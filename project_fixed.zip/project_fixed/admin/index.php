<!DOCTYPE html>
<html lang="ka">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>EZZWAY — Admin Panel</title>
<style>
/* ══════════════════════════════════════════
   EZZWAY ADMIN — Design System
══════════════════════════════════════════ */
:root {
  --bg:        #0a0a0f;
  --bg2:       #111118;
  --bg3:       #18181f;
  --border:    #2a2a35;
  --border2:   #3a3a48;
  --accent:    #7c5cfc;
  --accent2:   #9b7bff;
  --success:   #22c55e;
  --warning:   #f59e0b;
  --danger:    #ef4444;
  --info:      #3b82f6;
  --text:      #f1f0ff;
  --text2:     #9998b0;
  --text3:     #5c5b72;
  --radius:    10px;
  --radius-lg: 16px;
  --shadow:    0 4px 24px rgba(0,0,0,.5);
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{
  font-family:'Inter',system-ui,-apple-system,sans-serif;
  background:var(--bg);color:var(--text);
  min-height:100vh;font-size:14px;line-height:1.6;
}

/* ─── Scrollbar ──────── */
::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-track{background:var(--bg2)}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px}
::-webkit-scrollbar-thumb:hover{background:var(--accent)}

/* ─── Layout ─────────── */
.layout{display:flex;min-height:100vh}
.sidebar{
  width:240px;min-width:240px;background:var(--bg2);
  border-right:1px solid var(--border);
  display:flex;flex-direction:column;
  position:sticky;top:0;height:100vh;overflow-y:auto;
}
.main{flex:1;overflow:auto;padding:28px;min-height:100vh}

/* ─── Sidebar ────────── */
.sidebar-logo{
  padding:24px 20px 16px;
  border-bottom:1px solid var(--border);
}
.sidebar-logo .logo-text{
  font-size:18px;font-weight:800;letter-spacing:.5px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.sidebar-logo .logo-sub{font-size:10px;color:var(--text3);letter-spacing:1.5px;text-transform:uppercase;margin-top:2px}

.nav-section{padding:12px 10px 4px;font-size:10px;color:var(--text3);letter-spacing:1.5px;text-transform:uppercase;font-weight:600}
.nav-item{
  display:flex;align-items:center;gap:10px;
  padding:9px 14px;border-radius:var(--radius);
  margin:1px 8px;cursor:pointer;
  color:var(--text2);font-size:13px;font-weight:500;
  transition:all .15s;user-select:none;
}
.nav-item:hover{background:var(--bg3);color:var(--text)}
.nav-item.active{background:rgba(124,92,252,.15);color:var(--accent2);border-left:3px solid var(--accent)}
.nav-item .nav-icon{width:17px;height:17px;opacity:.8;flex-shrink:0}
.nav-item .nav-badge{
  margin-left:auto;background:var(--accent);color:#fff;
  font-size:10px;font-weight:700;padding:1px 6px;border-radius:20px;
}
.sidebar-user{
  margin-top:auto;padding:14px 14px;
  border-top:1px solid var(--border);
}
.sidebar-user .user-info{display:flex;align-items:center;gap:10px}
.sidebar-user .avatar{
  width:34px;height:34px;border-radius:50%;
  background:linear-gradient(135deg,var(--accent),#5b3fbf);
  display:flex;align-items:center;justify-content:center;
  font-size:13px;font-weight:700;color:#fff;flex-shrink:0;
}
.sidebar-user .user-name{font-size:13px;font-weight:600}
.sidebar-user .user-role{font-size:11px;color:var(--text3)}

/* ─── Top Bar ─────────── */
.topbar{
  display:flex;align-items:center;justify-content:space-between;
  margin-bottom:24px;
}
.page-title{font-size:22px;font-weight:800;letter-spacing:-.3px}
.page-sub{font-size:13px;color:var(--text2);margin-top:2px}
.topbar-actions{display:flex;gap:8px}

/* ─── Buttons ─────────── */
.btn{
  display:inline-flex;align-items:center;gap:7px;
  padding:8px 16px;border-radius:var(--radius);
  font-size:13px;font-weight:600;cursor:pointer;
  border:none;transition:all .15s;white-space:nowrap;
}
.btn-primary{background:var(--accent);color:#fff}
.btn-primary:hover{background:var(--accent2)}
.btn-ghost{background:transparent;color:var(--text2);border:1px solid var(--border)}
.btn-ghost:hover{background:var(--bg3);color:var(--text)}
.btn-danger{background:rgba(239,68,68,.15);color:var(--danger);border:1px solid rgba(239,68,68,.3)}
.btn-danger:hover{background:var(--danger);color:#fff}
.btn-success{background:rgba(34,197,94,.12);color:var(--success);border:1px solid rgba(34,197,94,.3)}
.btn-success:hover{background:var(--success);color:#fff}
.btn-sm{padding:5px 11px;font-size:12px}
.btn svg{width:15px;height:15px}

/* ─── Cards ───────────── */
.card{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius-lg);padding:20px}
.card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}
.card-title{font-size:15px;font-weight:700}

/* ─── Stats ───────────── */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:24px}
.stat-card{
  background:var(--bg2);border:1px solid var(--border);
  border-radius:var(--radius-lg);padding:18px;
  display:flex;align-items:center;gap:14px;
}
.stat-icon{
  width:44px;height:44px;border-radius:var(--radius);
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;
}
.stat-icon svg{width:22px;height:22px}
.stat-label{font-size:11px;color:var(--text2);text-transform:uppercase;letter-spacing:1px;font-weight:600}
.stat-value{font-size:26px;font-weight:800;margin-top:2px;letter-spacing:-.5px}

/* ─── Table ───────────── */
.table-wrap{overflow-x:auto;border-radius:var(--radius-lg);border:1px solid var(--border)}
table{width:100%;border-collapse:collapse;background:var(--bg2)}
thead tr{border-bottom:1px solid var(--border)}
th{
  padding:11px 14px;text-align:left;font-size:11px;
  text-transform:uppercase;letter-spacing:1px;color:var(--text3);
  font-weight:600;background:var(--bg3);white-space:nowrap;
}
td{padding:11px 14px;border-bottom:1px solid var(--border);vertical-align:middle;font-size:13px}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(124,92,252,.04)}

/* ─── Badges ──────────── */
.badge{
  display:inline-flex;align-items:center;padding:3px 10px;
  border-radius:20px;font-size:11px;font-weight:700;letter-spacing:.3px;
}
.badge-admin    {background:rgba(239,68,68,.15);color:#ff8080;border:1px solid rgba(239,68,68,.3)}
.badge-moderator{background:rgba(245,158,11,.15);color:#fbbf24;border:1px solid rgba(245,158,11,.3)}
.badge-editor   {background:rgba(59,130,246,.15);color:#60a5fa;border:1px solid rgba(59,130,246,.3)}
.badge-user     {background:rgba(34,197,94,.12);color:#4ade80;border:1px solid rgba(34,197,94,.3)}
.badge-guest    {background:var(--bg3);color:var(--text3);border:1px solid var(--border)}
.badge-on {background:rgba(34,197,94,.12);color:#4ade80;border:1px solid rgba(34,197,94,.3)}
.badge-off{background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.25)}
.badge-new{background:rgba(59,130,246,.15);color:#60a5fa;border:1px solid rgba(59,130,246,.3)}

/* ─── Product Thumb ────── */
.prod-thumb{
  width:42px;height:42px;border-radius:8px;object-fit:cover;
  background:var(--bg3);flex-shrink:0;
}
.prod-info{display:flex;align-items:center;gap:10px}
.prod-name{font-weight:600;font-size:13px}
.prod-desc{font-size:11px;color:var(--text2);margin-top:1px}

/* ─── Stars ───────────── */
.stars{display:flex;gap:2px}
.star{width:13px;height:13px;color:#f59e0b}
.star.e{color:var(--border2)}

/* ─── Toggle ──────────── */
.toggle{
  position:relative;width:36px;height:20px;
  display:inline-block;cursor:pointer;
}
.toggle input{opacity:0;width:0;height:0}
.toggle-slider{
  position:absolute;inset:0;background:var(--border2);
  border-radius:20px;transition:.2s;
}
.toggle-slider::before{
  content:'';position:absolute;
  width:14px;height:14px;border-radius:50%;
  left:3px;top:3px;background:#fff;transition:.2s;
}
.toggle input:checked + .toggle-slider{background:var(--accent)}
.toggle input:checked + .toggle-slider::before{transform:translateX(16px)}

/* ─── Form ────────────── */
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.form-grid.cols3{grid-template-columns:1fr 1fr 1fr}
.form-group{display:flex;flex-direction:column;gap:5px}
.form-group.full{grid-column:1/-1}
label{font-size:12px;font-weight:600;color:var(--text2);text-transform:uppercase;letter-spacing:.5px}
input[type=text],input[type=number],input[type=url],select,textarea{
  background:var(--bg3);border:1px solid var(--border);
  color:var(--text);border-radius:var(--radius);
  padding:9px 12px;font-size:13px;width:100%;
  transition:border-color .15s;outline:none;
  font-family:inherit;
}
input:focus,select:focus,textarea:focus{border-color:var(--accent)}
select option{background:var(--bg3)}
textarea{resize:vertical;min-height:70px}
.form-row{display:flex;gap:10px;align-items:flex-end}
.form-toggle-row{
  display:flex;align-items:center;justify-content:space-between;
  padding:10px 12px;background:var(--bg3);border:1px solid var(--border);
  border-radius:var(--radius);
}
.form-toggle-label{font-size:13px;font-weight:500}
.form-toggle-sub{font-size:11px;color:var(--text3);margin-top:1px}

/* ─── Modal ───────────── */
.modal-overlay{
  position:fixed;inset:0;background:rgba(0,0,0,.7);
  display:none;align-items:center;justify-content:center;
  z-index:1000;padding:20px;backdrop-filter:blur(4px);
}
.modal-overlay.open{display:flex}
.modal{
  background:var(--bg2);border:1px solid var(--border);
  border-radius:var(--radius-lg);width:100%;max-width:580px;
  max-height:90vh;overflow-y:auto;box-shadow:var(--shadow);
}
.modal-head{
  padding:20px 24px;border-bottom:1px solid var(--border);
  display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;background:var(--bg2);z-index:1;
}
.modal-head h2{font-size:16px;font-weight:800}
.modal-close{
  width:32px;height:32px;border-radius:8px;
  border:1px solid var(--border);background:transparent;
  color:var(--text2);cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  transition:all .15s;
}
.modal-close:hover{background:var(--bg3);color:var(--text)}
.modal-body{padding:24px}
.modal-foot{
  padding:16px 24px;border-top:1px solid var(--border);
  display:flex;gap:10px;justify-content:flex-end;
}

/* ─── Search Bar ──────── */
.search-bar{
  display:flex;align-items:center;gap:10px;
  background:var(--bg3);border:1px solid var(--border);
  border-radius:var(--radius);padding:8px 14px;
  min-width:240px;
}
.search-bar svg{width:15px;height:15px;color:var(--text3);flex-shrink:0}
.search-bar input{
  background:transparent;border:none;outline:none;
  color:var(--text);font-size:13px;width:100%;
}

/* ─── Toast ───────────── */
#toast-container{
  position:fixed;bottom:24px;right:24px;
  display:flex;flex-direction:column;gap:8px;z-index:9999;
}
.toast{
  background:var(--bg2);border:1px solid var(--border);
  border-radius:var(--radius);padding:12px 16px;
  display:flex;align-items:center;gap:10px;
  box-shadow:var(--shadow);font-size:13px;font-weight:500;
  animation:toastIn .25s ease;min-width:240px;max-width:340px;
}
.toast.success{border-color:rgba(34,197,94,.4);background:rgba(34,197,94,.08)}
.toast.error  {border-color:rgba(239,68,68,.4);background:rgba(239,68,68,.08)}
.toast.info   {border-color:rgba(59,130,246,.4);background:rgba(59,130,246,.08)}
@keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}

/* ─── Page Sections ────── */
.page{display:none}
.page.active{display:block}

/* ─── Filter bar ──────── */
.filter-bar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:16px}

/* ─── Confirm Dialog ────── */
.confirm-overlay{
  position:fixed;inset:0;background:rgba(0,0,0,.7);
  display:none;align-items:center;justify-content:center;
  z-index:2000;backdrop-filter:blur(4px);
}
.confirm-overlay.open{display:flex}
.confirm-box{
  background:var(--bg2);border:1px solid var(--border);
  border-radius:var(--radius-lg);padding:24px;max-width:380px;width:90%;
  box-shadow:var(--shadow);
}
.confirm-icon{font-size:32px;margin-bottom:12px;display:block}
.confirm-title{font-size:16px;font-weight:800;margin-bottom:6px}
.confirm-msg{font-size:13px;color:var(--text2);margin-bottom:20px}
.confirm-actions{display:flex;gap:10px;justify-content:flex-end}

/* ─── Image Preview ────── */
.img-preview{
  width:100%;height:140px;border-radius:var(--radius);
  border:1px solid var(--border);object-fit:cover;
  background:var(--bg3);display:none;margin-bottom:8px;
}
.img-preview.show{display:block}

/* ─── Loading ─────────── */
.spinner{
  width:32px;height:32px;border:3px solid var(--border);
  border-top-color:var(--accent);border-radius:50%;
  animation:spin .6s linear infinite;margin:40px auto;
}
@keyframes spin{to{transform:rotate(360deg)}}
.loading-overlay{
  position:absolute;inset:0;background:rgba(10,10,15,.8);
  display:flex;align-items:center;justify-content:center;
  border-radius:var(--radius-lg);z-index:5;
}

/* ─── Empty State ──────── */
.empty-state{
  padding:48px 20px;text-align:center;color:var(--text3);
}
.empty-state svg{width:48px;height:48px;margin:0 auto 12px;display:block;opacity:.4}
.empty-state h3{font-size:15px;font-weight:600;color:var(--text2);margin-bottom:6px}

/* ─── Responsive ──────── */
@media(max-width:768px){
  .sidebar{display:none}
  .main{padding:16px}
  .form-grid{grid-template-columns:1fr}
  .form-grid.cols3{grid-template-columns:1fr}
  .stats-grid{grid-template-columns:1fr 1fr}
}

/* ─── Category grid ────── */
.cat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}
.cat-card{
  background:var(--bg3);border:1px solid var(--border);
  border-radius:var(--radius-lg);padding:14px;
  display:flex;gap:12px;align-items:center;
}
.cat-thumb{
  width:48px;height:48px;border-radius:8px;object-fit:cover;
  background:var(--bg2);flex-shrink:0;
}
.cat-card-name{font-weight:700;font-size:14px}
.cat-card-count{font-size:12px;color:var(--text3);margin-top:2px}
.cat-actions{margin-left:auto;display:flex;gap:6px}

/* ─── Drag handle (cosmetic) ── */
.drag-handle{cursor:grab;color:var(--text3);padding-right:6px}
</style>
</head>
<body>

<!-- ══════════════════════════════════
     LAYOUT
══════════════════════════════════ -->
<div class="layout">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-text">⚡ EZZWAY</div>
      <div class="logo-sub">Admin Panel</div>
    </div>

    <div class="nav-section">მთავარი</div>
    <div class="nav-item active" data-page="dashboard">
      <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
      Dashboard
    </div>

    <div class="nav-section">კატალოგი</div>
    <div class="nav-item" data-page="products">
      <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
      პროდუქტები
      <span class="nav-badge" id="nb-products">0</span>
    </div>
    <div class="nav-item" data-page="categories">
      <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
      კატეგორიები
    </div>

    <div class="nav-section">მომხმარებლები</div>
    <div class="nav-item" data-page="users">
      <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
      მომხმარებლები
      <span class="nav-badge" id="nb-users">0</span>
    </div>

    <div class="sidebar-user">
      <div class="user-info">
        <div class="avatar" id="sb-avatar">A</div>
        <div>
          <div class="user-name" id="sb-name">—</div>
          <div class="user-role" id="sb-role">—</div>
        </div>
      </div>
    </div>
  </aside>

  <!-- MAIN -->
  <main class="main">

    <!-- ── DASHBOARD ────────────────────── -->
    <section class="page active" id="page-dashboard">
      <div class="topbar">
        <div>
          <div class="page-title">Dashboard</div>
          <div class="page-sub">კეთილი იყოს თქვენი მობრძანება, EZZWAY-ში</div>
        </div>
      </div>
      <div class="stats-grid" id="stats-grid"></div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
        <div class="card">
          <div class="card-header"><div class="card-title">🕐 ბოლო პროდუქტები</div></div>
          <div id="recent-products"></div>
        </div>
        <div class="card">
          <div class="card-header"><div class="card-title">👥 ბოლო მომხმარებლები</div></div>
          <div id="recent-users"></div>
        </div>
      </div>
    </section>

    <!-- ── PRODUCTS ──────────────────────── -->
    <section class="page" id="page-products">
      <div class="topbar">
        <div>
          <div class="page-title">პროდუქტები</div>
          <div class="page-sub">პროდუქტების მართვა და ფილტრის კონტროლი</div>
        </div>
        <div class="topbar-actions">
          <button class="btn btn-primary" onclick="openProductModal()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            პროდუქტის დამატება
          </button>
        </div>
      </div>

      <div class="filter-bar">
        <div class="search-bar" style="flex:1;max-width:320px">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="პროდუქტის ძიება..." id="prod-search" oninput="renderProductsTable()"/>
        </div>
        <select id="prod-cat-filter" onchange="renderProductsTable()" style="background:var(--bg3);border:1px solid var(--border);color:var(--text);border-radius:var(--radius);padding:8px 12px;font-size:13px">
          <option value="">ყველა კატეგორია</option>
        </select>
        <select id="prod-filter-filter" onchange="renderProductsTable()" style="background:var(--bg3);border:1px solid var(--border);color:var(--text);border-radius:var(--radius);padding:8px 12px;font-size:13px">
          <option value="">ფილტრი: ყველა</option>
          <option value="yes">ფილტრში: კი</option>
          <option value="no">ფილტრში: არა</option>
        </select>
      </div>

      <div class="table-wrap" style="position:relative" id="prod-table-wrap">
        <table id="prod-table">
          <thead>
            <tr>
              <th>პროდუქტი</th>
              <th>კატეგორია</th>
              <th>ფასი</th>
              <th>ბეჯი</th>
              <th>რეიტინგი</th>
              <th>ფილტრში</th>
              <th>სტატუსი</th>
              <th>მოქმედება</th>
            </tr>
          </thead>
          <tbody id="prod-tbody"></tbody>
        </table>
      </div>
    </section>

    <!-- ── CATEGORIES ─────────────────────── -->
    <section class="page" id="page-categories">
      <div class="topbar">
        <div>
          <div class="page-title">კატეგორიები</div>
          <div class="page-sub">კატეგორიების მართვა</div>
        </div>
        <div class="topbar-actions">
          <button class="btn btn-primary" id="add-cat-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            კატეგორიის დამატება
          </button>
        </div>
      </div>
      <div class="cat-grid" id="cat-grid"></div>
    </section>

    <!-- ── USERS ──────────────────────────── -->
    <section class="page" id="page-users">
      <div class="topbar">
        <div>
          <div class="page-title">მომხმარებლები</div>
          <div class="page-sub">Role-ების მართვა და მომხმარებლების კონტროლი</div>
        </div>
      </div>

      <div class="filter-bar">
        <div class="search-bar" style="flex:1;max-width:320px">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="მომხმარებლის ძიება..." id="user-search" oninput="renderUsersTable()"/>
        </div>
        <select id="role-filter" onchange="renderUsersTable()" style="background:var(--bg3);border:1px solid var(--border);color:var(--text);border-radius:var(--radius);padding:8px 12px;font-size:13px">
          <option value="">ყველა Role</option>
          <option value="admin">Admin</option>
          <option value="moderator">Moderator</option>
          <option value="editor">Editor</option>
          <option value="user">User</option>
          <option value="guest">Guest</option>
        </select>
      </div>

      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>მომხმარებელი</th>
              <th>ელ-ფოსტა</th>
              <th>Role</th>
              <th>რეგისტრაცია</th>
              <th>ბოლო შესვლა</th>
              <th>მოქმედება</th>
            </tr>
          </thead>
          <tbody id="user-tbody"></tbody>
        </table>
      </div>
    </section>

  </main>
</div>

<!-- ══════════════════════════════════
     MODALS
══════════════════════════════════ -->

<!-- Product Modal -->
<div class="modal-overlay" id="product-modal">
  <div class="modal">
    <div class="modal-head">
      <h2 id="modal-prod-title">პროდუქტის დამატება</h2>
      <button class="modal-close" onclick="closeProductModal()">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="modal-body">
      <input type="hidden" id="prod-id"/>
      <div class="form-grid" style="margin-bottom:14px">
        <div class="form-group full">
          <label>სახელი *</label>
          <input type="text" id="prod-name" placeholder="მაგ: Sony WH-1000XM5" maxlength="200"/>
        </div>
        <div class="form-group">
          <label>კატეგორია *</label>
          <select id="prod-cat"></select>
        </div>
        <div class="form-group">
          <label>ფასი (₾) *</label>
          <input type="number" id="prod-price" placeholder="0" min="0"/>
        </div>
        <div class="form-group full">
          <label>აღწერა</label>
          <textarea id="prod-desc" placeholder="პროდუქტის მოკლე აღწერა..." maxlength="500"></textarea>
        </div>
        <div class="form-group">
          <label>ბეჯი</label>
          <input type="text" id="prod-badge" placeholder="მაგ: ახალი, ბესტსელერი" maxlength="50"/>
        </div>
        <div class="form-group">
          <label>რეიტინგი (1-5)</label>
          <select id="prod-rating">
            <option value="5">★★★★★ (5)</option>
            <option value="4">★★★★☆ (4)</option>
            <option value="3">★★★☆☆ (3)</option>
            <option value="2">★★☆☆☆ (2)</option>
            <option value="1">★☆☆☆☆ (1)</option>
          </select>
        </div>
        <div class="form-group">
          <label>მიმოხილვები</label>
          <input type="number" id="prod-reviews" placeholder="0" min="0"/>
        </div>
        <div class="form-group full">
          <label>სურათის URL</label>
          <input type="url" id="prod-img" placeholder="https://..." oninput="previewImage(this.value)"/>
          <img id="prod-img-preview" class="img-preview" alt="preview"/>
        </div>
      </div>

      <div style="display:flex;flex-direction:column;gap:10px">
        <div class="form-toggle-row">
          <div>
            <div class="form-toggle-label">🔍 გამოჩნდეს ფილტრში</div>
            <div class="form-toggle-sub">ჩართვის შემთხვევაში პროდუქტი ფილტრში გამოჩნდება</div>
          </div>
          <label class="toggle">
            <input type="checkbox" id="prod-show-filter" checked/>
            <span class="toggle-slider"></span>
          </label>
        </div>
        <div class="form-toggle-row">
          <div>
            <div class="form-toggle-label">✅ აქტიური</div>
            <div class="form-toggle-sub">გამორთვის შემთხვევაში პროდუქტი არ გამოჩნდება</div>
          </div>
          <label class="toggle">
            <input type="checkbox" id="prod-active" checked/>
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeProductModal()">გაუქმება</button>
      <button class="btn btn-primary" onclick="saveProduct()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        შენახვა
      </button>
    </div>
  </div>
</div>

<!-- Category Modal -->
<div class="modal-overlay" id="cat-modal">
  <div class="modal">
    <div class="modal-head">
      <h2 id="modal-cat-title">კატეგორიის დამატება</h2>
      <button class="modal-close" onclick="closeCatModal()">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="modal-body">
      <input type="hidden" id="cat-id"/>
      <div class="form-grid">
        <div class="form-group full">
          <label>სახელი *</label>
          <input type="text" id="cat-name" placeholder="მაგ: ყურსასმენები"/>
        </div>
        <div class="form-group full">
          <label>სურათის URL</label>
          <input type="url" id="cat-img-url" placeholder="https://..." oninput="previewCatImage(this.value)"/>
          <img id="cat-img-preview" class="img-preview" alt="preview" style="margin-top:8px"/>
        </div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeCatModal()">გაუქმება</button>
      <button class="btn btn-primary" onclick="saveCat()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        შენახვა
      </button>
    </div>
  </div>
</div>

<!-- Role Modal -->
<div class="modal-overlay" id="role-modal">
  <div class="modal" style="max-width:400px">
    <div class="modal-head">
      <h2>Role-ის შეცვლა</h2>
      <button class="modal-close" onclick="closeRoleModal()">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="modal-body">
      <input type="hidden" id="role-user-id"/>
      <p style="color:var(--text2);font-size:13px;margin-bottom:16px">
        <strong id="role-user-name"></strong>-ის role-ის შეცვლა:
      </p>
      <div style="display:flex;flex-direction:column;gap:8px" id="role-options"></div>
    </div>
  </div>
</div>

<!-- Confirm Dialog -->
<div class="confirm-overlay" id="confirm-overlay">
  <div class="confirm-box">
    <span class="confirm-icon" id="confirm-icon">🗑️</span>
    <div class="confirm-title" id="confirm-title">დარწმუნებული ხარ?</div>
    <div class="confirm-msg" id="confirm-msg">ეს ქმედება შეუქცევადია.</div>
    <div class="confirm-actions">
      <button class="btn btn-ghost" onclick="closeConfirm()">გაუქმება</button>
      <button class="btn btn-danger" id="confirm-ok-btn">წაშლა</button>
    </div>
  </div>
</div>

<!-- Toast Container -->
<div id="toast-container"></div>

<!-- ══════════════════════════════════
     JS
══════════════════════════════════ -->
<script>
/* ─── State ─────────────────────────────── */
const S = {
  user: null, role: null, csrfToken: null,
  products: [], categories: [], users: [],
  editingProdId: null, editingCatId: null,
};

const BASE = '../api';
const ROLES = ['admin','moderator','editor','user','guest'];
const ROLE_LABELS = {
  admin:'Admin', moderator:'Moderator', editor:'Editor', user:'User', guest:'Guest'
};
const ROLE_LEVEL = {admin:4,moderator:3,editor:2,user:1,guest:0};

/* ─── Init ───────────────────────────────── */
async function init() {
  await fetchMe();
  if (!S.user) {
    document.body.innerHTML = `
      <div style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg)">
        <div style="text-align:center">
          <div style="font-size:48px;margin-bottom:16px">🔐</div>
          <h2 style="font-size:20px;font-weight:800;margin-bottom:8px">წვდომა შეზღუდულია</h2>
          <p style="color:var(--text2);margin-bottom:20px">Admin Panel-ის სანახავად ავტორიზაცია გჭირდება.</p>
          <a href="../" class="btn btn-primary" style="text-decoration:none;display:inline-flex">← მთავარ გვერდზე</a>
        </div>
      </div>`;
    return;
  }
  if (ROLE_LEVEL[S.role] < ROLE_LEVEL['editor']) {
    document.body.innerHTML = `
      <div style="min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg)">
        <div style="text-align:center">
          <div style="font-size:48px;margin-bottom:16px">🚫</div>
          <h2 style="font-size:20px;font-weight:800;margin-bottom:8px">არასაკმარისი პრივილეგიები</h2>
          <p style="color:var(--text2);margin-bottom:20px">ამ გვერდზე შესვლა მხოლოდ Editor+ შეუძლია.</p>
          <a href="../" class="btn btn-ghost" style="text-decoration:none;display:inline-flex">← უკან</a>
        </div>
      </div>`;
    return;
  }

  updateSidebarUser();
  await Promise.all([loadProducts(), loadCategories(), loadUsers()]);
  renderDashboard();
  bindNav();
  document.getElementById('add-cat-btn').addEventListener('click', () => openCatModal());
}

/* ─── API Helpers ────────────────────────── */
async function api(url, method='GET', body=null) {
  const opts = {
    method,
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': S.csrfToken || '' }
  };
  if (body) opts.body = JSON.stringify(body);
  const r = await fetch(BASE + url, opts);
  return r.json();
}

async function fetchMe() {
  try {
    const r = await api('/me.php');
    if (r.success && r.data?.user) {
      S.user = r.data.user;
      S.role = r.data.role;
      S.csrfToken = r.data.csrf_token;
    } else {
      S.csrfToken = r.data?.csrf_token || null;
    }
  } catch(e) { console.error(e); }
}

async function loadProducts() {
  const r = await api('/products.php?admin=1');
  if (r.success) {
    S.products   = r.data.products || [];
    S.categories = r.data.categories || [];
    document.getElementById('nb-products').textContent = S.products.length;
  }
}

async function loadCategories() {
  const r = await api('/categories.php');
  if (r.success) S.categories = r.data || [];
}

async function loadUsers() {
  if (ROLE_LEVEL[S.role] < ROLE_LEVEL['moderator']) return;
  const r = await api('/users_admin.php');
  if (r.success) {
    S.users = r.data || [];
    document.getElementById('nb-users').textContent = S.users.length;
  }
}

/* ─── Sidebar User ───────────────────────── */
function updateSidebarUser() {
  document.getElementById('sb-name').textContent = (S.user.firstName + ' ' + S.user.lastName).trim() || '—';
  document.getElementById('sb-role').textContent = ROLE_LABELS[S.role] || S.role;
  document.getElementById('sb-avatar').textContent = (S.user.firstName?.[0] || '?').toUpperCase();
}

/* ─── Navigation ─────────────────────────── */
function bindNav() {
  document.querySelectorAll('.nav-item[data-page]').forEach(el => {
    el.addEventListener('click', () => {
      const page = el.dataset.page;
      document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
      el.classList.add('active');
      document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
      document.getElementById('page-' + page).classList.add('active');
      if (page === 'products')   renderProductsTable();
      if (page === 'categories') renderCategoryGrid();
      if (page === 'users')      renderUsersTable();
    });
  });
}

/* ─── Dashboard ──────────────────────────── */
function renderDashboard() {
  const totalProd   = S.products.length;
  const inFilter    = S.products.filter(p => p.show_in_filter).length;
  const totalCats   = S.categories.length;
  const totalUsers  = S.users.length;

  document.getElementById('stats-grid').innerHTML = `
    <div class="stat-card">
      <div class="stat-icon" style="background:rgba(124,92,252,.15);color:var(--accent)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
      </div>
      <div><div class="stat-label">სულ პროდუქტი</div><div class="stat-value">${totalProd}</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:rgba(34,197,94,.12);color:var(--success)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      </div>
      <div><div class="stat-label">ფილტრში</div><div class="stat-value">${inFilter}</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:rgba(245,158,11,.12);color:var(--warning)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
      </div>
      <div><div class="stat-label">კატეგორიები</div><div class="stat-value">${totalCats}</div></div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:rgba(59,130,246,.12);color:var(--info)">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
      </div>
      <div><div class="stat-label">მომხმარებლები</div><div class="stat-value">${totalUsers}</div></div>
    </div>`;

  // Recent products
  const recent = [...S.products].sort((a,b) => b.createdAt?.localeCompare(a.createdAt)).slice(0,5);
  document.getElementById('recent-products').innerHTML = recent.length ? recent.map(p => `
    <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border)">
      <img src="${esc(p.img)}" class="prod-thumb" onerror="this.src=''"/>
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:13px;truncate">${esc(p.name)}</div>
        <div style="font-size:11px;color:var(--text2)">₾${p.price}</div>
      </div>
      <span class="badge ${p.show_in_filter ? 'badge-on' : 'badge-off'}">${p.show_in_filter ? 'ფილტრში' : 'დამალული'}</span>
    </div>`).join('') : '<div class="empty-state">პროდუქტი არ არის</div>';

  // Recent users
  const recentU = [...S.users].sort((a,b) => b.createdAt?.localeCompare(a.createdAt)).slice(0,5);
  document.getElementById('recent-users').innerHTML = recentU.length ? recentU.map(u => `
    <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border)">
      <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--accent),#5b3fbf);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:#fff;flex-shrink:0">
        ${(u.firstName?.[0]||'?').toUpperCase()}
      </div>
      <div style="flex:1">
        <div style="font-weight:600;font-size:13px">${esc(u.firstName)} ${esc(u.lastName)}</div>
        <div style="font-size:11px;color:var(--text2)">${esc(u.email)}</div>
      </div>
      <span class="badge badge-${u.role||'user'}">${ROLE_LABELS[u.role||'user']}</span>
    </div>`).join('') : '<div class="empty-state">მომხმარებელი არ არის</div>';
}

/* ─── Products Table ─────────────────────── */
function renderProductsTable() {
  const search  = document.getElementById('prod-search').value.toLowerCase();
  const catF    = document.getElementById('prod-cat-filter').value;
  const filterF = document.getElementById('prod-filter-filter').value;

  // Populate category filter dropdown
  const catSel = document.getElementById('prod-cat-filter');
  if (catSel.options.length <= 1) {
    S.categories.forEach(c => {
      const o = document.createElement('option');
      o.value = c.id; o.textContent = c.label;
      catSel.appendChild(o);
    });
  }

  let prods = S.products.filter(p => {
    if (search && !p.name.toLowerCase().includes(search) && !p.desc?.toLowerCase().includes(search)) return false;
    if (catF && p.category_id !== catF) return false;
    if (filterF === 'yes' && !p.show_in_filter) return false;
    if (filterF === 'no'  &&  p.show_in_filter) return false;
    return true;
  });

  const tbody = document.getElementById('prod-tbody');
  if (!prods.length) {
    tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      <h3>პროდუქტი ვერ მოიძებნა</h3>
    </div></td></tr>`;
    return;
  }

  const catById = Object.fromEntries(S.categories.map(c => [c.id, c.label]));

  tbody.innerHTML = prods.map(p => `
    <tr>
      <td>
        <div class="prod-info">
          <img src="${esc(p.img)}" class="prod-thumb" onerror="this.style.background='#222'"/>
          <div>
            <div class="prod-name">${esc(p.name)}</div>
            <div class="prod-desc">${esc(p.desc||'')}</div>
          </div>
        </div>
      </td>
      <td style="color:var(--text2)">${esc(catById[p.category_id]||p.category_id)}</td>
      <td style="font-weight:700">₾${p.price}</td>
      <td>${p.badge ? `<span class="badge badge-new">${esc(p.badge)}</span>` : '<span style="color:var(--text3)">—</span>'}</td>
      <td>
        <div class="stars">${starsHTML(p.rating)}</div>
        <div style="font-size:11px;color:var(--text3)">(${p.reviews})</div>
      </td>
      <td>
        <label class="toggle" title="ფილტრში ჩვენება" onclick="toggleFilter('${p.id}', event)">
          <input type="checkbox" ${p.show_in_filter ? 'checked' : ''} readonly/>
          <span class="toggle-slider"></span>
        </label>
      </td>
      <td><span class="badge ${p.active ? 'badge-on' : 'badge-off'}">${p.active ? 'აქტიური' : 'გამორთული'}</span></td>
      <td>
        <div style="display:flex;gap:6px">
          <button class="btn btn-ghost btn-sm" onclick="openProductModal('${p.id}')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="13" height="13"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
          <button class="btn btn-danger btn-sm" onclick="confirmDeleteProduct('${p.id}', '${esc(p.name)}')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="13" height="13"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg>
          </button>
        </div>
      </td>
    </tr>`).join('');
}

/* ─── Product Modal ──────────────────────── */
function openProductModal(id = null) {
  S.editingProdId = id;
  document.getElementById('modal-prod-title').textContent = id ? 'პროდუქტის რედაქტირება' : 'პროდუქტის დამატება';

  // Populate category select
  const sel = document.getElementById('prod-cat');
  sel.innerHTML = S.categories.map(c => `<option value="${c.id}">${c.label}</option>`).join('');

  if (id) {
    const p = S.products.find(x => x.id === id);
    if (!p) return;
    document.getElementById('prod-id').value           = p.id;
    document.getElementById('prod-name').value         = p.name;
    document.getElementById('prod-desc').value         = p.desc||'';
    document.getElementById('prod-price').value        = p.price;
    document.getElementById('prod-badge').value        = p.badge||'';
    document.getElementById('prod-rating').value       = p.rating;
    document.getElementById('prod-reviews').value      = p.reviews;
    document.getElementById('prod-img').value          = p.img||'';
    document.getElementById('prod-cat').value          = p.category_id;
    document.getElementById('prod-show-filter').checked = p.show_in_filter;
    document.getElementById('prod-active').checked     = p.active;
    previewImage(p.img||'');
  } else {
    document.getElementById('prod-id').value           = '';
    document.getElementById('prod-name').value         = '';
    document.getElementById('prod-desc').value         = '';
    document.getElementById('prod-price').value        = '';
    document.getElementById('prod-badge').value        = '';
    document.getElementById('prod-rating').value       = '5';
    document.getElementById('prod-reviews').value      = '0';
    document.getElementById('prod-img').value          = '';
    document.getElementById('prod-show-filter').checked = true;
    document.getElementById('prod-active').checked     = true;
    previewImage('');
  }

  document.getElementById('product-modal').classList.add('open');
}

function closeProductModal() {
  document.getElementById('product-modal').classList.remove('open');
  S.editingProdId = null;
}

async function saveProduct() {
  const body = {
    id:             document.getElementById('prod-id').value || undefined,
    name:           document.getElementById('prod-name').value.trim(),
    desc:           document.getElementById('prod-desc').value.trim(),
    price:          parseInt(document.getElementById('prod-price').value) || 0,
    badge:          document.getElementById('prod-badge').value.trim() || null,
    rating:         parseInt(document.getElementById('prod-rating').value),
    reviews:        parseInt(document.getElementById('prod-reviews').value) || 0,
    img:            document.getElementById('prod-img').value.trim(),
    category_id:    document.getElementById('prod-cat').value,
    show_in_filter: document.getElementById('prod-show-filter').checked,
    active:         document.getElementById('prod-active').checked,
    csrf_token:     S.csrfToken,
  };

  if (!body.name) { toast('სახელი სავალდებულოა', 'error'); return; }
  if (!body.category_id) { toast('კატეგორია სავალდებულოა', 'error'); return; }

  const isEdit = !!S.editingProdId;
  const r = await api('/products.php', isEdit ? 'PUT' : 'POST', body);
  if (!r.success) { toast(r.error || 'შეცდომა', 'error'); return; }

  await loadProducts();
  closeProductModal();
  renderProductsTable();
  renderDashboard();
  toast(isEdit ? 'პროდუქტი განახლდა ✓' : 'პროდუქტი დაემატა ✓', 'success');
}

/* ─── Filter Toggle (inline) ─────────────── */
async function toggleFilter(id, e) {
  e.preventDefault();
  e.stopPropagation();
  const p = S.products.find(x => x.id === id);
  if (!p) return;
  const r = await api('/products.php', 'PUT', {
    id, show_in_filter: !p.show_in_filter, csrf_token: S.csrfToken
  });
  if (!r.success) { toast(r.error || 'შეცდომა', 'error'); return; }
  await loadProducts();
  renderProductsTable();
  toast(r.data.show_in_filter ? 'ფილტრში გამოჩნდება ✓' : 'ფილტრიდან დაიმალა ✓', 'info');
}

/* ─── Delete Product ─────────────────────── */
function confirmDeleteProduct(id, name) {
  showConfirm(
    '🗑️', 'პროდუქტის წაშლა',
    `"${name}" სამუდამოდ წაიშლება. ეს ქმედება შეუქცევადია.`,
    async () => {
      const r = await api('/products.php', 'DELETE', { id, csrf_token: S.csrfToken });
      if (!r.success) { toast(r.error || 'შეცდომა', 'error'); return; }
      await loadProducts();
      renderProductsTable();
      renderDashboard();
      toast('პროდუქტი წაიშალა', 'success');
    }
  );
}

/* ─── Categories ─────────────────────────── */
function renderCategoryGrid() {
  const prodCountByCat = {};
  S.products.forEach(p => { prodCountByCat[p.category_id] = (prodCountByCat[p.category_id]||0) + 1; });

  const sorted = [...S.categories].sort((a,b) => (a.order||99)-(b.order||99));
  document.getElementById('cat-grid').innerHTML = sorted.map(c => `
    <div class="cat-card">
      <img src="${esc(c.img)}" class="cat-thumb" onerror="this.style.background='#222'"/>
      <div style="flex:1;min-width:0">
        <div class="cat-card-name">${esc(c.label)}</div>
        <div class="cat-card-count">${prodCountByCat[c.id]||0} პროდუქტი</div>
      </div>
      <div class="cat-actions">
        <button class="btn btn-ghost btn-sm" onclick="openCatModal('${c.id}')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="13" height="13"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        </button>
        ${ROLE_LEVEL[S.role] >= ROLE_LEVEL['admin'] ? `
        <button class="btn btn-danger btn-sm" onclick="confirmDeleteCat('${c.id}','${esc(c.label)}')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="13" height="13"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg>
        </button>` : ''}
      </div>
    </div>`).join('') || '<div class="empty-state"><h3>კატეგორია არ არის</h3></div>';
}

function openCatModal(id = null) {
  S.editingCatId = id;
  document.getElementById('modal-cat-title').textContent = id ? 'კატეგორიის რედაქტირება' : 'კატეგორიის დამატება';
  document.getElementById('cat-id').value = id || '';
  const preview = document.getElementById('cat-img-preview');
  if (id) {
    const c = S.categories.find(x => x.id === id);
    document.getElementById('cat-name').value    = c.label;
    document.getElementById('cat-img-url').value = c.img||'';
    previewCatImage(c.img||'');
  } else {
    document.getElementById('cat-name').value    = '';
    document.getElementById('cat-img-url').value = '';
    preview.classList.remove('show');
  }
  document.getElementById('cat-modal').classList.add('open');
}

function closeCatModal() {
  document.getElementById('cat-modal').classList.remove('open');
}

async function saveCat() {
  const id   = document.getElementById('cat-id').value;
  const name = document.getElementById('cat-name').value.trim();
  const img  = document.getElementById('cat-img-url').value.trim();

  if (!name) { toast('სახელი სავალდებულოა', 'error'); return; }

  const body = { name: name, label: name, img, csrf_token: S.csrfToken };
  const isEdit = !!S.editingCatId;
  if (isEdit) body.id = id;

  const r = await api('/categories.php', isEdit ? 'PUT' : 'POST', body);
  if (!r.success) { toast(r.error || 'შეცდომა', 'error'); return; }

  await loadCategories();
  await loadProducts();
  closeCatModal();
  renderCategoryGrid();
  renderDashboard();
  toast(isEdit ? 'კატეგორია განახლდა ✓' : 'კატეგორია დაემატა ✓', 'success');
}

function confirmDeleteCat(id, name) {
  showConfirm('🗑️','კატეგორიის წაშლა',
    `"${name}" წაიშლება. (პროდუქტები უნდა იყოს ცარიელი)`,
    async () => {
      const r = await api('/categories.php', 'DELETE', { id, csrf_token: S.csrfToken });
      if (!r.success) { toast(r.error,'error'); return; }
      await loadCategories();
      renderCategoryGrid();
      toast('კატეგორია წაიშალა','success');
    });
}

/* ─── Users Table ────────────────────────── */
function renderUsersTable() {
  const search = document.getElementById('user-search').value.toLowerCase();
  const roleF  = document.getElementById('role-filter').value;

  const filtered = S.users.filter(u => {
    const name = (u.firstName+' '+u.lastName+' '+u.email).toLowerCase();
    if (search && !name.includes(search)) return false;
    if (roleF && (u.role||'user') !== roleF) return false;
    return true;
  });

  const tbody = document.getElementById('user-tbody');
  if (!filtered.length) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state"><h3>მომხმარებელი ვერ მოიძებნა</h3></div></td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(u => {
    const role = u.role || 'user';
    const canChange = ROLE_LEVEL[S.role] >= ROLE_LEVEL['admin'] && u.id !== S.user.id;
    return `
      <tr>
        <td>
          <div style="display:flex;align-items:center;gap:10px">
            <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--accent),#5b3fbf);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:#fff;flex-shrink:0">
              ${(u.firstName?.[0]||'?').toUpperCase()}
            </div>
            <div>
              <div style="font-weight:600">${esc(u.firstName)} ${esc(u.lastName)}</div>
              ${u.id === S.user.id ? '<div style="font-size:11px;color:var(--accent2)">• შენ</div>' : ''}
            </div>
          </div>
        </td>
        <td style="color:var(--text2);font-size:12px">${esc(u.email)}</td>
        <td><span class="badge badge-${role}">${ROLE_LABELS[role]}</span></td>
        <td style="color:var(--text2);font-size:12px">${(u.createdAt||'').slice(0,10)}</td>
        <td style="color:var(--text2);font-size:12px">${(u.lastLogin||'').slice(0,10)}</td>
        <td>
          <div style="display:flex;gap:6px">
            ${canChange ? `
            <button class="btn btn-ghost btn-sm" onclick="openRoleModal('${u.id}','${esc(u.firstName+' '+u.lastName)}','${role}')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="13" height="13"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
              Role
            </button>
            <button class="btn btn-danger btn-sm" onclick="confirmDeleteUser('${u.id}','${esc(u.firstName)}')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="13" height="13"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg>
            </button>` : '<span style="color:var(--text3);font-size:12px">—</span>'}
          </div>
        </td>
      </tr>`;
  }).join('');
}

function openRoleModal(userId, userName, currentRole) {
  document.getElementById('role-user-id').value   = userId;
  document.getElementById('role-user-name').textContent = userName;
  const opts = document.getElementById('role-options');
  const allRoles = ['admin','moderator','editor','user','guest'];
  opts.innerHTML = allRoles.map(r => `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-radius:var(--radius);border:1px solid ${r === currentRole ? 'var(--accent)' : 'var(--border)'};background:${r === currentRole ? 'rgba(124,92,252,.1)' : 'var(--bg3)'};cursor:pointer"
      onclick="changeRole('${userId}','${r}')">
      <div>
        <span class="badge badge-${r}">${ROLE_LABELS[r]}</span>
        <span style="margin-left:8px;font-size:12px;color:var(--text2)">${roleDesc(r)}</span>
      </div>
      ${r === currentRole ? '<svg viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2.5" stroke-linecap="round" width="16" height="16"><polyline points="20 6 9 17 4 12"/></svg>' : ''}
    </div>`).join('');
  document.getElementById('role-modal').classList.add('open');
}

function roleDesc(r) {
  return {admin:'სრული წვდომა',moderator:'პროდუქტი + მომხმარებლები',editor:'პროდუქტების დამატება/რედ.',user:'ჩვეულებრივი მომხმარებელი',guest:'უპრივილეგიო'}[r]||'';
}

function closeRoleModal() {
  document.getElementById('role-modal').classList.remove('open');
}

async function changeRole(userId, newRole) {
  const r = await api('/users_admin.php','PUT',{id:userId,role:newRole,csrf_token:S.csrfToken});
  if (!r.success) { toast(r.error||'შეცდომა','error'); return; }
  await loadUsers();
  closeRoleModal();
  renderUsersTable();
  renderDashboard();
  toast(`Role შეიცვალა → ${ROLE_LABELS[newRole]} ✓`,'success');
}

function confirmDeleteUser(id, name) {
  showConfirm('🗑️','მომხმარებლის წაშლა',
    `"${name}"-ის ანგარიში სამუდამოდ წაიშლება.`,
    async () => {
      const r = await api('/users_admin.php','DELETE',{id,csrf_token:S.csrfToken});
      if (!r.success){ toast(r.error,'error');return; }
      await loadUsers();
      renderUsersTable();
      renderDashboard();
      toast('მომხმარებელი წაიშალა','success');
    });
}

/* ─── Image Preview ──────────────────────── */
function previewImage(url) {
  const el = document.getElementById('prod-img-preview');
  if (url) { el.src = url; el.classList.add('show'); }
  else el.classList.remove('show');
}

function previewCatImage(url) {
  const el = document.getElementById('cat-img-preview');
  if (url) { el.src = url; el.classList.add('show'); }
  else el.classList.remove('show');
}

/* ─── Helpers ────────────────────────────── */
function starsHTML(r) {
  let h='';
  for(let i=1;i<=5;i++) h+=`<svg class="star ${i<=r?'':'e'}" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>`;
  return h;
}

function esc(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

/* ─── Toast ──────────────────────────────── */
function toast(msg, type='info') {
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  const icons = {success:'✅',error:'❌',info:'ℹ️'};
  t.innerHTML = `<span>${icons[type]||''}</span><span>${msg}</span>`;
  document.getElementById('toast-container').appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

/* ─── Confirm Dialog ─────────────────────── */
let _confirmCb = null;
function showConfirm(icon, title, msg, cb) {
  document.getElementById('confirm-icon').textContent  = icon;
  document.getElementById('confirm-title').textContent = title;
  document.getElementById('confirm-msg').textContent   = msg;
  _confirmCb = cb;
  document.getElementById('confirm-overlay').classList.add('open');
}
function closeConfirm() {
  document.getElementById('confirm-overlay').classList.remove('open');
  _confirmCb = null;
}
document.getElementById('confirm-ok-btn').addEventListener('click', () => {
  if (_confirmCb) _confirmCb();
  closeConfirm();
});
document.getElementById('confirm-overlay').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeConfirm();
});

/* ─── Modal close on overlay click ──────── */
document.querySelectorAll('.modal-overlay').forEach(o => {
  o.addEventListener('click', e => {
    if (e.target === o) o.classList.remove('open');
  });
});

/* ─── Keyboard ESC ───────────────────────── */
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open,.confirm-overlay.open').forEach(el => el.classList.remove('open'));
  }
});

/* ─── Boot ───────────────────────────────── */
init();
</script>
</body>
</html>
