/* ═══════════════════════════════════════
   BOTTOM PANEL — DOM BUILD ONLY
   კატეგორიების ჩატვირთვა products.js-ში
   ხდება, სადაც ყველა ფუნქცია არსებობს.
═══════════════════════════════════════ */

/* ── 1. Build static DOM immediately ── */
const panel       = document.getElementById('bottom-panel');
const filterStrip = document.createElement('div'); filterStrip.id = 'filter-strip';
const stripHead   = document.createElement('div'); stripHead.className = 'strip-head';
stripHead.innerHTML = '<div class="strip-head-line"></div><span class="strip-head-label">კატეგორიები</span>';
const stripNav    = document.createElement('div'); stripNav.className = 'strip-nav';
const fPrev       = arrowBtn('left');
const fNext       = arrowBtn('right');
const fWrap       = document.createElement('div'); fWrap.id = 'f-wrap';
const fTrack      = document.createElement('div'); fTrack.id = 'f-track';
fWrap.appendChild(fTrack);
stripNav.append(fPrev, fWrap, fNext);
filterStrip.append(stripHead, stripNav);
panel.appendChild(filterStrip);

const floader    = document.createElement('div'); floader.id = 'floader';
floader.innerHTML = '<div class="spinner"></div>';
const prodHeader = document.createElement('div'); prodHeader.id = 'prod-header';
const prodScroll = document.createElement('div'); prodScroll.id = 'prod-scroll';
const cardsGrid  = document.createElement('div'); cardsGrid.id = 'cards-grid';
prodScroll.appendChild(cardsGrid);
panel.append(floader, prodHeader, prodScroll);

/* ── 2. Show skeleton immediately ── */
(function() {
    for (var i = 0; i < 6; i++) {
        var s = document.createElement('div');
        s.className = 'skel';
        s.style.animationDelay = (i * 0.08) + 's';
        s.innerHTML = '<div class="skel-img"></div><div class="sk-body"><div class="sk-line w35"></div><div class="sk-line w72"></div><div class="sk-line w50"></div></div>';
        cardsGrid.appendChild(s);
    }
}());

/* ═══════════════════════════════════════
   HERO / SLIDE LOGIC
═══════════════════════════════════════ */
var cur = 0, busy = false, autoTimer;
var N = SLIDES.length;
var TC_W = 108;

function setSlideContent(s) {
    heroStage.innerHTML = '<div class="h-badge">' + s.badge + '</div><h1 class="h-title">' + s.title + '</h1><p class="h-sub">' + s.sub + '</p><div class="h-row"><button class="btn-buy">' + s.cta1 + '</button><button class="btn-more">' + s.cta2 + '</button></div>';
    var row = heroStage.querySelector('.h-row');
    row.append(hSep, hPrev, hNext, cntEl);
    heroStage.appendChild(progWrap);
}
function refreshUI() {
    progFill.style.width = ((cur + 1) / N * 100) + '%';
    cntEl.innerHTML = '<strong>0' + (cur + 1) + '</strong>&thinsp;/&thinsp;0' + N;
    tTrack.querySelectorAll('.tc').forEach(function(c, i) { c.classList.toggle('active', i === cur); });
    var ww  = tWrap.offsetWidth;
    var off = Math.min(Math.max(cur * TC_W - ww / 2 + TC_W / 2, 0), Math.max(N * TC_W - ww, 0));
    tTrack.style.transform = 'translateX(-' + off + 'px)';
}
function goTo(idx, dir) {
    if (busy || idx === cur) return;
    busy = true;
    var old = cur; cur = idx;
    var d = (dir !== undefined) ? dir : (idx > old ? 1 : -1);
    bgLayers[old].classList.remove('active');
    bgLayers[old].classList.add(d === 1 ? 'exit-l' : 'exit-r');
    bgLayers[cur].style.transition = 'none';
    bgLayers[cur].style.opacity    = '0';
    bgLayers[cur].style.transform  = 'scale(1.06) translateX(' + (d === 1 ? '3%' : '-3%') + ')';
    bgLayers[cur].classList.remove('exit-l', 'exit-r', 'active');
    requestAnimationFrame(function() {
        requestAnimationFrame(function() {
            bgLayers[cur].style.transition = '';
            bgLayers[cur].style.opacity    = '';
            bgLayers[cur].style.transform  = '';
            bgLayers[cur].classList.add('active');
        });
    });
    heroStage.classList.remove('show');
    setSlideContent(SLIDES[cur]);
    requestAnimationFrame(function() { requestAnimationFrame(function() { heroStage.classList.add('show'); }); });
    setTimeout(function() { bgLayers[old].classList.remove('exit-l', 'exit-r'); busy = false; }, 1200);
    refreshUI();
    resetAuto();
}
function slideNext() { goTo((cur + 1) % N, 1); }
function slidePrev() { goTo((cur - 1 + N) % N, -1); }
function resetAuto()  { clearInterval(autoTimer); autoTimer = setInterval(slideNext, 5500); }

setSlideContent(SLIDES[0]);
requestAnimationFrame(function() { requestAnimationFrame(function() { heroStage.classList.add('show'); }); });
refreshUI();
resetAuto();

var tOff = 0;
tPrev.addEventListener('click', function() { tOff = Math.max(0, tOff - 1); tTrack.style.transform = 'translateX(-' + (tOff * TC_W) + 'px)'; });
tNext.addEventListener('click', function() { tOff = Math.min(N - 1, tOff + 1); tTrack.style.transform = 'translateX(-' + (tOff * TC_W) + 'px)'; });
var tx = 0;
hero.addEventListener('touchstart', function(e) { tx = e.touches[0].clientX; },                                                                                    { passive: true });
hero.addEventListener('touchend',   function(e) { var dx = tx - e.changedTouches[0].clientX; if (Math.abs(dx) > 50) { dx > 0 ? slideNext() : slidePrev(); } },     { passive: true });
