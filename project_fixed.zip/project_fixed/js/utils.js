/* ═══════════════════════════════════════
   UTILS
═══════════════════════════════════════ */
function arrowBtn(dir,big){
  const b=document.createElement('button');b.className='nbtn'+(big?' big':'');
  const p=dir==='left'?'15 18 9 12 15 6':'9 18 15 12 9 6';
  b.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="${p}"/></svg>`;
  return b;
}
function starsHTML(n){return Array.from({length:5},(_,i)=>`<svg class="star${i<n?' on':''}" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.86L12 17.77l-6.18 3.23L7 14.14 2 9.27l6.91-1.01z"/></svg>`).join('')}
function getCardStep(){const cs=getComputedStyle(document.documentElement);return(parseFloat(cs.getPropertyValue('--card-w'))||175)+(parseFloat(cs.getPropertyValue('--card-gap'))||10)}

