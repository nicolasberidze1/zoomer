/* ═══════════════════════════════════════
   EZZWAY — API HELPER
   Supports CSRF token for secure requests
═══════════════════════════════════════ */

// CSRF token — loaded on page start from me.php
let _csrfToken = null;

function setCsrfToken(token) {
  if (token) _csrfToken = token;
}

async function apiCall(url, method = 'GET', body = null) {
  const opts = {
    method,
    credentials: 'same-origin',
    headers: {},
  };

  // Attach CSRF token header on mutating requests
  if (_csrfToken && ['POST', 'PUT', 'DELETE'].includes(method)) {
    opts.headers['X-CSRF-Token'] = _csrfToken;
  }

  if (body instanceof FormData) {
    opts.body = body;
  } else if (body) {
    opts.headers['Content-Type'] = 'application/json';
    // Also embed in body as fallback
    if (_csrfToken && ['POST', 'PUT', 'DELETE'].includes(method)) {
      body.csrf_token = _csrfToken;
    }
    opts.body = JSON.stringify(body);
  }

  const res = await fetch(url, opts);
  return res.json();
}

// Fetch CSRF token on page load via me.php
(async () => {
  try {
    const r = await fetch('api/me.php', { credentials: 'same-origin' });
    const data = await r.json();
    if (data.success && data.data?.csrf_token) {
      _csrfToken = data.data.csrf_token;
    }
  } catch (e) {}
})();

