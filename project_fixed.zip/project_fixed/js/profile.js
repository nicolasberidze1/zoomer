/* ═══════════════════════════════════════
   CART (profile view)
═══════════════════════════════════════ */
function renderCartInProfile() {
  const listEl = document.getElementById('prof-cart-list');
  const emptyEl = document.getElementById('prof-cart-empty');
  const footerEl = document.getElementById('prof-cart-footer');
  const totalEl = document.getElementById('prof-cart-total');

  listEl.querySelectorAll('.prof-cart-item').forEach(el=>el.remove());

  if(!cartItems || cartItems.length === 0) {
    emptyEl.style.display = 'flex';
    footerEl.style.display = 'none';
    return;
  }

  emptyEl.style.display = 'none';
  footerEl.style.display = 'block';

  let total = 0;
  cartItems.forEach(item => {
    const price = parseFloat(String(item.price).replace(/[^\d.]/g, '')) || 0;
    const qty = item.qty || 1;
    total += price * qty;

    const div = document.createElement('div');
    div.className = 'prof-cart-item';
    div.innerHTML = `
      <div class="pci-img">
        ${item.img ? `<img src="${item.img}" alt="">` : '<span style="font-size:20px">📦</span>'}
      </div>
      <div class="pci-info">
        <div class="pci-name">${item.name}</div>
        <div class="pci-qty">რაოდ: ${qty}</div>
      </div>
      <div class="pci-right">
        <div class="pci-price">${(price*qty).toFixed(0)} ₾</div>
        <button class="pci-remove" data-id="${item.id}" title="წაშლა">✕</button>
      </div>`;
    listEl.appendChild(div);
  });

  totalEl.textContent = '₾' + total.toFixed(0);

  // Remove handlers
  listEl.querySelectorAll('.pci-remove').forEach(btn=>{
    btn.addEventListener('click', async ()=>{
      const itemId = btn.dataset.id;
      try {
        const res = await apiCall('api/cart.php', 'DELETE', {id: itemId});
        if(res.success){
          cartItems = res.data;
          updateCartBadge();
          renderCartInProfile();
          if(currentUser){ currentUser.cart = cartItems; renderProfile(currentUser); }
        }
      } catch(e){ showToast('შეცდომა', '❗'); }
    });
  });
}

/* load cart from server */
async function loadCart() {
  if(!currentUser) return;
  try {
    const res = await apiCall('api/cart.php');
    if(res.success){
      cartItems = res.data || [];
      updateCartBadge();
      renderCartInProfile();
      if(currentUser){ document.getElementById('prof-cart-cnt').textContent = cartItems.length; }
    }
  } catch(e){}
}

/* add product to cart */
async function addToCart(product) {
  if(!currentUser){ showToast('კალათაში დასამატებლად შედი ანგარიშში 👤','👤'); openModal('modal-login'); return; }
  try {
    const res = await apiCall('api/cart.php', 'POST', {
      name: product.name, price: String(product.price), img: product.img||'', cat: product.cat||''
    });
    if(res.success){
      cartItems = res.data;
      updateCartBadge();
      showToast(product.name + ' კალათაში დაემატა! 🛒','🛒');
      if(currentUser){ document.getElementById('prof-cart-cnt').textContent = cartItems.length; document.getElementById('menu-cart-sub').textContent=cartItems.length+' პროდუქტი'; const b=document.getElementById('prof-cart-badge');if(b)b.textContent=cartItems.length; }
    } else {
      showToast(res.error||'შეცდომა','❗');
    }
  } catch(e){ showToast('კავშირის შეცდომა ❗','❗'); }
}

/* ═══════════════════════════════════════
   PROFILE TABS
═══════════════════════════════════════ */
document.querySelectorAll('.prof-tab').forEach(btn=>{
  btn.addEventListener('click',()=>{
    const tab = btn.dataset.tab;
    document.querySelectorAll('.prof-tab').forEach(b=>b.classList.remove('active'));
    document.querySelectorAll('.prof-tab-pane').forEach(p=>p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('ptab-'+tab).classList.add('active');
    if(tab==='cart') renderCartInProfile();
  });
});

/* menu item shortcuts */
document.getElementById('menu-cart-item').addEventListener('click',()=>{
  document.querySelector('[data-tab="cart"]').click();
});
document.getElementById('menu-edit-item').addEventListener('click',()=>{
  document.querySelector('[data-tab="edit"]').click();
});

/* ═══════════════════════════════════════
   PROFILE: PHOTO UPLOAD
═══════════════════════════════════════ */
document.getElementById('photo-file-input').addEventListener('change', async function(){
  const file = this.files[0];
  if(!file) return;
  if(file.size > 5*1024*1024){ showToast('ფოტო 5MB-ზე მეტი არ უნდა იყოს ❗','❗'); return; }
  const fd = new FormData();
  fd.append('photo', file);
  showToast('ფოტო იტვირთება...','⏳');
  try {
    const res = await apiCall('api/upload_photo.php','POST', fd);
    if(res.success){
      if(currentUser){ currentUser.photo = res.data.photoUrl; }
      const profPhoto = document.getElementById('prof-photo');
      profPhoto.src = res.data.photoUrl + '?t=' + Date.now();
      profPhoto.style.display = 'block';
      document.getElementById('prof-initial').style.display = 'none';
      showToast('ფოტო განახლდა! ✅');
    } else {
      showToast(res.error||'ატვირთვა ვერ მოხერხდა ❗','❗');
    }
  } catch(e){
    showToast('კავშირის შეცდომა ❗','❗');
  }
  this.value='';
});

/* ═══════════════════════════════════════
   PROFILE: EDIT SAVE
═══════════════════════════════════════ */
document.getElementById('edit-save-btn').addEventListener('click', async ()=>{
  const fname = document.getElementById('edit-fname').value.trim();
  const lname = document.getElementById('edit-lname').value.trim();
  const phone = document.getElementById('edit-phone').value.trim();
  const bio = document.getElementById('edit-bio').value.trim();
  if(!fname||!lname){ showToast('სახელი და გვარი სავალდებულოა ❗','❗'); return; }

  setBtnLoading('edit-save-btn',true);
  try {
    const res = await apiCall('api/profile.php','POST',{firstName:fname,lastName:lname,phone,bio});
    if(res.success){
      currentUser = res.data;
      renderProfile(res.data);
      showToast('პროფილი განახლდა! ✅');
    } else {
      showToast(res.error,'❗');
    }
  } catch(e){ showToast('კავშირის შეცდომა ❗','❗'); }
  setBtnLoading('edit-save-btn',false,'შენახვა');
});

/* ═══════════════════════════════════════
   PROFILE: CHANGE PASSWORD
═══════════════════════════════════════ */
document.getElementById('edit-pass-btn').addEventListener('click', async ()=>{
  const cur = document.getElementById('edit-cur-pass').value;
  const newP = document.getElementById('edit-new-pass').value;
  if(!cur||!newP){ showToast('შეავსე პაროლის ველები ❗','❗'); return; }
  if(newP.length<8){ showToast('ახალი პაროლი მინ. 8 სიმბოლო ❗','❗'); return; }

  setBtnLoading('edit-pass-btn',true);
  try {
    const res = await apiCall('api/profile.php','POST',{currentPassword:cur, newPassword:newP});
    if(res.success){
      document.getElementById('edit-cur-pass').value='';
      document.getElementById('edit-new-pass').value='';
      showToast('პაროლი შეიცვალა! 🔐','🔐');
    } else {
      showToast(res.error,'❗');
    }
  } catch(e){ showToast('კავშირის შეცდომა ❗','❗'); }
  setBtnLoading('edit-pass-btn',false,'პაროლის განახლება');
});

