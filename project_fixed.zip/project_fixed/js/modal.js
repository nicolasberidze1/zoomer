/* ═══════════════════════════════════════
   MODAL SYSTEM
═══════════════════════════════════════ */
function openModal(id){
  document.getElementById(id).classList.add('open');
  document.body.style.overflow='hidden';
}
function closeModal(id){
  document.getElementById(id).classList.remove('open');
  document.body.style.overflow='';
}
function closeAllModals(){
  ['modal-login','modal-register','modal-profile','modal-payment'].forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.classList.remove('open');
  });
  document.body.style.overflow='';
}

['modal-login','modal-register','modal-profile'].forEach(id=>{
  document.getElementById(id).addEventListener('click',e=>{
    if(e.target===document.getElementById(id))closeModal(id);
  });
});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeAllModals()});
document.getElementById('close-login').addEventListener('click',()=>closeModal('modal-login'));
document.getElementById('close-register').addEventListener('click',()=>closeModal('modal-register'));
document.getElementById('close-profile').addEventListener('click',()=>closeModal('modal-profile'));

document.getElementById('hdr-login-btn').addEventListener('click',()=>openModal('modal-login'));
document.getElementById('hdr-reg-btn').addEventListener('click',()=>openModal('modal-register'));
document.getElementById('mob-login-btn').addEventListener('click',()=>{mobileMenu.classList.remove('open');burger.classList.remove('open');openModal('modal-login')});
document.getElementById('mob-reg-btn').addEventListener('click',()=>{mobileMenu.classList.remove('open');burger.classList.remove('open');openModal('modal-register')});
document.getElementById('hdr-avatar').addEventListener('click',()=>openModal('modal-profile'));

document.getElementById('switch-to-reg').addEventListener('click',()=>{closeModal('modal-login');openModal('modal-register')});
document.getElementById('switch-to-reg2').addEventListener('click',()=>{closeModal('modal-login');openModal('modal-register')});
document.getElementById('switch-to-login').addEventListener('click',()=>{closeModal('modal-register');openModal('modal-login')});

/* password toggle */
function togglePass(inputId,btnId){
  document.getElementById(btnId).addEventListener('click',()=>{
    const inp=document.getElementById(inputId);
    inp.type=inp.type==='password'?'text':'password';
  });
}
togglePass('login-pass','toggle-login-pass');
togglePass('reg-pass','toggle-reg-pass');

/* password strength */
document.getElementById('reg-pass').addEventListener('input',function(){
  const val=this.value;
  const bars=[document.getElementById('pb1'),document.getElementById('pb2'),document.getElementById('pb3'),document.getElementById('pb4')];
  const label=document.getElementById('pw-label');
  bars.forEach(b=>{b.className='pw-bar'});
  if(val.length===0){label.textContent='პაროლი შეიყვანე';label.style.color='';return;}
  let score=0;
  if(val.length>=8)score++;
  if(/[A-Z]/.test(val))score++;
  if(/[0-9]/.test(val))score++;
  if(/[^A-Za-z0-9]/.test(val))score++;
  const classes=['weak','weak','medium','strong'];
  const labels=['სუსტი','სუსტი','საშუალო','ძლიერი'];
  const colors=['#ff4d4d','#ff4d4d','#ffb400','#4cff72'];
  for(let i=0;i<score;i++)bars[i].className='pw-bar '+classes[i];
  label.textContent=labels[score-1]||'სუსტი';
  label.style.color=colors[score-1]||'#ff4d4d';
});

/* toast helper */
let toastTimer;
function showToast(msg,icon='✅'){
  const t=document.getElementById('toast');
  t.querySelector('.t-icon').textContent=icon;
  t.querySelector('.t-msg').textContent=msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>t.classList.remove('show'),3200);
}

/* btn loading state */
function setBtnLoading(id, loading, originalText=''){
  const btn = document.getElementById(id);
  if(!btn) return;
  if(loading){
    btn.dataset.origText = btn.textContent;
    btn.textContent = '...';
    btn.disabled = true;
  } else {
    btn.textContent = originalText || btn.dataset.origText || btn.textContent;
    btn.disabled = false;
  }
}

