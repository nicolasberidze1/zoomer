/* ═══════════════════════════════════════
   STICKY HEADER
═══════════════════════════════════════ */
const siteHeader=document.getElementById('site-header');
const heroEl=document.getElementById('hero');

function updateHeaderSticky(){
  const heroBottom=heroEl.getBoundingClientRect().bottom;
  if(heroBottom<=0){siteHeader.classList.add('sticky')}
  else{siteHeader.classList.remove('sticky')}
}
window.addEventListener('scroll',updateHeaderSticky,{passive:true});
updateHeaderSticky();

/* ═══════════════════════════════════════
   HAMBURGER
═══════════════════════════════════════ */
const burger=document.getElementById('hdr-burger');
const mobileMenu=document.getElementById('mobile-menu');
burger.addEventListener('click',()=>{
  const open=mobileMenu.classList.toggle('open');
  burger.classList.toggle('open',open);
});
window.addEventListener('scroll',()=>{
  if(mobileMenu.classList.contains('open')){
    mobileMenu.classList.remove('open');
    burger.classList.remove('open');
  }
},{passive:true});

