/* ═══════════════════════════════════════
   FILTER + CARDS + CATS INIT
   
   ეს ფაილი ჩაიტვირთება bottom.js-ის
   შემდეგ, ამიტომ ყველა DOM ელემენტი
   (fTrack, cardsGrid, etc.) უკვე არსებობს.
   
   CATS-ის ჩატვირთვა აქ ხდება — Promise
   callback-ი აქ რეგისტრირდება, სადაც
   renderProducts() ფუნქციაც განსაზღვრულია.
═══════════════════════════════════════ */

var activeFi = 0;
var cStep    = 0;
var fOff     = 0;
var FC_W     = 96;

/* ── Card helpers ── */
function visibleCards() {
    return Math.max(1, Math.floor(prodScroll.clientWidth / getCardStep()));
}

function moveCards(step) {
    if (!CATS[activeFi]) return;
    var maxStep = Math.max(0, CATS[activeFi].products.length - visibleCards());
    cStep = maxStep === 0 ? 0 : ((step % (maxStep + 1)) + (maxStep + 1)) % (maxStep + 1);
    cardsGrid.style.transition = 'transform .42s cubic-bezier(.4,0,.2,1)';
    cardsGrid.style.transform  = 'translateX(-' + (cStep * getCardStep()) + 'px)';
}

function buildCardsNav() {
    var cPrev = arrowBtn('left');
    var cNext = arrowBtn('right');
    cPrev.addEventListener('click', function() { moveCards(cStep - 1); });
    cNext.addEventListener('click', function() { moveCards(cStep + 1); });
    var nav = document.createElement('div');
    nav.className = 'cards-nav';
    nav.append(cPrev, cNext);
    return nav;
}

function renderProducts(catIdx) {
    var cat = CATS[catIdx];
    if (!cat) return;
    cStep = 0;

    prodHeader.innerHTML       = '';
    cardsGrid.style.transition = 'none';
    cardsGrid.style.transform  = '';
    cardsGrid.innerHTML        = '';

    var titleEl = document.createElement('h3');
    titleEl.className = 'prod-title';
    titleEl.innerHTML = 'პროდუქცია <span>' + cat.label + '</span>';

    var countEl = document.createElement('span');
    countEl.className   = 'prod-count';
    countEl.textContent = cat.products.length + ' პროდუქტი';

    var rightEl = document.createElement('div');
    rightEl.className = 'prod-right';
    rightEl.append(countEl, buildCardsNav());

    prodHeader.append(titleEl, rightEl);

    cat.products.forEach(function(p, i) {
        var c = document.createElement('div');
        c.className = 'pc';
        c.style.animationDelay = (i * 0.06) + 's';
        c.innerHTML =
            '<div class="pc-img">' +
                (p.badge ? '<span class="pc-badge">' + p.badge + '</span>' : '') +
                '<img src="' + p.img + '" alt="' + p.name + '" loading="lazy">' +
            '</div>' +
            '<div class="pc-body">' +
                '<div class="pc-cat">'   + cat.label  + '</div>' +
                '<div class="pc-name">'  + p.name     + '</div>' +
                '<div class="pc-stars">' + starsHTML(p.rating) + '<span class="pc-rv">(' + p.reviews + ')</span></div>' +
                '<div class="pc-desc">'  + p.desc     + '</div>' +
                '<div class="pc-foot">' +
                    '<div class="pc-price">' + p.price + ' <sub>GEL</sub></div>' +
                    '<button class="add-btn" title="კალათა">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
                            '<path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/>' +
                            '<line x1="3" y1="6" x2="21" y2="6"/>' +
                            '<path d="M16 10a4 4 0 01-8 0"/>' +
                        '</svg>' +
                    '</button>' +
                '</div>' +
            '</div>';

        c.querySelector('.add-btn').addEventListener('click', function() {
            addToCart({ name: p.name, price: p.price, img: p.img, cat: cat.label });
        });
        cardsGrid.appendChild(c);
    });
}

function showSkeleton() {
    cStep = 0;
    prodHeader.innerHTML       = '';
    cardsGrid.style.transition = 'none';
    cardsGrid.style.transform  = '';
    cardsGrid.innerHTML        = '';
    for (var i = 0; i < 6; i++) {
        var s = document.createElement('div');
        s.className            = 'skel';
        s.style.animationDelay = (i * 0.08) + 's';
        s.innerHTML = '<div class="skel-img"></div><div class="sk-body"><div class="sk-line w35"></div><div class="sk-line w72"></div><div class="sk-line w50"></div></div>';
        cardsGrid.appendChild(s);
    }
}

function activateFilter(idx, el) {
    if (activeFi === idx) return;
    floader.classList.add('on');
    showSkeleton();
    fTrack.querySelectorAll('.fc').forEach(function(c) { c.classList.remove('active'); });
    el.classList.add('active');
    activeFi = idx;
    setTimeout(function() {
        floader.classList.remove('on');
        renderProducts(idx);
    }, 400);
}

/* ── Build category chips ── */
function buildCategoryChips(cats) {
    fTrack.innerHTML = '';
    cats.forEach(function(cat, i) {
        var c = document.createElement('div');
        c.className = 'fc' + (i === 0 ? ' active' : '');
        c.innerHTML = '<img src="' + cat.img + '" alt="' + cat.label + '" loading="lazy"><span class="fc-label">' + cat.label + '</span>';
        c.addEventListener('click', function() { activateFilter(i, c); });
        fTrack.appendChild(c);
    });
}

/* ── Register scroll arrow listeners (called once) ── */
function bindScrollArrows() {
    fPrev.addEventListener('click', function() {
        var vis = Math.max(1, Math.floor(fWrap.offsetWidth / FC_W));
        var max = Math.max(0, CATS.length - vis);
        fOff = (fOff <= 0) ? max : fOff - 1;
        fTrack.style.transform = 'translateX(-' + (fOff * FC_W) + 'px)';
    });
    fNext.addEventListener('click', function() {
        var vis = Math.max(1, Math.floor(fWrap.offsetWidth / FC_W));
        var max = Math.max(0, CATS.length - vis);
        fOff = (fOff >= max) ? 0 : fOff + 1;
        fTrack.style.transform = 'translateX(-' + (fOff * FC_W) + 'px)';
    });
}

/* ══════════════════════════════════════════════════
   CATS INIT — ჩაიტვირთება ამ ფაილის parse-ის შემდეგ.
   Promise .then() callback-ი ყოველთვის async არის,
   ანუ გაეშვება event loop-ის შემდეგ რაუნდში —
   მაგრამ ამ დროს ეს ფაილი უკვე სრულად parse-ულია
   და renderProducts() ფუნქცია კი არსებობს.
══════════════════════════════════════════════════ */
window.__catsPromise.then(function(cats) {
    if (!Array.isArray(cats) || cats.length === 0) {
        cardsGrid.innerHTML  = '';
        prodHeader.innerHTML = '<p style="color:var(--muted);padding:14px 12px;font-size:13px">პროდუქტები ვერ ჩაიტვირთა. გადატვირთეთ გვერდი.</p>';
        return;
    }
    buildCategoryChips(cats);
    bindScrollArrows();
    renderProducts(0);
});

/* ── Page loader ── */
window.addEventListener('load', function() {
    setTimeout(function() {
        var loader = document.getElementById('loader');
        if (loader) loader.classList.add('gone');
    }, 1200);
});
