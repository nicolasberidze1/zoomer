/* ═══════════════════════════════════════
   GOOGLE SIGN-IN
═══════════════════════════════════════ */
function initGoogleAuth(){
  if(typeof google==='undefined'||!google.accounts) return;
  const clientId = window.GOOGLE_CLIENT_ID;
  if(!clientId) return;
  google.accounts.id.initialize({
    client_id: clientId,
    callback: async (response)=>{
      try {
        const res = await apiCall('api/google_auth.php','POST',{credential:response.credential});
        if(res.success){
          closeAllModals();
          await loadCart();
          setLoggedIn(res.data);
          showToast('Google-ით შესვლა წარმატებულია! 🎉','🎉');
        } else {
          showToast(res.error,'❗');
        }
      } catch(e){ showToast('Google შეცდომა ❗','❗'); }
    }
  });
}

document.getElementById('google-gsi').addEventListener('load', initGoogleAuth);

// Google buttons click
document.querySelectorAll('.btn-social').forEach(btn=>{
  if(btn.textContent.trim()==='Google'){
    btn.addEventListener('click',()=>{
      if(typeof google==='undefined'||!google.accounts){
        showToast('Google SDK ჯერ არ ჩაიტვირთა ❗','❗'); return;
      }
      google.accounts.id.prompt((notification)=>{
        if(notification.isSkippedMoment()||notification.isDismissedMoment()){
          showToast('Google შესვლა გაუქმდა','ℹ️');
        }
      });
    });
  }
  if(btn.textContent.trim()==='Facebook'){
    btn.addEventListener('click',()=>{
      if(!window._fbReady){ showToast('Facebook SDK ჯერ არ ჩაიტვირთა, ცოტა მოიცადე ❗','❗'); return; }
      FB.login((response)=>{
        if(response.authResponse){
          apiCall('api/facebook_auth.php','POST',{
            accessToken: response.authResponse.accessToken,
            userID: response.authResponse.userID
          }).then(res=>{
            if(res.success){
              closeAllModals();
              loadCart().then(()=>{ setLoggedIn(res.data); showToast('Facebook-ით შესვლა წარმატებულია! 🎉','🎉'); });
            } else { showToast(res.error,'❗'); }
          }).catch(()=>showToast('Facebook შეცდომა ❗','❗'));
        } else {
          showToast('Facebook შესვლა გაუქმდა','ℹ️');
        }
      },{scope:'email,public_profile'});
    });
  }
});

