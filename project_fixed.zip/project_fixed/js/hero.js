/* ═══════════════════════════════════════
   HERO BUILD
═══════════════════════════════════════ */
const hero=document.getElementById('hero');
const bgLayers=SLIDES.map((s,i)=>{
  const d=document.createElement('div');d.className='sl-bg'+(i===0?' active':'');
  d.style.backgroundImage=`url('${s.bg}')`;hero.appendChild(d);return d;
});
const thumbRow=document.createElement('div');thumbRow.id='thumb-row';
const tPrev=arrowBtn('left'),tNext=arrowBtn('right');
const tWrap=document.createElement('div');tWrap.id='t-wrap';
const tTrack=document.createElement('div');tTrack.id='t-track';
tWrap.appendChild(tTrack);thumbRow.append(tPrev,tWrap,tNext);hero.appendChild(thumbRow);
SLIDES.forEach((s,i)=>{
  const c=document.createElement('div');c.className='tc'+(i===0?' active':'');
  c.innerHTML=`<img src="${s.bg}" alt="" loading="lazy"><span class="tc-num">0${i+1}</span>`;
  c.addEventListener('click',()=>goTo(i));tTrack.appendChild(c);
});
const heroStage=document.createElement('div');heroStage.id='hero-stage';
const progWrap=document.createElement('div');progWrap.id='hero-progress';
const progFill=document.createElement('div');progFill.id='hero-progress-fill';
progWrap.appendChild(progFill);heroStage.appendChild(progWrap);hero.appendChild(heroStage);
const hPrev=arrowBtn('left',true),hNext=arrowBtn('right',true);
const cntEl=document.createElement('span');cntEl.className='h-counter';
const hSep=document.createElement('span');hSep.className='h-sep';
hPrev.addEventListener('click',slidePrev);hNext.addEventListener('click',slideNext);

