/* ═══════════════════════════════════════
   USER STATE & PROFILE RENDERING
═══════════════════════════════════════ */
let currentUser = null;
let cartItems = [];

/* update header cart badge */
function updateCartBadge(){
  const count = cartItems.length;
  document.querySelectorAll('.nav-badge').forEach(el=>{
    if(el.closest('.hdr-nav') || el.closest('#mobile-menu')) el.textContent=count;
  });
}

/* render user data into profile modal */
function renderProfile(user) {
  if(!user) return;
  currentUser = user;

  const fullName = user.firstName + ' ' + user.lastName;
  const initial = user.firstName ? user.firstName.charAt(0).toUpperCase() : '?';

  // Header avatar
  document.getElementById('avatar-initial').textContent = initial;
  document.getElementById('hdr-avatar').style.backgroundImage = user.photo ? `url(${user.photo})` : '';

  // Profile top
  const profPhotoEl = document.getElementById('prof-photo');
  const profInitialEl = document.getElementById('prof-initial');
  if(user.photo) {
    profPhotoEl.src = user.photo;
    profPhotoEl.style.display = 'block';
    profInitialEl.style.display = 'none';
  } else {
    profPhotoEl.style.display = 'none';
    profInitialEl.style.display = 'flex';
    profInitialEl.textContent = initial;
  }

  document.getElementById('prof-name').textContent = fullName;
  document.getElementById('prof-email').textContent = user.email;

  // Meta (phone)
  const metaEl = document.getElementById('prof-meta');
  metaEl.innerHTML = user.phone ? `<span class="prof-phone">📞 ${user.phone}</span>` : '';

  // Provider badge
  const provBadge = document.getElementById('prof-provider-badge');
  if(user.provider && user.provider !== 'email'){
    provBadge.style.display = '';
    provBadge.textContent = user.provider === 'google' ? '🔵 Google' : '🔷 Facebook';
    provBadge.className = 'p-badge tech';
  } else {
    provBadge.style.display = 'none';
  }

  // Stats
  const orders = user.orders || [];
  const spent = user.totalSpent || 0;
  document.getElementById('prof-orders-cnt').textContent = orders.length;
  document.getElementById('prof-spent').textContent = '₾' + (spent >= 1000 ? (spent/1000).toFixed(1)+'K' : spent);
  document.getElementById('prof-cart-cnt').textContent = cartItems.length;

  // Sub-labels in menu
  document.getElementById('menu-cart-sub').textContent = cartItems.length + ' პროდუქტი';
  document.getElementById('menu-orders-sub').textContent = orders.length + ' შეკვეთა';

  // Bio block
  const bioBlock = document.getElementById('prof-bio-block');
  const bioText = document.getElementById('prof-bio-text');
  if(user.bio) {
    bioBlock.style.display = 'block';
    bioText.textContent = user.bio;
  } else {
    bioBlock.style.display = 'none';
  }

  // Edit form prefill
  document.getElementById('edit-fname').value = user.firstName || '';
  document.getElementById('edit-lname').value = user.lastName || '';
  document.getElementById('edit-phone').value = user.phone || '';
  document.getElementById('edit-bio').value = user.bio || '';

  // Cart badge on tab
  const cartBadgeEl = document.getElementById('prof-cart-badge');
  if(cartBadgeEl) cartBadgeEl.textContent = cartItems.length;
}

function setLoggedIn(user) {
  currentUser = user;
  document.getElementById('hdr-avatar').classList.add('active');
  document.getElementById('hdr-login-btn').style.display = 'none';
  document.getElementById('hdr-reg-btn').style.display = 'none';
  const mobAuth = document.getElementById('mob-auth-btns');
  mobAuth.innerHTML = `<button class="btn-login" style="flex:1" onclick="mobileMenu.classList.remove('open');burger.classList.remove('open');openModal('modal-profile')">პროფილი</button>`;
  renderProfile(user);
  renderCartInProfile();
  // NexChat: show FAB and notify chat system
  const fab = document.getElementById('nxc-fab');
  if(fab) fab.style.display = 'flex';
  window.dispatchEvent(new CustomEvent('nxcAuthReady', { detail: user }));
}

function setLoggedOut() {
  currentUser = null;
  cartItems = [];
  document.getElementById('hdr-avatar').classList.remove('active');
  document.getElementById('hdr-avatar').style.backgroundImage = '';
  document.getElementById('hdr-login-btn').style.display = '';
  document.getElementById('hdr-reg-btn').style.display = '';
  const mobAuth = document.getElementById('mob-auth-btns');
  mobAuth.innerHTML = `<button class="btn-login" id="mob-login-btn">შესვლა</button><button class="btn-register" id="mob-reg-btn">რეგისტრაცია</button>`;
  document.getElementById('mob-login-btn').addEventListener('click',()=>{mobileMenu.classList.remove('open');burger.classList.remove('open');openModal('modal-login')});
  document.getElementById('mob-reg-btn').addEventListener('click',()=>{mobileMenu.classList.remove('open');burger.classList.remove('open');openModal('modal-register')});
  updateCartBadge();
  // NexChat: hide FAB when logged out
  const fab = document.getElementById('nxc-fab');
  if(fab) fab.style.display = 'none';
}

/* ═══════════════════════════════════════
   AUTH: LOGIN
═══════════════════════════════════════ */
document.getElementById('login-submit').addEventListener('click', async ()=>{
  const email = document.getElementById('login-email').value.trim();
  const pass = document.getElementById('login-pass').value;
  const remember = document.getElementById('remember-me').checked;
  if(!email||!pass){ showToast('შეავსე ყველა ველი ❗','❗'); return; }
  if(!/\S+@\S+\.\S+/.test(email)){ showToast('ელ-ფოსტა არასწორია ❗','❗'); return; }

  setBtnLoading('login-submit', true);
  try {
    const res = await apiCall('api/login.php','POST',{email, password:pass, remember});
    if(res.success){
      // Save CSRF token from response
      if(res.data?.csrf_token) setCsrfToken(res.data.csrf_token);
      closeModal('modal-login');
      document.getElementById('login-email').value='';
      document.getElementById('login-pass').value='';
      await loadCart();
      setLoggedIn(res.data);
      showToast('კეთილი იყოს დაბრუნება, '+res.data.firstName+'! 👋');
    } else {
      showToast(res.error,'❗');
    }
  } catch(e){
    showToast('კავშირის შეცდომა ❗','❗');
  }
  setBtnLoading('login-submit', false, 'შესვლა');
});

/* ═══════════════════════════════════════
   AUTH: REGISTER
═══════════════════════════════════════ */
document.getElementById('reg-submit').addEventListener('click', async ()=>{
  const fname = document.getElementById('reg-fname').value.trim();
  const lname = document.getElementById('reg-lname').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const pass = document.getElementById('reg-pass').value;
  const agree = document.getElementById('agree-terms').checked;
  if(!fname||!lname||!email||!pass){ showToast('შეავსე ყველა ველი ❗','❗'); return; }
  if(!agree){ showToast('დაეთანხმე პირობებს ❗','❗'); return; }
  if(pass.length<8){ showToast('პაროლი მინ. 8 სიმბოლო ❗','❗'); return; }

  setBtnLoading('reg-submit', true);
  try {
    const res = await apiCall('api/register.php','POST',{firstName:fname, lastName:lname, email, password:pass});
    if(res.success){
      // Save CSRF token
      if(res.data?.csrf_token) setCsrfToken(res.data.csrf_token);
      closeModal('modal-register');
      document.getElementById('reg-fname').value='';
      document.getElementById('reg-lname').value='';
      document.getElementById('reg-email').value='';
      document.getElementById('reg-pass').value='';
      document.getElementById('agree-terms').checked=false;
      await loadCart();
      setLoggedIn(res.data);
      showToast('ანგარიში შეიქმნა! გამარჯობა, '+res.data.firstName+'! ✨','✨');
    } else {
      showToast(res.error,'❗');
    }
  } catch(e){
    showToast('კავშირის შეცდომა ❗','❗');
  }
  setBtnLoading('reg-submit', false, 'ანგარიშის შექმნა');
});

/* ═══════════════════════════════════════
   AUTH: LOGOUT
═══════════════════════════════════════ */
document.getElementById('btn-logout').addEventListener('click', async ()=>{
  closeModal('modal-profile');
  try { await apiCall('api/logout.php','POST'); } catch(e){}
  setLoggedOut();
  showToast('გამოხვედი სისტემიდან 👋','👋');
});

/* ═══════════════════════════════════════
   PAGE LOAD: CHECK SESSION
═══════════════════════════════════════ */
(async ()=>{
  try {
    const res = await apiCall('api/profile.php');
    if(res.success && res.data){
      await loadCart();
      setLoggedIn(res.data);
      // Show admin panel button if role is editor+
      const role = res.data.role || 'user';
      const roleLevels = {admin:4,moderator:3,editor:2,user:1,guest:0};
      if((roleLevels[role]||0) >= 2){
        renderAdminPanelBtn(role);
      }
    }
  } catch(e){}
})();

/* ═══════════════════════════════════════
   ADMIN PANEL SHORTCUT IN PROFILE
═══════════════════════════════════════ */
function renderAdminPanelBtn(role) {
  const roleLabels = {admin:'Admin',moderator:'Moderator',editor:'Editor',user:'User',guest:'Guest'};
  const colors = {admin:'rgba(239,68,68,.15)',moderator:'rgba(245,158,11,.15)',editor:'rgba(59,130,246,.15)'};
  const textColors = {admin:'#ff8080',moderator:'#fbbf24',editor:'#60a5fa'};

  // Badge in profile top area
  const badges = document.querySelector('.profile-badges');
  if(badges && !document.getElementById('role-badge-el')){
    const roleBadge = document.createElement('span');
    roleBadge.id = 'role-badge-el';
    roleBadge.className = 'p-badge tech';
    roleBadge.style.cssText = `background:${colors[role]||'rgba(124,92,252,.15)'};color:${textColors[role]||'#a78bfa'};border:1px solid ${textColors[role]||'#a78bfa'}33`;
    roleBadge.textContent = '🛡️ ' + (roleLabels[role]||role);
    badges.appendChild(roleBadge);
  }

  // Admin panel menu item
  const menuLogout = document.getElementById('btn-logout');
  if(menuLogout && !document.getElementById('admin-panel-menu-item')){
    const adminItem = document.createElement('a');
    adminItem.id = 'admin-panel-menu-item';
    adminItem.href = 'admin/';
    adminItem.target = '_blank';
    adminItem.className = 'profile-menu-item';
    adminItem.style.cssText = 'display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:10px;cursor:pointer;text-decoration:none;background:rgba(124,92,252,.08);border:1px solid rgba(124,92,252,.2);margin-bottom:8px';
    adminItem.innerHTML = `
      <div class="pmi-icon" style="background:rgba(124,92,252,.15);color:#a78bfa">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
      </div>
      <div class="pmi-text">
        <div class="pmi-title" style="color:#a78bfa">⚡ Admin Panel</div>
        <div class="pmi-sub">${roleLabels[role]||role} წვდომა</div>
      </div>
      <span class="pmi-arrow" style="color:#a78bfa">›</span>`;
    menuLogout.parentNode.insertBefore(adminItem, menuLogout);
  }
}

