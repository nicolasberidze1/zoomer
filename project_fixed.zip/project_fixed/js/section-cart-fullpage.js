/* ═══════════════════════════════════════════════════════════════════
   SECTION CART + FULLPAGE PRODUCT VIEW
   - კალათის ღილაკები ყველა section-ში
   - Fullpage product viewer ყველა card-ისთვის
═══════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  /* ── Card configs: section cards → selector mappings ── */
  var CARD_CONFIGS = [
    // Hero filter cards (.pc class)
    { cardSel: '.pc',              btnSel: '.add-btn',            nameSel: '.pc-name',             priceSel: '.pc-price',             descSel: '.pc-desc',             catSel: '.pc-cat',           starsSel: '.pc-stars' },
    // Headphones
    { cardSel: '.sonic-pod',       btnSel: '.sonic-add-btn',      nameSel: '.sonic-pod-name',      priceSel: '.sonic-pod-price',      descSel: '.sonic-pod-desc',      catSel: '.sonic-pod-cat',    starsSel: '.sonic-pod-stars',      cat: 'ყურსასმენები' },
    // Laptops
    { cardSel: '.ultrabook-tile',  btnSel: '.ultrabook-tile-btn', nameSel: '.ultrabook-tile-name', priceSel: '.ultrabook-tile-price', descSel: '.ultrabook-tile-desc', starsSel: '.ultrabook-tile-stars', cat: 'ლეპტოპები' },
    // Computers
    { cardSel: '.rig-unit',        btnSel: '.rig-unit-btn',       nameSel: '.rig-unit-name',       priceSel: '.rig-unit-price',       descSel: '.rig-unit-desc',       starsSel: '.rig-unit-stars',       cat: 'კომპიუტერები' },
    // Gaming
    { cardSel: '.arena-slot',      btnSel: '.arena-slot-btn',     nameSel: '.arena-slot-name',     priceSel: '.arena-slot-price',     descSel: '.arena-slot-desc',     starsSel: '.arena-slot-stars',     cat: 'გეიმინგი' },
    // Keyboard
    { cardSel: '.keystroke-piece', btnSel: '.keystroke-piece-btn',nameSel: '.keystroke-piece-name',priceSel: '.keystroke-piece-price',descSel: '.keystroke-piece-desc',starsSel: '.keystroke-piece-stars',cat: 'კლავიატურა' },
    // Monitor
    { cardSel: '.screen-frame',    btnSel: '.screen-frame-btn',   nameSel: '.screen-frame-name',   priceSel: '.screen-frame-price',   descSel: '.screen-frame-desc',   starsSel: '.screen-frame-stars',   cat: 'მონიტორი' },
    // Mouse
    { cardSel: '.click-item',      btnSel: '.click-item-btn',     nameSel: '.click-item-name',     priceSel: '.click-item-price',     descSel: '.click-item-desc',     starsSel: '.click-item-stars',     cat: 'მაუსი' },
    // Smartphones
    { cardSel: '.mobile-device',   btnSel: '.mobile-device-btn',  nameSel: '.mobile-device-name',  priceSel: '.mobile-device-price',  descSel: '.mobile-device-desc',  starsSel: '.mobile-device-stars',  cat: 'სმარტფონი' },
    // Speakers
    { cardSel: '.audio-box',       btnSel: '.audio-box-btn',      nameSel: '.audio-box-name',      priceSel: '.audio-box-price',      descSel: '.audio-box-desc',      starsSel: '.audio-box-stars',      cat: 'სპიკერი' },
    // Webcam
    { cardSel: '.stream-lens',     btnSel: '.stream-lens-btn',    nameSel: '.stream-lens-name',    priceSel: '.stream-lens-price',    descSel: '.stream-lens-desc',    starsSel: '.stream-lens-stars',    cat: 'ვებკამი' },
  ];

  /* Build a lookup: btn selector → config */
  var BTN_TO_CONFIG = {};
  CARD_CONFIGS.forEach(function (cfg) {
    BTN_TO_CONFIG[cfg.btnSel] = cfg;
  });

  /* ── Helper: extract product data from a card element ── */
  function readCardData(card, cfg) {
    var name  = card.querySelector(cfg.nameSel)  ? card.querySelector(cfg.nameSel).textContent.trim()  : '';
    var price = card.querySelector(cfg.priceSel) ? card.querySelector(cfg.priceSel).textContent.trim() : '';
    var desc  = cfg.descSel && card.querySelector(cfg.descSel) ? card.querySelector(cfg.descSel).textContent.trim() : '';
    var cat   = cfg.catSel  && card.querySelector(cfg.catSel)  ? card.querySelector(cfg.catSel).textContent.trim()  : (cfg.cat || '');
    var img   = card.querySelector('img') ? card.querySelector('img').src : '';
    // Stars: count .on svgs
    var starsEl   = cfg.starsSel ? card.querySelector(cfg.starsSel) : null;
    var starsCount = starsEl
      ? Math.max(starsEl.querySelectorAll('svg.on').length, starsEl.querySelectorAll('.on').length)
      : 0;
    return { name: name, price: price, desc: desc, cat: cat, img: img, stars: starsCount };
  }

  /* ── Cart delegation ── */
  document.addEventListener('click', function (e) {
    var btn = e.target.closest
      ? e.target.closest(Object.keys(BTN_TO_CONFIG).join(','))
      : null;
    if (!btn) return;

    // find which config this btn belongs to
    var cfg = null;
    for (var sel in BTN_TO_CONFIG) {
      if (btn.matches(sel)) { cfg = BTN_TO_CONFIG[sel]; break; }
    }
    if (!cfg) return;

    // Don't re-handle hero cards (already have their own listener)
    if (cfg.cardSel === '.pc') return;

    e.stopPropagation();

    var card = btn.closest(cfg.cardSel);
    if (!card) return;
    var data = readCardData(card, cfg);

    // Price cleanup: remove GEL suffix if present (keep ₾ symbol)
    var priceClean = data.price.replace(/\s*GEL\s*$/i, '').trim();

    if (typeof addToCart === 'function') {
      addToCart({ name: data.name, price: priceClean, img: data.img, cat: data.cat });
    }
  });

  /* ════════════════════════════════════════
     FULLPAGE MODAL — CSS + HTML injection
  ════════════════════════════════════════ */
  var MODAL_CSS = `
  #fp-overlay {
    position: fixed;
    inset: 0;
    z-index: 99999;
    background: rgba(0,0,0,.7);
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity .35s ease;
  }
  #fp-overlay.fp-open {
    opacity: 1;
    pointer-events: all;
  }
  #fp-card {
    position: relative;
    background: #0f0f17;
    border: 1px solid rgba(255,255,255,.1);
    border-radius: 24px;
    box-shadow: 0 40px 100px rgba(0,0,0,.7), 0 0 0 1px rgba(255,255,255,.05);
    max-width: 880px;
    width: calc(100% - 40px);
    max-height: 90vh;
    overflow: hidden;
    display: flex;
    flex-direction: row;
    transform: scale(.88) translateY(32px);
    transition: transform .45s cubic-bezier(.16,1,.3,1), opacity .35s ease;
    opacity: 0;
  }
  #fp-overlay.fp-open #fp-card {
    transform: scale(1) translateY(0);
    opacity: 1;
  }
  #fp-img-col {
    flex: 0 0 380px;
    position: relative;
    overflow: hidden;
    background: #090912;
  }
  #fp-img-bg {
    position: absolute;
    inset: -10%;
    width: 120%; height: 120%;
    object-fit: cover;
    filter: blur(24px) brightness(.4) saturate(1.4);
    transform: scale(1.1);
  }
  #fp-img-main {
    position: relative;
    z-index: 1;
    width: 100%;
    height: 100%;
    object-fit: contain;
    padding: 32px;
    box-sizing: border-box;
    transition: transform .6s cubic-bezier(.16,1,.3,1);
  }
  #fp-overlay.fp-open #fp-img-main {
    transform: scale(1.04);
  }
  #fp-info-col {
    flex: 1;
    padding: 40px 36px;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 18px;
    scrollbar-width: thin;
    scrollbar-color: rgba(255,255,255,.1) transparent;
  }
  #fp-cat-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(255,255,255,.06);
    border: 1px solid rgba(255,255,255,.1);
    border-radius: 20px;
    padding: 5px 14px;
    font-size: 11px;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: rgba(255,255,255,.55);
    width: fit-content;
  }
  #fp-name {
    font-family: 'Bebas Neue', 'Inter', sans-serif;
    font-size: clamp(26px, 4vw, 38px);
    font-weight: 700;
    color: #fff;
    line-height: 1.1;
    letter-spacing: 1px;
    margin: 0;
  }
  #fp-stars {
    display: flex;
    align-items: center;
    gap: 4px;
  }
  #fp-stars .fp-star {
    width: 18px; height: 18px;
    fill: #f5a623;
  }
  #fp-stars .fp-star.off {
    fill: rgba(255,255,255,.15);
  }
  #fp-desc {
    font-size: 15px;
    color: rgba(255,255,255,.55);
    line-height: 1.65;
    margin: 0;
    border-left: 3px solid rgba(255,255,255,.08);
    padding-left: 14px;
  }
  #fp-divider {
    width: 100%;
    height: 1px;
    background: rgba(255,255,255,.07);
  }
  #fp-price-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    margin-top: auto;
  }
  #fp-price {
    font-family: 'Bebas Neue', 'Inter', sans-serif;
    font-size: 42px;
    color: #fff;
    letter-spacing: 1px;
    line-height: 1;
  }
  #fp-price sub {
    font-size: 18px;
    vertical-align: baseline;
    color: rgba(255,255,255,.5);
    font-family: 'Inter', sans-serif;
    font-weight: 400;
    letter-spacing: 0;
  }
  #fp-add-btn {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, #6c2fff, #a040ff);
    border: none;
    border-radius: 14px;
    padding: 14px 26px;
    color: #fff;
    font-size: 14px;
    font-weight: 600;
    letter-spacing: .5px;
    cursor: pointer;
    transition: transform .2s, box-shadow .2s, filter .2s;
    white-space: nowrap;
  }
  #fp-add-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 32px rgba(108,47,255,.45);
    filter: brightness(1.1);
  }
  #fp-add-btn:active { transform: scale(.97); }
  #fp-add-btn svg { width: 18px; height: 18px; }
  #fp-close {
    position: absolute;
    top: 16px; right: 16px;
    z-index: 10;
    width: 38px; height: 38px;
    border-radius: 50%;
    background: rgba(255,255,255,.08);
    border: 1px solid rgba(255,255,255,.12);
    color: rgba(255,255,255,.7);
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: background .2s, color .2s, transform .2s;
  }
  #fp-close:hover {
    background: rgba(255,255,255,.16);
    color: #fff;
    transform: rotate(90deg);
  }
  #fp-close svg { width: 16px; height: 16px; }
  @media (max-width: 680px) {
    #fp-card { flex-direction: column; max-height: 92vh; border-radius: 20px 20px 0 0; align-self: flex-end; width: 100%; }
    #fp-img-col { flex: 0 0 220px; }
    #fp-info-col { padding: 24px 22px 28px; }
  }
  /* Card cursor hint */
  .pc, .sonic-pod, .ultrabook-tile, .rig-unit, .arena-slot,
  .keystroke-piece, .screen-frame, .click-item, .mobile-device,
  .audio-box, .stream-lens {
    cursor: pointer;
  }
  `;

  /* Inject CSS */
  var styleEl = document.createElement('style');
  styleEl.textContent = MODAL_CSS;
  document.head.appendChild(styleEl);

  /* Build modal HTML */
  var overlay = document.createElement('div');
  overlay.id = 'fp-overlay';
  overlay.innerHTML = `
    <div id="fp-card">
      <button id="fp-close" aria-label="დახურვა">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
      <div id="fp-img-col">
        <img id="fp-img-bg" src="" alt="">
        <img id="fp-img-main" src="" alt="">
      </div>
      <div id="fp-info-col">
        <div id="fp-cat-badge"></div>
        <h2 id="fp-name"></h2>
        <div id="fp-stars"></div>
        <p id="fp-desc"></p>
        <div id="fp-divider"></div>
        <div id="fp-price-row">
          <div id="fp-price"></div>
          <button id="fp-add-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/>
              <line x1="3" y1="6" x2="21" y2="6"/>
              <path d="M16 10a4 4 0 01-8 0"/>
            </svg>
            კალათაში დამატება
          </button>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  var fpCard     = document.getElementById('fp-card');
  var fpClose    = document.getElementById('fp-close');
  var fpImgBg    = document.getElementById('fp-img-bg');
  var fpImgMain  = document.getElementById('fp-img-main');
  var fpCat      = document.getElementById('fp-cat-badge');
  var fpName     = document.getElementById('fp-name');
  var fpStars    = document.getElementById('fp-stars');
  var fpDesc     = document.getElementById('fp-desc');
  var fpPrice    = document.getElementById('fp-price');
  var fpAddBtn   = document.getElementById('fp-add-btn');

  var currentProduct = null;

  function openFullpage(data) {
    currentProduct = data;
    fpImgBg.src      = data.img;
    fpImgMain.src    = data.img;
    fpImgMain.alt    = data.name;
    fpCat.textContent = data.cat || '';
    fpName.textContent = data.name;
    fpDesc.textContent = data.desc || '';
    fpPrice.innerHTML  = data.price + (data.price.indexOf('GEL') === -1 ? '' : '');

    // Stars
    var starsHTML = '';
    for (var i = 1; i <= 5; i++) {
      starsHTML += '<svg class="fp-star' + (i <= (data.stars || 5) ? '' : ' off') + '" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.86L12 17.77l-6.18 3.23L7 14.14 2 9.27l6.91-1.01z"/></svg>';
    }
    fpStars.innerHTML = starsHTML;

    document.body.style.overflow = 'hidden';
    overlay.classList.add('fp-open');
  }

  function closeFullpage() {
    overlay.classList.remove('fp-open');
    document.body.style.overflow = '';
    setTimeout(function () { currentProduct = null; }, 400);
  }

  /* Close handlers */
  fpClose.addEventListener('click', closeFullpage);
  overlay.addEventListener('click', function (e) {
    if (e.target === overlay) closeFullpage();
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && overlay.classList.contains('fp-open')) closeFullpage();
  });

  /* Add-to-cart from fullpage */
  fpAddBtn.addEventListener('click', function () {
    if (!currentProduct) return;
    var priceClean = currentProduct.price.replace(/\s*GEL\s*$/i, '').trim();
    if (typeof addToCart === 'function') {
      addToCart({ name: currentProduct.name, price: priceClean, img: currentProduct.img, cat: currentProduct.cat || '' });
    }
  });

  /* ── Card click → open fullpage ── */
  function setupCardClicks() {
    CARD_CONFIGS.forEach(function (cfg) {
      document.querySelectorAll(cfg.cardSel).forEach(function (card) {
        if (card.dataset.fpBound) return;
        card.dataset.fpBound = '1';
        card.addEventListener('click', function (e) {
          // Don't open fullpage if clicking the add button
          if (e.target.closest(cfg.btnSel)) return;
          var data = readCardData(card, cfg);
          openFullpage(data);
        });
      });
    });
  }

  /* Run immediately + watch for dynamically rendered cards (hero section) */
  setupCardClicks();

  /* Watch for new cards added via renderProducts */
  if (window.MutationObserver) {
    var mo = new MutationObserver(function () {
      setupCardClicks();
    });
    mo.observe(document.body, { childList: true, subtree: true });
  }

})();
