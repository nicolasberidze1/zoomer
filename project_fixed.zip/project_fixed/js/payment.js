/* ═══════════════════════════════════════
   PAYMENT MODAL
═══════════════════════════════════════ */
['modal-payment'].forEach(id=>{
  document.getElementById(id).addEventListener('click',e=>{
    if(e.target===document.getElementById(id)) closePaymentModal();
  });
});
document.getElementById('close-payment').addEventListener('click', closePaymentModal);

function openPaymentModal(){
  const totalEl = document.getElementById('prof-cart-total');
  document.getElementById('pay-total-line').textContent = 'სულ: ' + (totalEl ? totalEl.textContent : '₾0');
  document.getElementById('modal-payment').classList.add('open');
  document.body.style.overflow='hidden';
  // reset card
  document.getElementById('pay-card-num').value='';
  document.getElementById('pay-card-name').value='';
  document.getElementById('pay-card-exp').value='';
  document.getElementById('pay-card-cvv').value='';
  document.getElementById('card-number-display').textContent='•••• •••• •••• ••••';
  document.getElementById('card-holder-display').textContent='FULL NAME';
  document.getElementById('card-expiry-display').textContent='MM/YY';
  document.getElementById('card-cvv-display').textContent='•••';
  document.getElementById('card-3d').classList.remove('flipped');
  updateCardBrand('');
}

function closePaymentModal(){
  document.getElementById('modal-payment').classList.remove('open');
  document.body.style.overflow='';
}

document.getElementById('btn-checkout').addEventListener('click', openPaymentModal);

function updateCardBrand(num){
  const visa = document.getElementById('visa-logo');
  const mc   = document.getElementById('mc-logo');
  const amex = document.getElementById('amex-logo');
  visa.style.display='none'; mc.style.display='none'; amex.style.display='none';
  if(/^4/.test(num)) visa.style.display='';
  else if(/^5[1-5]|^2[2-7]/.test(num)) mc.style.display='';
  else if(/^3[47]/.test(num)) amex.style.display='';
}

// Card number
document.getElementById('pay-card-num').addEventListener('input', function(){
  let v = this.value.replace(/\D/g,'').slice(0,16);
  let formatted = v.replace(/(.{4})/g,'$1 ').trim();
  this.value = formatted;
  const disp = v.padEnd(16,'•');
  document.getElementById('card-number-display').textContent =
    disp.slice(0,4)+' '+disp.slice(4,8)+' '+disp.slice(8,12)+' '+disp.slice(12,16);
  updateCardBrand(v);
});

// Card name
document.getElementById('pay-card-name').addEventListener('input', function(){
  const v = this.value.toUpperCase().slice(0,26);
  this.value = v;
  document.getElementById('card-holder-display').textContent = v || 'FULL NAME';
});

// Expiry
document.getElementById('pay-card-exp').addEventListener('input', function(){
  let v = this.value.replace(/\D/g,'').slice(0,4);
  if(v.length>=2) v = v.slice(0,2)+'/'+v.slice(2);
  this.value = v;
  document.getElementById('card-expiry-display').textContent = v || 'MM/YY';
});

// CVV - flip card
document.getElementById('pay-card-cvv').addEventListener('focus', function(){
  document.getElementById('card-3d').classList.add('flipped');
});
document.getElementById('pay-card-cvv').addEventListener('blur', function(){
  document.getElementById('card-3d').classList.remove('flipped');
});
document.getElementById('pay-card-cvv').addEventListener('input', function(){
  const v = this.value.replace(/\D/g,'').slice(0,4);
  this.value = v;
  document.getElementById('card-cvv-display').textContent = v ? '•'.repeat(v.length) : '•••';
});

// Submit
document.getElementById('pay-submit-btn').addEventListener('click', async ()=>{
  const num  = document.getElementById('pay-card-num').value.replace(/\s/g,'');
  const name = document.getElementById('pay-card-name').value.trim();
  const exp  = document.getElementById('pay-card-exp').value.trim();
  const cvv  = document.getElementById('pay-card-cvv').value.trim();

  if(num.length<16){ showToast('ბარათის ნომერი არასრულია ❗','❗'); return; }
  if(!name){ showToast('სახელი სავალდებულოა ❗','❗'); return; }
  if(!/^\d{2}\/\d{2}$/.test(exp)){ showToast('ვადა არასწორია ❗','❗'); return; }
  if(cvv.length<3){ showToast('CVV არასწორია ❗','❗'); return; }

  setBtnLoading('pay-submit-btn', true);
  // Simulate payment processing
  await new Promise(r=>setTimeout(r,1800));
  setBtnLoading('pay-submit-btn', false, 'გადახდა');
  closePaymentModal();
  closeAllModals();
  // Clear cart
  try {
    for(const item of [...cartItems]){
      await apiCall('api/cart.php','DELETE',{id:item.id});
    }
    cartItems=[];
    updateCartBadge();
    if(currentUser){ renderProfile(currentUser); renderCartInProfile(); }
  } catch(e){}
  showToast('გადახდა წარმატებული! 🎉 გმადლობთ!','🎉');
});
