/* ══════════════════════════════════════════════════════════
   TECHZONE — NexChat JS
   /chat/chat.js
══════════════════════════════════════════════════════════ */

(function () {
  'use strict';

  /* ─────────────────────────────────────────────────────────
     STATE
  ───────────────────────────────────────────────────────── */
  let nxcOpen          = false;
  let nxcCurrentUser   = null;
  let nxcChatWith      = null;
  let nxcMessages      = [];
  let nxcUsers         = [];
  let nxcPollingTimer  = null;
  let nxcTypingTimer   = null;
  let nxcTypingPollTimer = null;
  let nxcIsSending     = false;
  let nxcPickerTab     = 'emoji';
  let nxcPickerOpen    = false;
  let nxcReactionTarget = null;
  let nxcIsAdmin       = false;

  /* Voice recording */
  let nxcMediaRecorder = null;
  let nxcAudioChunks   = [];
  let nxcRecordingTimer = null;
  let nxcRecordingSec  = 0;

  /* Device state */
  let nxcDevices          = { inputs: [], outputs: [] };
  let nxcSelectedInputId  = null;
  let nxcSelectedOutputId = null;
  let nxcDevicePanelOpen  = false;

  /*
   * KEY FIX: base64 voice src stored here, NOT in HTML attributes.
   * HTML attribute injection of 500KB base64 strings breaks browsers.
   */
  const nxcVoiceSrcMap = new Map();

  /* WebRTC Call state */
  let nxcCallPeer      = null;
  let nxcCallWith      = null;
  let nxcCallRole      = null;
  let nxcCallTimer     = null;
  let nxcCallSec       = 0;
  let nxcCallPollTimer = null;
  let nxcLocalStream   = null;
  let nxcCallMuted     = false;
  let nxcIncomingCallData = null;

  /* ─────────────────────────────────────────────────────────
     CONSTANTS
  ───────────────────────────────────────────────────────── */
  const STICKERS = [
    { emoji: '🐱', label: 'cat' },  { emoji: '🐶', label: 'dog' },
    { emoji: '🐼', label: 'panda' },{ emoji: '🦊', label: 'fox' },
    { emoji: '🐻', label: 'bear' }, { emoji: '🐸', label: 'frog' },
    { emoji: '🐨', label: 'koala' },{ emoji: '🦋', label: 'butterfly' },
    { emoji: '🌻', label: 'flower'},{ emoji: '🌙', label: 'moon' },
    { emoji: '⭐', label: 'star' }, { emoji: '💎', label: 'gem' },
    { emoji: '🏔️', label: 'mountain'},{ emoji: '🌊', label: 'wave' },
    { emoji: '🦄', label: 'unicorn'},{ emoji: '🐉', label: 'dragon' },
  ];

  const TENOR_KEY = 'AIzaSyAyimkuYQYF_FXVALexPzkcsvZiNeZxPrA';
  const DEFAULT_GIFS = [
    'https://media.tenor.com/UZnCMiR8LKYAAAAC/ok-okay.gif',
    'https://media.tenor.com/uH9FtDNjkgYAAAAC/thumbs-up-thumbs-up-kid.gif',
    'https://media.tenor.com/O81NVMVcmzUAAAAC/high-five-friends.gif',
    'https://media.tenor.com/YP9k5E46z5MAAAAC/wave-hi.gif',
    'https://media.tenor.com/kseP1mhPMaYAAAAC/crying-sad.gif',
    'https://media.tenor.com/2rLxlZVzWfcAAAAC/lol-laughing.gif',
  ];

  const ICE_SERVERS = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' },
    ]
  };

  /* ─────────────────────────────────────────────────────────
     INIT
  ───────────────────────────────────────────────────────── */
  window.addEventListener('nxcAuthReady', (e) => {
    nxcCurrentUser = e.detail;
    nxcIsAdmin = (['admin','moderator'].includes(nxcCurrentUser?.role));
    initChat();
  });

  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
      if (window.currentUser && !nxcCurrentUser) {
        nxcCurrentUser = window.currentUser;
        nxcIsAdmin = (['admin','moderator'].includes(nxcCurrentUser?.role));
        initChat();
      }
    }, 1500);
  });

  function initChat() {
    if (!nxcCurrentUser) return;
    setupEventListeners();
    loadUnreadCount();
    setInterval(loadUnreadCount, 15000);
    setInterval(pollIncomingCall, 3000);
  }

  /* ─────────────────────────────────────────────────────────
     EVENT LISTENERS
  ───────────────────────────────────────────────────────── */
  function setupEventListeners() {
    const fab         = document.getElementById('nxc-fab');
    const closeBtn    = document.getElementById('nxc-close');
    const backBtn     = document.getElementById('nxc-back-btn');
    const sendBtn     = document.getElementById('nxc-send-btn');
    const textarea    = document.getElementById('nxc-textarea');
    const emojiBtn    = document.getElementById('nxc-emoji-btn');
    const voiceBtn    = document.getElementById('nxc-voice-btn');
    const voiceCancel = document.getElementById('nxc-voice-cancel');
    const search      = document.getElementById('nxc-search');
    const deviceBtn   = document.getElementById('nxc-device-btn');

    fab?.addEventListener('click', toggleChat);
    closeBtn?.addEventListener('click', closeChat);
    backBtn?.addEventListener('click', () => {
      document.getElementById('nxc-chat-panel').classList.remove('mobile-open');
    });

    sendBtn?.addEventListener('click', sendTextMessage);
    textarea?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendTextMessage(); }
    });
    textarea?.addEventListener('input', () => { autoResize(textarea); sendTypingIndicator(); });

    emojiBtn?.addEventListener('click', togglePicker);
    voiceBtn?.addEventListener('click', toggleVoiceRecording);
    voiceCancel?.addEventListener('click', cancelVoiceRecording);
    search?.addEventListener('input', filterUsers);
    deviceBtn?.addEventListener('click', toggleDevicePanel);

    document.querySelectorAll('.nxc-ptab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.nxc-ptab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        nxcPickerTab = tab.dataset.tab;
        renderPicker();
      });
    });

    document.getElementById('nxc-pin-btn')?.addEventListener('click', pinLastMessage);
    document.getElementById('nxc-clear-btn')?.addEventListener('click', clearChat);

    document.getElementById('nxc-call-btn')?.addEventListener('click', startCall);
    document.getElementById('nxc-call-accept')?.addEventListener('click', acceptCall);
    document.getElementById('nxc-call-reject')?.addEventListener('click', rejectCall);
    document.getElementById('nxc-call-end')?.addEventListener('click', endCall);
    document.getElementById('nxc-call-mute')?.addEventListener('click', toggleCallMute);

    document.addEventListener('click', (e) => {
      if (!e.target.closest('.nxc-reaction-popup') && !e.target.closest('.nxc-bubble')) {
        document.getElementById('nxc-reaction-popup').style.display = 'none';
        nxcReactionTarget = null;
      }
      if (!e.target.closest('.nxc-device-panel') && !e.target.closest('#nxc-device-btn')) {
        const panel = document.getElementById('nxc-device-panel');
        if (panel && nxcDevicePanelOpen) { panel.style.display = 'none'; nxcDevicePanelOpen = false; }
      }
    });

    document.querySelectorAll('.nxc-react-emoji').forEach(el => el.addEventListener('click', sendReaction));
  }

  /* ─────────────────────────────────────────────────────────
     FAB / OPEN / CLOSE
  ───────────────────────────────────────────────────────── */
  function toggleChat() { if (nxcOpen) closeChat(); else openChat(); }

  function openChat() {
    nxcOpen = true;
    document.getElementById('nxc-overlay').classList.add('open');
    document.body.style.overflow = 'hidden';
    loadUsers();
  }

  function closeChat() {
    nxcOpen = false;
    document.getElementById('nxc-overlay').classList.remove('open');
    document.body.style.overflow = '';
    stopPolling();
  }

  /* ─────────────────────────────────────────────────────────
     USERS LIST
  ───────────────────────────────────────────────────────── */
  async function loadUsers() {
    try {
      const res = await apiCall('chat/chat_api.php?action=users');
      if (res.success) { nxcUsers = res.data; renderUsers(nxcUsers); }
    } catch (e) { console.error('NexChat: loadUsers', e); }
  }

  function renderUsers(users) {
    const list = document.getElementById('nxc-users-list');
    if (!users.length) {
      list.innerHTML = '<div class="nxc-loading"><span>მომხმარებელი არ არის</span></div>';
      return;
    }
    list.innerHTML = users.map(u => {
      const name    = (u.firstName + ' ' + u.lastName).trim() || u.email;
      const initial = (u.firstName?.[0] || u.email?.[0] || '?').toUpperCase();
      const avHtml  = u.photo ? `<img src="${escHtml(u.photo)}" alt="">` : initial;
      const roleBadge = u.role !== 'user'
        ? `<span class="nxc-user-role-badge nxc-role-${u.role}">${u.role}</span>` : '';
      const lastText = u.lastMessage
        ? (u.lastMessage.deleted      ? '🗑 წაშლილია'
          : u.lastMessage.type==='voice'   ? '🎤 ხმოვანი'
          : u.lastMessage.type==='sticker' ? '🎭 სტიკერი'
          : u.lastMessage.type==='gif'     ? '🎬 GIF'
          : u.lastMessage.type==='emoji'   ? u.lastMessage.text
          : u.lastMessage.text?.slice(0,28) || '')
        : 'დაიწყე საუბარი';
      const unread = u.unread ? `<div class="nxc-unread-badge">${u.unread}</div>` : '';
      return `<div class="nxc-user-item" data-uid="${escHtml(u.id)}" onclick="nxcSelectUser('${escHtml(u.id)}')">
        <div class="nxc-user-av-wrap">
          <div class="nxc-user-av">${avHtml}</div>
          <div class="nxc-user-av-status online"></div>
        </div>
        <div class="nxc-user-info">
          <div class="nxc-user-name">${escHtml(name)}${roleBadge}</div>
          <div class="nxc-user-last">${escHtml(lastText)}</div>
        </div>${unread}
      </div>`;
    }).join('');
  }

  function filterUsers() {
    const q = document.getElementById('nxc-search').value.toLowerCase();
    renderUsers(nxcUsers.filter(u =>
      (u.firstName + ' ' + u.lastName + ' ' + u.email).toLowerCase().includes(q)
    ));
  }

  /* ─────────────────────────────────────────────────────────
     SELECT USER
  ───────────────────────────────────────────────────────── */
  window.nxcSelectUser = async function (uid) {
    nxcChatWith = nxcUsers.find(u => u.id === uid) || null;
    if (!nxcChatWith) return;

    document.querySelectorAll('.nxc-user-item').forEach(el =>
      el.classList.toggle('active', el.dataset.uid === uid)
    );
    document.getElementById('nxc-chat-panel').classList.add('mobile-open');

    const name = (nxcChatWith.firstName + ' ' + nxcChatWith.lastName).trim() || nxcChatWith.email;
    const avEl = document.getElementById('nxc-chat-av');
    avEl.innerHTML = nxcChatWith.photo
      ? `<img src="${escHtml(nxcChatWith.photo)}" alt="">`
      : (nxcChatWith.firstName?.[0] || '?').toUpperCase();

    document.getElementById('nxc-chat-header-name').textContent = name;
    const roleBadges = { admin:'👑 Admin', moderator:'🛡 Mod', editor:'✏️ Editor', user:'💬 User' };
    document.getElementById('nxc-chat-header-sub').textContent = roleBadges[nxcChatWith.role] || 'User';
    document.getElementById('nxc-pin-btn').style.display   = nxcIsAdmin ? 'flex' : 'none';
    document.getElementById('nxc-clear-btn').style.display = nxcIsAdmin ? 'flex' : 'none';
    document.getElementById('nxc-empty-state').style.display = 'none';
    document.getElementById('nxc-chat-view').style.display = 'flex';

    await loadMessages();
    markRead();
    startPolling();
  };

  /* ─────────────────────────────────────────────────────────
     MESSAGES
  ───────────────────────────────────────────────────────── */
  async function loadMessages() {
    if (!nxcChatWith) return;
    try {
      const res = await apiCall(`chat/chat_api.php?action=messages&with=${nxcChatWith.id}`);
      if (res.success) {
        const newMsgs = res.data.messages || [];
        const lastOld = nxcMessages[nxcMessages.length - 1];
        const lastNew = newMsgs[newMsgs.length - 1];
        const changed = newMsgs.length !== nxcMessages.length
          || (lastNew && lastOld && (
              lastNew.id !== lastOld.id
              || lastNew.read !== lastOld.read
              || (lastNew.reactions?.length||0) !== (lastOld.reactions?.length||0)
             ));
        nxcMessages = newMsgs;
        if (changed) renderMessages();
      }
    } catch (e) { console.error('NexChat: loadMessages', e); }
  }

  function renderMessages() {
    const container = document.getElementById('nxc-messages');
    const scrollBottom = container.scrollHeight - container.scrollTop - container.clientHeight;
    const wasAtBottom  = scrollBottom < 80;
    container.innerHTML = '';

    if (!nxcMessages.length) {
      container.innerHTML = '<div class="nxc-sys-msg">👋 საუბარი დაიწყე!</div>';
      return;
    }

    let lastDate = null, lastFrom = null;

    nxcMessages.forEach((msg) => {
      const msgDate = new Date(msg.time * 1000);
      const dateStr = formatDate(msgDate);

      if (dateStr !== lastDate) {
        const sep = document.createElement('div');
        sep.className = 'nxc-date-sep';
        sep.textContent = dateStr;
        container.appendChild(sep);
        lastDate = dateStr; lastFrom = null;
      }

      const isMine    = msg.from === nxcCurrentUser.id;
      const isNewGroup = msg.from !== lastFrom;
      lastFrom = msg.from;

      let group;
      const lastGroup = container.querySelector('.nxc-msg-group:last-child');
      if (!isNewGroup && lastGroup && lastGroup.dataset.from === msg.from) {
        group = lastGroup;
      } else {
        group = document.createElement('div');
        group.className = `nxc-msg-group ${isMine ? 'nxc-mine' : 'nxc-theirs'}`;
        group.dataset.from = msg.from;
        container.appendChild(group);
      }

      const row    = document.createElement('div');
      row.className = 'nxc-msg-row';

      const sender = isMine ? nxcCurrentUser : nxcChatWith;
      const avEl   = document.createElement('div');
      avEl.className = 'nxc-msg-av';
      avEl.innerHTML = sender?.photo
        ? `<img src="${escHtml(sender.photo)}" alt="">`
        : (sender?.firstName?.[0] || '?').toUpperCase();

      const bubble = document.createElement('div');
      bubble.className = 'nxc-bubble';
      bubble.dataset.msgid = msg.id;

      if (msg.deleted) {
        bubble.classList.add('deleted');
        bubble.textContent = '🗑 შეტყობინება წაშლილია';
      } else if (msg.type === 'sticker') {
        bubble.classList.add('sticker');
        bubble.innerHTML = `<div style="font-size:64px;line-height:1;">${escHtml(msg.text)}</div>`;
      } else if (msg.type === 'gif') {
        bubble.classList.add('gif-bubble');
        bubble.innerHTML = `<img class="nxc-gif-img" src="${escHtml(msg.media)}" alt="GIF" loading="lazy">`;
      } else if (msg.type === 'voice') {
        /* KEY FIX: Store voice src in Map, build player with DOM (no onclick with base64) */
        if (msg.media?.src) nxcVoiceSrcMap.set(msg.id, msg.media.src);
        bubble.appendChild(buildVoicePlayer(msg));
      } else if (msg.type === 'emoji') {
        bubble.classList.add('emoji-only');
        bubble.textContent = msg.text;
      } else {
        const stripped = msg.text?.replace(/[\u{1F000}-\u{1FFFF}\u{2600}-\u{27FF}\uFE0F]/gu, '').trim();
        if (!stripped && msg.text?.length <= 8) bubble.classList.add('emoji-only');
        bubble.textContent = msg.text || '';
      }

      bubble.addEventListener('contextmenu', (e) => { e.preventDefault(); showReactionPopup(e, msg.id); });
      bubble.addEventListener('touchstart', (() => {
        let t; return () => { t = setTimeout(() => showReactionPopup(null, msg.id, bubble), 600); };
      })(), { passive: true });

      if (isMine && !msg.deleted) {
        bubble.title = 'ორჯერ დაჭერა = წაშლა';
        bubble.addEventListener('dblclick', () => deleteMessage(msg.id));
        let tapTimer = null;
        bubble.addEventListener('touchend', () => {
          if (tapTimer) { clearTimeout(tapTimer); tapTimer = null; deleteMessage(msg.id); }
          else tapTimer = setTimeout(() => { tapTimer = null; }, 300);
        });
      }

      if (isMine) { row.appendChild(bubble); row.appendChild(avEl); }
      else        { row.appendChild(avEl); row.appendChild(bubble); }
      group.appendChild(row);

      if (msg.reactions?.length) {
        const reacts = document.createElement('div');
        reacts.className = 'nxc-reactions';
        msg.reactions.forEach(r => {
          const chip = document.createElement('div');
          chip.className = `nxc-reaction${r.users.includes(nxcCurrentUser.id) ? ' mine' : ''}`;
          chip.innerHTML = `${r.emoji} <span class="nxc-reaction-count">${r.users.length}</span>`;
          chip.onclick = () => doReact(msg.id, r.emoji);
          reacts.appendChild(chip);
        });
        group.appendChild(reacts);
      }

      if (msg.pinned) {
        document.getElementById('nxc-pinned-bar').style.display = 'flex';
        document.getElementById('nxc-pinned-text').textContent = msg.text?.slice(0,60) || '(media)';
      }
    });

    /* Read receipt */
    const myMsgs = nxcMessages.filter(m => m.from === nxcCurrentUser.id);
    if (myMsgs.length) {
      const lastMine   = myMsgs[myMsgs.length - 1];
      const lastBubble = container.querySelector(`[data-msgid="${lastMine.id}"]`);
      if (lastBubble) {
        const meta = document.createElement('div');
        meta.className = 'nxc-msg-meta';
        meta.innerHTML = `<span class="nxc-msg-time">${formatTime(new Date(lastMine.time*1000))}</span>
                          <span class="nxc-msg-read">${lastMine.read ? '✓✓' : '✓'}</span>`;
        lastBubble.closest('.nxc-msg-group').appendChild(meta);
      }
    }

    if (wasAtBottom) container.scrollTop = container.scrollHeight;
    document.getElementById('nxc-msgs-loading').style.display = 'none';
  }

  /* ─────────────────────────────────────────────────────────
     VOICE PLAYER — pure DOM, no HTML attribute injection
  ───────────────────────────────────────────────────────── */
  function buildVoicePlayer(msg) {
    const dur  = msg.media?.duration ? `${Math.round(msg.media.duration)}წმ` : '';
    const wrap = document.createElement('div');
    wrap.className = 'nxc-voice-player';

    const playBtn = document.createElement('button');
    playBtn.className = 'nxc-voice-play';
    playBtn.textContent = '▶';

    const waveWrap = document.createElement('div');
    waveWrap.className = 'nxc-voice-waveform';
    for (let i = 0; i < 12; i++) {
      const bar = document.createElement('div');
      bar.className = 'nxc-wave-bar';
      bar.style.height = (4 + Math.random() * 16) + 'px';
      bar.style.animationDelay = (i * 0.08) + 's';
      waveWrap.appendChild(bar);
    }

    const progress = document.createElement('input');
    progress.type = 'range'; progress.min = 0; progress.max = 100; progress.value = 0;
    progress.style.cssText = 'width:70px;accent-color:#d4ff3e;cursor:pointer;flex-shrink:0;';

    const durSpan = document.createElement('span');
    durSpan.className = 'nxc-voice-dur';
    durSpan.textContent = dur;

    let audio = null;
    let playing = false;

    playBtn.addEventListener('click', () => {
      const src = nxcVoiceSrcMap.get(msg.id);
      if (!src) { if (window.showToast) showToast('ხმოვანი ვერ მოიძებნა ❗', '❗'); return; }

      if (playing && audio) {
        audio.pause();
        audio.currentTime = 0;
        playBtn.textContent = '▶';
        playing = false;
        return;
      }

      audio = new Audio(src);
      if (nxcSelectedOutputId && typeof audio.setSinkId === 'function') {
        audio.setSinkId(nxcSelectedOutputId).catch(() => {});
      }
      audio.ontimeupdate = () => {
        if (audio.duration) {
          progress.value = (audio.currentTime / audio.duration) * 100;
          durSpan.textContent = Math.round(audio.duration - audio.currentTime) + 'წმ';
        }
      };
      audio.onended = () => { playBtn.textContent = '▶'; playing = false; progress.value = 0; durSpan.textContent = dur; };
      audio.onerror = () => { playBtn.textContent = '▶'; playing = false; if(window.showToast) showToast('ხმოვანი ვერ დაიკრა ❗','❗'); };
      audio.play().then(() => { playBtn.textContent = '⏸'; playing = true; })
                  .catch(err => { if(window.showToast) showToast('Play error: '+err.message,'❗'); });
    });

    progress.addEventListener('input', () => {
      if (audio && audio.duration) audio.currentTime = (progress.value / 100) * audio.duration;
    });

    wrap.appendChild(playBtn);
    wrap.appendChild(waveWrap);
    wrap.appendChild(progress);
    wrap.appendChild(durSpan);
    return wrap;
  }

  /* ─────────────────────────────────────────────────────────
     SEND TEXT
  ───────────────────────────────────────────────────────── */
  async function sendTextMessage() {
    if (!nxcChatWith || nxcIsSending) return;
    const ta   = document.getElementById('nxc-textarea');
    const text = ta.value.trim();
    if (!text) return;

    nxcIsSending = true;
    ta.value = ''; autoResize(ta);
    const btn = document.getElementById('nxc-send-btn');
    if (btn) btn.style.opacity = '0.5';

    try {
      const res = await apiCall('chat/chat_api.php?action=send', 'POST', { to: nxcChatWith.id, type: 'text', text });
      if (!res.success) {
        ta.value = text; autoResize(ta);
        if (window.showToast) showToast(res.error || 'შეცდომა ❗', '❗');
      } else {
        await loadMessages(); loadUsers();
      }
    } catch (e) { ta.value = text; autoResize(ta); }
    finally { nxcIsSending = false; if (btn) btn.style.opacity = ''; }
  }

  async function sendMediaMessage(type, text, media) {
    if (!nxcChatWith) return;
    try {
      const res = await apiCall('chat/chat_api.php?action=send', 'POST', { to: nxcChatWith.id, type, text: text||'', media });
      if (res.success) { await loadMessages(); loadUsers(); }
      else { if(window.showToast) showToast(res.error||'გაგზავნა ვერ მოხდა ❗','❗'); }
    } catch (e) { console.error('sendMedia', e); }
  }

  async function deleteMessage(msgId) {
    if (!nxcChatWith || !confirm('შეტყობინება წაიშლება?')) return;
    try { await apiCall('chat/chat_api.php?action=delete','POST',{with:nxcChatWith.id,msgId}); await loadMessages(); } catch(e){}
  }

  /* ─────────────────────────────────────────────────────────
     TYPING
  ───────────────────────────────────────────────────────── */
  function sendTypingIndicator() {
    if (!nxcChatWith) return;
    clearTimeout(nxcTypingTimer);
    nxcTypingTimer = setTimeout(()=>{}, 2000);
    apiCall('chat/chat_api.php?action=typing','POST',{to:nxcChatWith.id}).catch(()=>{});
  }

  async function pollTyping() {
    if (!nxcChatWith || !nxcOpen) return;
    try {
      const res = await apiCall(`chat/chat_api.php?action=typing&with=${nxcChatWith.id}`);
      const el = document.getElementById('nxc-typing');
      const nm = document.getElementById('nxc-typing-name');
      if (res.success && res.data.typing) {
        nm.textContent = (nxcChatWith.firstName||nxcChatWith.email)+' წერს...';
        el.style.display = 'flex';
      } else { el.style.display = 'none'; }
    } catch(e){}
  }

  /* ─────────────────────────────────────────────────────────
     POLLING
  ───────────────────────────────────────────────────────── */
  function startPolling() {
    stopPolling();
    nxcPollingTimer = setInterval(async () => {
      if (!nxcChatWith || !nxcOpen || nxcIsSending) return;
      const old = nxcMessages.length;
      await loadMessages();
      if (nxcMessages.length > old) markRead();
    }, 3000);
    nxcTypingPollTimer = setInterval(pollTyping, 2000);
  }
  function stopPolling() { clearInterval(nxcPollingTimer); clearInterval(nxcTypingPollTimer); }
  async function markRead() {
    if (!nxcChatWith) return;
    try { await apiCall('chat/chat_api.php?action=read','POST',{with:nxcChatWith.id}); } catch(e){}
  }
  async function loadUnreadCount() {
    if (!nxcCurrentUser) return;
    try {
      const res = await apiCall('chat/chat_api.php?action=unread');
      if (res.success) {
        const c = res.data.count, badge = document.getElementById('nxc-fab-badge');
        if (c>0) { badge.style.display='flex'; badge.textContent=c>99?'99+':c; }
        else badge.style.display='none';
      }
    } catch(e){}
  }

  /* ─────────────────────────────────────────────────────────
     PICKER
  ───────────────────────────────────────────────────────── */
  function togglePicker() {
    nxcPickerOpen = !nxcPickerOpen;
    document.getElementById('nxc-picker-bar').style.display = nxcPickerOpen ? 'flex' : 'none';
    document.getElementById('nxc-emoji-btn').classList.toggle('active', nxcPickerOpen);
    if (nxcPickerOpen) renderPicker();
  }

  function renderPicker() {
    const content = document.getElementById('nxc-picker-content');
    content.innerHTML = '';
    if (nxcPickerTab === 'emoji') {
      ['😀','😂','🥰','😍','🤩','😎','🥳','😭','😤','😱','🙏','👍','👎','❤️','🔥','✨','💯','🎉','🤣','😊','😋','🤔','😅','😆','🫶','💪','🙌','👏','🫡','😇','🥺','😏','😒','😔','🤯','🥸','😴','🤗','😬','🫠','💀','👻','🎃','🤖','👾','🎮','🎵','🎶','⚽','🏆','🌟','🌈','🍕','🍔','🍦','☕','🍷','🎂','🚀','🌸'].forEach(em => {
        const btn = document.createElement('div');
        btn.className = 'nxc-emoji-btn-item'; btn.textContent = em;
        btn.onclick = () => { const ta=document.getElementById('nxc-textarea'); if(!ta.value.trim()) sendMediaMessage('emoji',em,null); else { ta.value+=em; ta.focus(); } };
        content.appendChild(btn);
      });
    } else if (nxcPickerTab === 'sticker') {
      STICKERS.forEach(st => {
        const btn = document.createElement('div');
        btn.className='nxc-emoji-btn-item'; btn.style.cssText='width:64px;height:64px;font-size:44px;border-radius:12px;';
        btn.title=st.label; btn.textContent=st.emoji;
        btn.onclick = () => { sendMediaMessage('sticker',st.emoji,null); togglePicker(); };
        content.appendChild(btn);
      });
    } else if (nxcPickerTab === 'gif') {
      const si = document.createElement('input');
      si.className='nxc-gif-search'; si.placeholder='GIF-ის ძიება...'; si.style.width='100%';
      content.style.flexDirection='column'; content.appendChild(si);
      const grid = document.createElement('div');
      grid.style.cssText='display:flex;flex-wrap:wrap;gap:6px;'; content.appendChild(grid);
      loadGifs('happy', grid);
      let gt; si.addEventListener('input', () => { clearTimeout(gt); gt=setTimeout(()=>loadGifs(si.value||'happy',grid),500); });
    }
  }

  async function loadGifs(query, grid) {
    grid.innerHTML = DEFAULT_GIFS.slice(0,4).map(u=>`<img class="nxc-gif-item" src="${u}" alt="gif" onclick="nxcSendGif('${u}')">`).join('');
    try {
      const r = await fetch(`https://tenor.googleapis.com/v2/search?q=${encodeURIComponent(query)}&key=${TENOR_KEY}&limit=8&media_filter=gif`);
      if (!r.ok) return;
      const d = await r.json();
      const gifs = d.results?.map(x=>x.media_formats?.gif?.url||x.media_formats?.tinygif?.url).filter(Boolean)||[];
      if (gifs.length) grid.innerHTML = gifs.map(u=>`<img class="nxc-gif-item" src="${u}" alt="gif" onclick="nxcSendGif('${u}')">`).join('');
    } catch(e){}
  }
  window.nxcSendGif = function(url) {
    sendMediaMessage('gif','',url);
    nxcPickerOpen=false;
    document.getElementById('nxc-picker-bar').style.display='none';
    document.getElementById('nxc-emoji-btn').classList.remove('active');
  };

  /* ─────────────────────────────────────────────────────────
     VOICE RECORDING
  ───────────────────────────────────────────────────────── */
  function toggleVoiceRecording() {
    if (nxcMediaRecorder && nxcMediaRecorder.state === 'recording') stopVoiceRecording();
    else startVoiceRecording();
  }

  async function startVoiceRecording() {
    if (!navigator.mediaDevices?.getUserMedia) {
      if (window.showToast) showToast('ბრაუზერი მიკროფონს არ უჭერს მხარს ❗','❗'); return;
    }
    const isSecure = location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1'||location.hostname==='::1';
    if (!isSecure) {
      if (window.showToast) showToast('🔒 HTTPS ან localhost საჭიროა მიკროფონისთვის!','❗'); return;
    }
    try {
      const constraints = nxcSelectedInputId
        ? { audio: { deviceId: { exact: nxcSelectedInputId }, echoCancellation:true, noiseSuppression:true } }
        : { audio: { echoCancellation:true, noiseSuppression:true } };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      nxcAudioChunks = [];

      const mimeType = ['audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus','audio/mp4','']
        .find(t => !t || MediaRecorder.isTypeSupported(t));

      nxcMediaRecorder = new MediaRecorder(stream, mimeType ? { mimeType } : {});
      nxcMediaRecorder.ondataavailable = (e) => { if (e.data?.size>0) nxcAudioChunks.push(e.data); };
      nxcMediaRecorder.onstop = () => {
        stream.getTracks().forEach(t=>t.stop());
        if (!nxcAudioChunks.length) { if(window.showToast) showToast('ჩაწერა ვერ მოხდა ❗','❗'); return; }
        const blob = new Blob(nxcAudioChunks, { type: mimeType||'audio/webm' });
        const duration = nxcRecordingSec;
        const reader = new FileReader();
        reader.onloadend = () => {
          const dataUrl = reader.result;
          if (!dataUrl||dataUrl.length<50) { if(window.showToast) showToast('კონვერტაცია ვერ მოხდა ❗','❗'); return; }
          sendMediaMessage('voice', '', { src: dataUrl, duration });
        };
        reader.onerror = () => { if(window.showToast) showToast('კონვერტაციის შეცდომა ❗','❗'); };
        reader.readAsDataURL(blob);
      };

      nxcMediaRecorder.start(250);
      nxcRecordingSec = 0;
      document.getElementById('nxc-voice-recording').style.display = 'flex';
      document.getElementById('nxc-voice-btn').style.color = '#ef4444';
      nxcRecordingTimer = setInterval(() => {
        nxcRecordingSec++;
        const m=Math.floor(nxcRecordingSec/60), s=nxcRecordingSec%60;
        const el=document.getElementById('nxc-voice-timer');
        if (el) el.textContent=`${m}:${s.toString().padStart(2,'0')}`;
        if (nxcRecordingSec>=120) stopVoiceRecording();
      }, 1000);
    } catch(err) {
      console.error('Mic error:', err);
      let msg = 'მიკროფონი ვერ გაიხსნა ❗';
      if (err.name==='NotAllowedError'||err.name==='PermissionDeniedError')
        msg='🎤 მიკროფონი არ არის დაშვებული. URL ბარიდან დაუშვი.';
      else if (err.name==='NotFoundError'||err.name==='DevicesNotFoundError')
        msg='🎤 მიკროფონი ვერ მოიძებნა. Device-ები შეამოწმე.';
      else if (err.name==='OverconstrainedError') { nxcSelectedInputId=null; startVoiceRecording(); return; }
      if (window.showToast) showToast(msg,'❗');
    }
  }

  function stopVoiceRecording() {
    clearInterval(nxcRecordingTimer);
    if (nxcMediaRecorder && nxcMediaRecorder.state!=='inactive') nxcMediaRecorder.stop();
    document.getElementById('nxc-voice-recording').style.display='none';
    document.getElementById('nxc-voice-btn').style.color='';
  }

  function cancelVoiceRecording() {
    clearInterval(nxcRecordingTimer);
    if (nxcMediaRecorder && nxcMediaRecorder.state!=='inactive') {
      nxcMediaRecorder.ondataavailable=null;
      nxcMediaRecorder.onstop=()=>{ nxcMediaRecorder.stream?.getTracks().forEach(t=>t.stop()); };
      nxcMediaRecorder.stop();
    }
    nxcAudioChunks=[];
    document.getElementById('nxc-voice-recording').style.display='none';
    document.getElementById('nxc-voice-btn').style.color='';
  }

  /* ─────────────────────────────────────────────────────────
     DEVICE PANEL
  ───────────────────────────────────────────────────────── */
  function toggleDevicePanel() {
    nxcDevicePanelOpen=!nxcDevicePanelOpen;
    const panel=document.getElementById('nxc-device-panel');
    if (!panel) return;
    if (nxcDevicePanelOpen) { panel.style.display='block'; loadAndRenderDevices(); }
    else panel.style.display='none';
  }

  async function loadAndRenderDevices() {
    const panel=document.getElementById('nxc-device-panel');
    if (!panel) return;
    panel.innerHTML='<div style="padding:14px;color:#aaa;font-size:13px;text-align:center;">იტვირთება...</div>';
    if (!navigator.mediaDevices?.enumerateDevices) {
      panel.innerHTML='<div class="nxc-dp-inner"><div class="nxc-dp-title">⚙️ Devices</div><div class="nxc-dp-msg">API მხარდაჭერა არ არის</div></div>';
      return;
    }
    try {
      try { const s=await navigator.mediaDevices.getUserMedia({audio:true}); s.getTracks().forEach(t=>t.stop()); }
      catch(pe) {
        panel.innerHTML='<div class="nxc-dp-inner"><div class="nxc-dp-title">⚙️ Devices</div><div class="nxc-dp-msg">🎤 მიკროფონი დაბლოკილია<br><small>ბრაუზერში გახსენი</small></div></div>';
        return;
      }
      const all=await navigator.mediaDevices.enumerateDevices();
      nxcDevices.inputs=all.filter(d=>d.kind==='audioinput');
      nxcDevices.outputs=all.filter(d=>d.kind==='audiooutput');
      renderDevicePanel();
    } catch(e) {
      panel.innerHTML='<div class="nxc-dp-inner"><div class="nxc-dp-title">⚙️ Devices</div><div class="nxc-dp-msg">შეცდომა</div></div>';
    }
  }

  function renderDevicePanel() {
    const panel=document.getElementById('nxc-device-panel');
    const supportsOutput=typeof document.createElement('audio').setSinkId==='function';
    const makeRadios=(list,name,selId,icon)=>list.map((d,i)=>{
      const lbl=d.label||(icon==='🎤'?'მიკროფონი':'დინამიკი')+' '+(i+1);
      const chk=selId===d.deviceId||(!selId&&(d.deviceId==='default'||i===0));
      return `<label class="nxc-dp-option${chk?' nxc-dp-sel':''}">
        <input type="radio" name="${name}" value="${escHtml(d.deviceId)}" ${chk?'checked':''}}>
        <span class="nxc-dp-icon">${icon}</span>
        <span class="nxc-dp-lbl">${escHtml(lbl)}</span></label>`;
    }).join('');
    const inp=nxcDevices.inputs.length?makeRadios(nxcDevices.inputs,'nxc-input',nxcSelectedInputId,'🎤'):'<div class="nxc-dp-msg">მიკროფონი არ მოიძებნა</div>';
    let out='';
    if (supportsOutput&&nxcDevices.outputs.length) out=`<div class="nxc-dp-section">🔊 Output</div>${makeRadios(nxcDevices.outputs,'nxc-output',nxcSelectedOutputId,'🔊')}`;
    else if (!supportsOutput) out='<div class="nxc-dp-section">🔊 Output</div><div class="nxc-dp-msg" style="font-size:11px;">Chrome/Edge-ზე მუშაობს</div>';
    panel.innerHTML=`<div class="nxc-dp-inner"><div class="nxc-dp-title">⚙️ Audio Devices</div><div class="nxc-dp-section">🎤 Input</div>${inp}${out}</div>`;
    panel.querySelectorAll('input[name="nxc-input"]').forEach(r=>r.addEventListener('change',()=>{
      nxcSelectedInputId=r.value==='default'?null:r.value;
      panel.querySelectorAll('label[class*="nxc-dp-option"]').forEach(l=>{ if(l.querySelector('[name="nxc-input"]')) l.classList.remove('nxc-dp-sel'); });
      r.closest('label')?.classList.add('nxc-dp-sel');
      if(window.showToast) showToast('მიკროფონი შეიცვალა ✅','🎤');
    }));
    panel.querySelectorAll('input[name="nxc-output"]').forEach(r=>r.addEventListener('change',()=>{
      nxcSelectedOutputId=r.value==='default'?null:r.value;
      panel.querySelectorAll('label[class*="nxc-dp-option"]').forEach(l=>{ if(l.querySelector('[name="nxc-output"]')) l.classList.remove('nxc-dp-sel'); });
      r.closest('label')?.classList.add('nxc-dp-sel');
      if(window.showToast) showToast('დინამიკი შეიცვალა ✅','🔊');
    }));
  }

  /* ─────────────────────────────────────────────────────────
     REACTIONS
  ───────────────────────────────────────────────────────── */
  function showReactionPopup(e,msgId,bubbleEl) {
    nxcReactionTarget={msgId,withId:nxcChatWith?.id};
    const popup=document.getElementById('nxc-reaction-popup');
    popup.style.display='flex';
    if (e) { popup.style.left=Math.min(e.clientX,window.innerWidth-220)+'px'; popup.style.top=(e.clientY-50)+'px'; }
    else if (bubbleEl) { const r=bubbleEl.getBoundingClientRect(); popup.style.left=r.left+'px'; popup.style.top=(r.top-50)+'px'; }
  }
  async function sendReaction(e) {
    const emoji=e.currentTarget.dataset.e; if(!nxcReactionTarget) return;
    document.getElementById('nxc-reaction-popup').style.display='none';
    await doReact(nxcReactionTarget.msgId,emoji); nxcReactionTarget=null;
  }
  async function doReact(msgId,emoji) {
    if (!nxcChatWith) return;
    try { await apiCall('chat/chat_api.php?action=react','POST',{with:nxcChatWith.id,msgId,emoji}); await loadMessages(); } catch(e){}
  }

  /* ─────────────────────────────────────────────────────────
     ADMIN
  ───────────────────────────────────────────────────────── */
  async function pinLastMessage() {
    if (!nxcChatWith||!nxcMessages.length) return;
    const last=nxcMessages[nxcMessages.length-1];
    try { await apiCall('chat/chat_api.php?action=pin','POST',{with:nxcChatWith.id,msgId:last.id}); await loadMessages(); if(window.showToast) showToast('დამაგრდა 📌','📌'); } catch(e){}
  }
  async function clearChat() {
    if (!nxcChatWith||!confirm('გასუფთავება?')) return;
    nxcMessages=[]; renderMessages(); if(window.showToast) showToast('გასუფთავდა 🗑','🗑');
  }

  /* ─────────────────────────────────────────────────────────
     WEBRTC CALLING
  ───────────────────────────────────────────────────────── */

  function isSecureContext() {
    return location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1'||location.hostname==='::1';
  }

  async function getMic() {
    const constraints = nxcSelectedInputId
      ? { audio: { deviceId:{exact:nxcSelectedInputId}, echoCancellation:true, noiseSuppression:true } }
      : { audio: { echoCancellation:true, noiseSuppression:true } };
    return navigator.mediaDevices.getUserMedia(constraints);
  }

  function waitForIce(peer, ms) {
    return new Promise(resolve => {
      if (peer.iceGatheringState==='complete') { resolve(); return; }
      const done=()=>{ peer.removeEventListener('icegatheringstatechange',h); resolve(); };
      const h=()=>{ if(peer.iceGatheringState==='complete') done(); };
      peer.addEventListener('icegatheringstatechange',h);
      setTimeout(done,ms);
    });
  }

  async function startCall() {
    if (!nxcChatWith) return;
    if (nxcCallPeer) { if(window.showToast) showToast('ზარი უკვე მიმდინარეობს ❗','❗'); return; }
    if (!isSecureContext()) { if(window.showToast) showToast('🔒 HTTPS ან localhost საჭიროა!','❗'); return; }

    let stream;
    try { stream=await getMic(); }
    catch(err) {
      const m=err.name==='NotAllowedError'?'🎤 მიკროფონი დაბლოკილია — ბრაუზერში გახსენი!':'🎤 მიკროფონი ვერ მოიძებნა ❗';
      if(window.showToast) showToast(m,'❗'); return;
    }

    nxcCallWith=nxcChatWith; nxcCallRole='caller'; nxcLocalStream=stream;
    showActiveCallUI(nxcCallWith,'ringing');

    nxcCallPeer=new RTCPeerConnection(ICE_SERVERS);
    stream.getTracks().forEach(t=>nxcCallPeer.addTrack(t,stream));
    nxcCallPeer.ontrack=e=>{ const a=document.getElementById('nxc-remote-audio'); if(a){a.srcObject=e.streams[0];a.play().catch(()=>{});} };

    const iceList=[];
    nxcCallPeer.onicecandidate=e=>{ if(e.candidate) iceList.push(e.candidate.toJSON()); };

    const offer=await nxcCallPeer.createOffer({offerToReceiveAudio:true});
    await nxcCallPeer.setLocalDescription(offer);
    await waitForIce(nxcCallPeer,2000);

    let cr;
    try {
      cr=await apiCall('chat/chat_api.php?action=call_offer','POST',{
        to:nxcCallWith.id, offer:{type:offer.type,sdp:nxcCallPeer.localDescription.sdp}, iceCandidates:iceList
      });
    } catch(e) { endCall(true); if(window.showToast) showToast('სერვერი ვერ მიაღწია ❗','❗'); return; }
    if (!cr.success) { endCall(true); if(window.showToast) showToast(cr.error||'ზარი ვერ დაიწყო ❗','❗'); return; }

    let attempts=0;
    nxcCallPollTimer=setInterval(async()=>{
      if (++attempts>20) { clearInterval(nxcCallPollTimer); endCall(true); if(window.showToast) showToast('პასუხი არ მოვიდა 📵','📵'); return; }
      try {
        const r=await apiCall(`chat/chat_api.php?action=call_status&with=${nxcCallWith.id}&role=caller`);
        if (!r.success) return;
        const call=r.data?.call;
        if (!call) return;
        if (call.status==='declined') { clearInterval(nxcCallPollTimer); endCall(true); if(window.showToast) showToast('ზარი უარყოფილია 📵','📵'); }
        else if (call.status==='active'&&call.answer&&nxcCallPeer?.signalingState==='have-local-offer') {
          clearInterval(nxcCallPollTimer);
          await nxcCallPeer.setRemoteDescription(new RTCSessionDescription(call.answer));
          for (const c of (call.iceCandidates||[])) { try{await nxcCallPeer.addIceCandidate(new RTCIceCandidate(c));}catch(e){} }
          updateCallStatus('კავშირი დამყარდა 📞'); startCallTimer();
          nxcCallPollTimer=setInterval(()=>pollHangup(nxcCallWith.id,'caller'),4000);
        } else if (call.status==='ended') { clearInterval(nxcCallPollTimer); endCall(true); }
      } catch(e){}
    },2000);
  }

  async function pollHangup(withId,role) {
    try {
      const r=await apiCall(`chat/chat_api.php?action=call_status&with=${withId}&role=${role}`);
      if (r.success&&r.data?.call?.status==='ended') { clearInterval(nxcCallPollTimer); endCall(true); if(window.showToast) showToast('ზარი დასრულდა 📵','📵'); }
    } catch(e){}
  }

  async function pollIncomingCall() {
    if (!nxcCurrentUser||nxcCallPeer||nxcIncomingCallData) return;
    if (document.getElementById('nxc-incoming-call')?.style.display!=='none') return;
    try {
      const r=await apiCall('chat/chat_api.php?action=call_status&role=callee');
      if (!r.success||r.data?.type!=='incoming') return;
      const call=r.data.call;
      if (!call?.offer) return;

      nxcIncomingCallData=call;
      const caller=nxcUsers.find(u=>u.id===call.from)||{id:call.from,firstName:'მომხმარებელი'};
      const name=(caller.firstName+' '+(caller.lastName||'')).trim()||'Unknown';

      const avEl=document.getElementById('nxc-incoming-av');
      if (avEl) { avEl.innerHTML=caller.photo?`<img src="${escHtml(caller.photo)}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`:name[0]?.toUpperCase()||'?'; }
      const nameEl=document.getElementById('nxc-incoming-name');
      if (nameEl) nameEl.textContent=name;
      document.getElementById('nxc-incoming-call').style.display='flex';

      setTimeout(()=>{ if(nxcIncomingCallData===call) rejectCall(); },30000);
    } catch(e){}
  }

  async function acceptCall() {
    if (!nxcIncomingCallData) return;
    const call=nxcIncomingCallData;
    nxcIncomingCallData=null;
    document.getElementById('nxc-incoming-call').style.display='none';

    if (!isSecureContext()) {
      await apiCall('chat/chat_api.php?action=call_answer','POST',{from:call.from,accepted:false}).catch(()=>{});
      if(window.showToast) showToast('🔒 HTTPS საჭიროა ❗','❗'); return;
    }

    nxcCallWith=nxcUsers.find(u=>u.id===call.from)||{id:call.from,firstName:'Unknown'};
    nxcCallRole='callee';
    showActiveCallUI(nxcCallWith,'connecting');

    let stream;
    try { stream=await getMic(); }
    catch(err) {
      await apiCall('chat/chat_api.php?action=call_answer','POST',{from:call.from,accepted:false}).catch(()=>{});
      hideCallUI(); if(window.showToast) showToast('🎤 მიკროფონი ვერ გაიხსნა ❗','❗'); return;
    }
    nxcLocalStream=stream;

    nxcCallPeer=new RTCPeerConnection(ICE_SERVERS);
    stream.getTracks().forEach(t=>nxcCallPeer.addTrack(t,stream));
    nxcCallPeer.ontrack=e=>{ const a=document.getElementById('nxc-remote-audio'); if(a){a.srcObject=e.streams[0];a.play().catch(()=>{});} };

    const iceList=[];
    nxcCallPeer.onicecandidate=e=>{ if(e.candidate) iceList.push(e.candidate.toJSON()); };

    try {
      await nxcCallPeer.setRemoteDescription(new RTCSessionDescription(call.offer));
      for (const c of (call.iceCandidates||[])) { try{await nxcCallPeer.addIceCandidate(new RTCIceCandidate(c));}catch(e){} }
      const answer=await nxcCallPeer.createAnswer();
      await nxcCallPeer.setLocalDescription(answer);
      await waitForIce(nxcCallPeer,2000);

      await apiCall('chat/chat_api.php?action=call_answer','POST',{
        from:call.from, accepted:true,
        answer:{type:answer.type,sdp:nxcCallPeer.localDescription.sdp},
        iceCandidates:iceList
      });

      updateCallStatus('კავშირი დამყარდა 📞'); startCallTimer();
      nxcCallPollTimer=setInterval(()=>pollHangup(call.from,'callee'),4000);
    } catch(err) {
      console.error('Accept call error:',err);
      await apiCall('chat/chat_api.php?action=call_answer','POST',{from:call.from,accepted:false}).catch(()=>{});
      endCall(true); if(window.showToast) showToast('კავშირის შეცდომა ❗','❗');
    }
  }

  async function rejectCall() {
    const call=nxcIncomingCallData; nxcIncomingCallData=null;
    document.getElementById('nxc-incoming-call').style.display='none';
    if (call?.from) await apiCall('chat/chat_api.php?action=call_answer','POST',{from:call.from,accepted:false}).catch(()=>{});
  }

  async function endCall(silent=false) {
    clearInterval(nxcCallPollTimer); clearInterval(nxcCallTimer);
    nxcCallTimer=null; nxcCallSec=0;
    if (!silent&&nxcCallWith) apiCall('chat/chat_api.php?action=call_hangup','POST',{with:nxcCallWith.id}).catch(()=>{});
    if (nxcCallPeer) { nxcCallPeer.ontrack=null; nxcCallPeer.onicecandidate=null; nxcCallPeer.close(); nxcCallPeer=null; }
    if (nxcLocalStream) { nxcLocalStream.getTracks().forEach(t=>t.stop()); nxcLocalStream=null; }
    const a=document.getElementById('nxc-remote-audio'); if(a) a.srcObject=null;
    nxcCallWith=null; nxcCallRole=null; nxcCallMuted=false;
    hideCallUI();
  }

  function toggleCallMute() {
    if (!nxcLocalStream) return;
    nxcCallMuted=!nxcCallMuted;
    nxcLocalStream.getAudioTracks().forEach(t=>{t.enabled=!nxcCallMuted;});
    const btn=document.getElementById('nxc-call-mute');
    if (btn) btn.textContent=nxcCallMuted?'🔇':'🎤';
    if(window.showToast) showToast(nxcCallMuted?'მიკროფონი გამოირთო 🔇':'მიკროფონი ჩაირთო 🎤','🎤');
  }

  function showActiveCallUI(user,statusKey) {
    const el=document.getElementById('nxc-active-call'); if(!el) return;
    const name=user?((user.firstName+' '+(user.lastName||'')).trim()||user.email||'—'):'—';
    const avEl=document.getElementById('nxc-active-call-av');
    if (avEl) { avEl.innerHTML=user?.photo?`<img src="${escHtml(user.photo)}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`:name[0]?.toUpperCase()||'?'; }
    document.getElementById('nxc-active-call-name').textContent=name;
    updateCallStatus(statusKey==='ringing'?'🔔 ელოდება...':statusKey==='connecting'?'🔄 უკავშირდება...':statusKey);
    const t=document.getElementById('nxc-active-call-timer'); if(t) t.textContent='';
    const m=document.getElementById('nxc-call-mute'); if(m) m.textContent='🎤';
    el.style.display='flex';
  }

  function updateCallStatus(text) { const el=document.getElementById('nxc-active-call-status'); if(el) el.textContent=text; }
  function hideCallUI() {
    const a=document.getElementById('nxc-active-call'); if(a) a.style.display='none';
    const b=document.getElementById('nxc-incoming-call'); if(b) b.style.display='none';
  }
  function startCallTimer() {
    nxcCallSec=0; clearInterval(nxcCallTimer);
    nxcCallTimer=setInterval(()=>{ nxcCallSec++; const m=Math.floor(nxcCallSec/60),s=nxcCallSec%60; const el=document.getElementById('nxc-active-call-timer'); if(el) el.textContent=`${m}:${s.toString().padStart(2,'0')}`; },1000);
  }

  /* ─────────────────────────────────────────────────────────
     HELPERS
  ───────────────────────────────────────────────────────── */
  function autoResize(el) { el.style.height='auto'; el.style.height=Math.min(el.scrollHeight,100)+'px'; }
  function escHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function formatDate(d) {
    const today=new Date(),yest=new Date(); yest.setDate(yest.getDate()-1);
    if (d.toDateString()===today.toDateString()) return 'დღეს';
    if (d.toDateString()===yest.toDateString()) return 'გუშინ';
    return d.toLocaleDateString('ka-GE',{day:'numeric',month:'long'});
  }
  function formatTime(d) { return d.toLocaleTimeString('ka-GE',{hour:'2-digit',minute:'2-digit'}); }

})();
