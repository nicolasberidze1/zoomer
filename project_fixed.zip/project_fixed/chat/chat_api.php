<?php
// ═══════════════════════════════════════════════════════════
// TECHZONE — Chat API
// /chat/chat_api.php
//
// GET    ?action=conversations           → my conversation list
// GET    ?action=messages&with=USER_ID   → messages with user
// GET    ?action=users                   → user list (for starting chat)
// POST   ?action=send                    → send message
// POST   ?action=typing                  → typing indicator
// GET    ?action=typing&with=USER_ID     → check if other typing
// POST   ?action=read&with=USER_ID       → mark messages as read
// GET    ?action=unread                  → total unread count
// ═══════════════════════════════════════════════════════════

require_once __DIR__ . '/../api/config.php';

$CHAT_DIR = __DIR__ . '/../data/chat/';
if (!is_dir($CHAT_DIR)) mkdir($CHAT_DIR, 0755, true);
if (!is_dir($CHAT_DIR . 'typing/')) mkdir($CHAT_DIR . 'typing/', 0755, true);

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

requireAuth();
$me = currentUser();
$myId = $me['id'];

// ── Helpers ─────────────────────────────────────────────────

function chatFile(string $a, string $b): string {
    global $CHAT_DIR;
    $ids = [$a, $b];
    sort($ids);
    return $CHAT_DIR . implode('_', $ids) . '.json';
}

function readChat(string $file): array {
    if (!file_exists($file)) return [];
    return json_decode(file_get_contents($file), true) ?: [];
}

function writeChat(string $file, array $msgs): void {
    file_put_contents($file, json_encode($msgs, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

function safeUserPublic(array $u): array {
    return [
        'id'        => $u['id'],
        'firstName' => $u['firstName'] ?? '',
        'lastName'  => $u['lastName'] ?? '',
        'email'     => $u['email'] ?? '',
        'photo'     => $u['photo'] ?? null,
        'role'      => $u['role'] ?? 'user',
        'lastLogin' => $u['lastLogin'] ?? null,
    ];
}

// ── GET: users list ──────────────────────────────────────────
if ($method === 'GET' && $action === 'users') {
    $all = readUsers();
    $result = [];
    foreach ($all as $u) {
        if ($u['id'] === $myId) continue;
        $su = safeUserPublic($u);
        // get last message
        $file = chatFile($myId, $u['id']);
        $msgs = readChat($file);
        $last = end($msgs) ?: null;
        $unread = 0;
        foreach ($msgs as $m) {
            if ($m['to'] === $myId && !($m['read'] ?? false)) $unread++;
        }
        $su['lastMessage'] = $last;
        $su['unread'] = $unread;
        $result[] = $su;
    }
    // sort: unread first, then by last message time
    usort($result, function($a, $b) {
        if ($a['unread'] !== $b['unread']) return $b['unread'] - $a['unread'];
        $at = $a['lastMessage']['time'] ?? 0;
        $bt = $b['lastMessage']['time'] ?? 0;
        return $bt <=> $at;
    });
    jsonOk($result);
}

// ── GET: messages with user ──────────────────────────────────
if ($method === 'GET' && $action === 'messages') {
    $withId = $_GET['with'] ?? '';
    if (!$withId) jsonErr('with param required');
    $withUser = findUserById($withId);
    if (!$withUser) jsonErr('User not found', 404);

    $file = chatFile($myId, $withId);
    $msgs = readChat($file);
    jsonOk([
        'messages' => $msgs,
        'user'     => safeUserPublic($withUser),
    ]);
}

// ── GET: unread count ────────────────────────────────────────
if ($method === 'GET' && $action === 'unread') {
    global $CHAT_DIR;
    $total = 0;
    $files = glob($CHAT_DIR . '*.json') ?: [];
    foreach ($files as $f) {
        if (strpos($f, $myId) === false) continue;
        $msgs = readChat($f);
        foreach ($msgs as $m) {
            if ($m['to'] === $myId && !($m['read'] ?? false)) $total++;
        }
    }
    jsonOk(['count' => $total]);
}

// ── GET: typing status ───────────────────────────────────────
if ($method === 'GET' && $action === 'typing') {
    global $CHAT_DIR;
    $withId = $_GET['with'] ?? '';
    $file = $CHAT_DIR . 'typing/' . $withId . '_' . $myId . '.txt';
    $typing = false;
    if (file_exists($file)) {
        $ts = (int)file_get_contents($file);
        $typing = (time() - $ts) < 4;
    }
    jsonOk(['typing' => $typing]);
}

// ── POST: typing indicator ───────────────────────────────────
if ($method === 'POST' && $action === 'typing') {
    global $CHAT_DIR;
    $body  = json_decode(file_get_contents('php://input'), true) ?: [];
    $toId  = $body['to'] ?? '';
    $file  = $CHAT_DIR . 'typing/' . $myId . '_' . $toId . '.txt';
    file_put_contents($file, time());
    jsonOk(['ok' => true]);
}

// ── POST: send message ───────────────────────────────────────
if ($method === 'POST' && $action === 'send') {
    requireCsrf();
    $body  = json_decode(file_get_contents('php://input'), true) ?: [];
    $toId  = sanitizeString($body['to']   ?? '');
    $type  = $body['type'] ?? 'text'; // text | emoji | sticker | gif | voice | image
    $text  = $body['text'] ?? '';
    $media = $body['media'] ?? null; // URL or base64 for gif/sticker/voice

    if (!$toId) jsonErr('to required');
    $toUser = findUserById($toId);
    if (!$toUser) jsonErr('User not found', 404);
    if (!$text && !$media) jsonErr('text or media required');

    $msg = [
        'id'     => bin2hex(random_bytes(8)),
        'from'   => $myId,
        'to'     => $toId,
        'type'   => $type,
        'text'   => $type === 'text' ? mb_substr($text, 0, 2000) : ($text ?: ''),
        'media'  => $media,
        'time'   => time(),
        'read'   => false,
        'reactions' => [],
    ];

    $file = chatFile($myId, $toId);
    $msgs = readChat($file);
    $msgs[] = $msg;
    // keep last 500 messages
    if (count($msgs) > 500) $msgs = array_slice($msgs, -500);
    writeChat($file, $msgs);

    jsonOk($msg);
}

// ── POST: mark read ──────────────────────────────────────────
if ($method === 'POST' && $action === 'read') {
    $body  = json_decode(file_get_contents('php://input'), true) ?: [];
    $withId = $body['with'] ?? $_GET['with'] ?? '';
    if (!$withId) jsonErr('with required');

    $file = chatFile($myId, $withId);
    $msgs = readChat($file);
    foreach ($msgs as &$m) {
        if ($m['to'] === $myId) $m['read'] = true;
    }
    writeChat($file, $msgs);
    jsonOk(['ok' => true]);
}

// ── POST: react to message ───────────────────────────────────
if ($method === 'POST' && $action === 'react') {
    requireCsrf();
    $body  = json_decode(file_get_contents('php://input'), true) ?: [];
    $withId = $body['with'] ?? '';
    $msgId  = $body['msgId'] ?? '';
    $emoji  = mb_substr($body['emoji'] ?? '', 0, 4);
    if (!$withId || !$msgId || !$emoji) jsonErr('required params missing');

    $file = chatFile($myId, $withId);
    $msgs = readChat($file);
    foreach ($msgs as &$m) {
        if ($m['id'] === $msgId) {
            $reactions = $m['reactions'] ?? [];
            $existing = null;
            foreach ($reactions as $k => $r) {
                if ($r['emoji'] === $emoji) { $existing = $k; break; }
            }
            if ($existing !== null) {
                $uidx = array_search($myId, $reactions[$existing]['users']);
                if ($uidx !== false) {
                    array_splice($reactions[$existing]['users'], $uidx, 1);
                    if (empty($reactions[$existing]['users'])) array_splice($reactions, $existing, 1);
                } else {
                    $reactions[$existing]['users'][] = $myId;
                }
            } else {
                $reactions[] = ['emoji' => $emoji, 'users' => [$myId]];
            }
            $m['reactions'] = array_values($reactions);
            break;
        }
    }
    writeChat($file, $msgs);
    jsonOk(['ok' => true]);
}

// ── POST: delete message ─────────────────────────────────────
if ($method === 'POST' && $action === 'delete') {
    requireCsrf();
    $body  = json_decode(file_get_contents('php://input'), true) ?: [];
    $withId = $body['with'] ?? '';
    $msgId  = $body['msgId'] ?? '';

    $file = chatFile($myId, $withId);
    $msgs = readChat($file);
    foreach ($msgs as &$m) {
        if ($m['id'] === $msgId && $m['from'] === $myId) {
            $m['deleted'] = true;
            $m['text'] = '';
            $m['media'] = null;
            break;
        }
    }
    writeChat($file, $msgs);
    jsonOk(['ok' => true]);
}

// ── CALL SIGNALING ────────────────────────────────────────
// File-based WebRTC signaling for peer-to-peer calls
// call signal file: data/chat/calls/{callerId}_{calleeId}.json

function callFile(string $a, string $b): string {
    global $CHAT_DIR;
    $dir = $CHAT_DIR . 'calls/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    return $dir . $a . '_' . $b . '.json';
}

function readCall(string $file): array {
    if (!file_exists($file)) return [];
    $age = time() - filemtime($file);
    if ($age > 60) { @unlink($file); return []; } // stale call
    return json_decode(file_get_contents($file), true) ?: [];
}

// POST: initiate call offer
if ($method === 'POST' && $action === 'call_offer') {
    $body   = json_decode(file_get_contents('php://input'), true) ?: [];
    $toId   = $body['to'] ?? '';
    $offer  = $body['offer'] ?? null;
    $ice    = $body['iceCandidates'] ?? [];
    if (!$toId || !$offer) jsonErr('to and offer required');
    $toUser = findUserById($toId);
    if (!$toUser) jsonErr('User not found', 404);

    $data = [
        'callId'       => bin2hex(random_bytes(8)),
        'from'         => $myId,
        'to'           => $toId,
        'status'       => 'ringing',
        'offer'        => $offer,
        'iceCandidates'=> $ice,   // caller's ICE candidates sent with offer
        'answer'       => null,
        'iceCallee'    => [],     // callee's ICE candidates sent with answer
        'created'      => time(),
    ];
    // Remove any stale incoming call for this pair
    foreach ([callFile($myId, $toId), callFile($toId, $myId)] as $f) {
        if (file_exists($f)) @unlink($f);
    }
    $file = callFile($myId, $toId);
    file_put_contents($file, json_encode($data));
    jsonOk(['callId' => $data['callId']]);
}

// POST: answer a call
if ($method === 'POST' && $action === 'call_answer') {
    $body     = json_decode(file_get_contents('php://input'), true) ?: [];
    $fromId   = $body['from'] ?? '';
    $answer   = $body['answer'] ?? null;
    $ice      = $body['iceCandidates'] ?? [];
    $accepted = (bool)($body['accepted'] ?? false);
    if (!$fromId) jsonErr('from required');

    $file = callFile($fromId, $myId);
    $data = readCall($file);
    if (empty($data)) jsonErr('Call not found', 404);
    $data['status'] = $accepted ? 'active' : 'declined';
    if ($answer && $accepted) {
        $data['answer']    = $answer;
        $data['iceCallee'] = $ice;
    }
    file_put_contents($file, json_encode($data));
    jsonOk(['ok' => true]);
}

// POST: ICE candidate exchange
if ($method === 'POST' && $action === 'call_ice') {
    $body      = json_decode(file_get_contents('php://input'), true) ?: [];
    $withId    = $body['with'] ?? '';
    $candidate = $body['candidate'] ?? null;
    $isCaller  = (bool)($body['isCaller'] ?? false);
    if (!$withId || !$candidate) jsonErr('with and candidate required');

    // Caller writes to callFile(myId, withId), callee writes to callFile(withId, myId)
    $file = $isCaller ? callFile($myId, $withId) : callFile($withId, $myId);
    $data = readCall($file);
    if (empty($data)) jsonErr('Call not found', 404);

    $iceKey = $isCaller ? 'iceCaller' : 'iceCallee';
    $data[$iceKey][] = $candidate;
    file_put_contents($file, json_encode($data));
    jsonOk(['ok' => true]);
}

// POST: hang up
if ($method === 'POST' && $action === 'call_hangup') {
    $body   = json_decode(file_get_contents('php://input'), true) ?: [];
    $withId = $body['with'] ?? '';
    if (!$withId) jsonErr('with required');

    // Try both call file orientations
    $file1 = callFile($myId, $withId);
    $file2 = callFile($withId, $myId);
    foreach ([$file1, $file2] as $f) {
        if (file_exists($f)) {
            $d = json_decode(file_get_contents($f), true) ?: [];
            $d['status'] = 'ended';
            file_put_contents($f, json_encode($d));
        }
    }
    jsonOk(['ok' => true]);
}

// GET: poll call status (both callee polling for incoming and caller for answer)
if ($method === 'GET' && $action === 'call_status') {
    $withId = $_GET['with'] ?? '';
    $role   = $_GET['role'] ?? ''; // 'caller' | 'callee' | ''

    // CALLER: check status of my outgoing call
    if ($role === 'caller' && $withId) {
        $file = callFile($myId, $withId);
        $data = readCall($file);
        jsonOk(['type' => 'outgoing', 'call' => $data ?: null]);
    }

    // CALLEE: poll for any incoming calls from anyone
    if ($role === 'callee') {
        $callsDir = $CHAT_DIR . 'calls/';
        if (is_dir($callsDir)) {
            $files = glob($callsDir . '*.json') ?: [];
            foreach ($files as $f) {
                $d = readCall($f);
                if (!empty($d) && $d['to'] === $myId && $d['status'] === 'ringing') {
                    jsonOk(['type' => 'incoming', 'call' => $d]);
                }
            }
        }
        jsonOk(['type' => 'none']);
    }

    // Generic: check both directions
    if ($withId) {
        // Check if someone called me
        $file = callFile($withId, $myId);
        $d = readCall($file);
        if (!empty($d) && $d['to'] === $myId && $d['status'] === 'ringing') {
            jsonOk(['type' => 'incoming', 'call' => $d]);
        }
        // Check my outgoing call
        $file2 = callFile($myId, $withId);
        $d2 = readCall($file2);
        if (!empty($d2)) {
            jsonOk(['type' => 'outgoing', 'call' => $d2]);
        }
    }

    // Scan all incoming calls
    $callsDir = $CHAT_DIR . 'calls/';
    if (is_dir($callsDir)) {
        $files = glob($callsDir . '*.json') ?: [];
        foreach ($files as $f) {
            $d = readCall($f);
            if (!empty($d) && $d['to'] === $myId && $d['status'] === 'ringing') {
                jsonOk(['type' => 'incoming', 'call' => $d]);
            }
        }
    }

    jsonOk(['type' => 'none']);
}

// ── POST: pin message (admin only) ───────────────────────────
if ($method === 'POST' && $action === 'pin') {
    requireRole(ROLE_ADMIN);
    requireCsrf();
    $body  = json_decode(file_get_contents('php://input'), true) ?: [];
    $withId = $body['with'] ?? '';
    $msgId  = $body['msgId'] ?? '';

    $file = chatFile($myId, $withId);
    $msgs = readChat($file);
    foreach ($msgs as &$m) {
        $m['pinned'] = ($m['id'] === $msgId) ? true : false;
    }
    writeChat($file, $msgs);
    jsonOk(['ok' => true]);
}

jsonErr('Unknown action', 400);
