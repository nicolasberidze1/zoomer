/* ══════════════════════════════════════════════════
   EZZWAY — Dynamic Data Loader  /data/data.js
══════════════════════════════════════════════════ */

var SLIDES = [
    { bg: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=1800&q=80', badge: '💻 პრემიუმ ლეპტოპები', title: 'ULTRA<em>THIN</em>POWER',   sub: 'სამუშაო სადმეც სადაც ხარ — თინი, მსუბუქი, სწრაფი.',                          cta1: 'იყიდე ახლა', cta2: 'სპეციფ.' },
    { bg: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=1800&q=80', badge: '🎧 Hi-Fi ხმა',         title: 'PURE<em>SOUND</em>STUDIO',   sub: 'მუსიკა ისეთი სახით, როგორც შექმნეს — ყოველი ნოტი, ყოველი დეტალი.',   cta1: 'მოსინჯე',    cta2: 'სია'    },
    { bg: 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?w=1800&q=80', badge: '🖥️ სამუშაო სივრცე',  title: 'BUILD<em>YOUR</em>SETUP',     sub: 'პერფექტული სამუშაო სივრცე — მონიტორი, კლავიატურა, სინათლე.',           cta1: 'სეტაპი',     cta2: 'ინსპ.'  },
];

var CATS = [];

/* ── Promise — always resolves ── */
var _catsResolve;
window.__catsPromise = new Promise(function(resolve) {
    _catsResolve = resolve;
});

/* ── Retry fetch ── */
function _fetchJSON(url, retries) {
    return fetch(url, { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
        .then(function(res) {
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return res.json();
        })
        .catch(function(err) {
            if (retries > 0) {
                return new Promise(function(r) { setTimeout(r, 500); })
                    .then(function() { return _fetchJSON(url, retries - 1); });
            }
            throw err;
        });
}

/* ── Load CATS from API ── */
_fetchJSON('api/products.php', 2)
    .then(function(data) {
        if (data && data.success && data.data && Array.isArray(data.data.cats)) {
            CATS = data.data.cats;
        }
    })
    .catch(function(err) {
        console.warn('[EZZWAY] Products API unavailable:', err.message);
    })
    .then(function() {
        /* Always runs — resolve with whatever CATS contains */
        _catsResolve(CATS);
        /* Fire legacy event for filter.js */
        document.dispatchEvent(new CustomEvent('cats-ready', { detail: CATS }));
    });
