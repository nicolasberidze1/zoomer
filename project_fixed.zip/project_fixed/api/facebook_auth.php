<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonErr('Method Not Allowed', 405);

if (!FACEBOOK_APP_ID || !FACEBOOK_APP_SECRET) jsonErr('Facebook App ID/Secret არ არის კონფიგურირებული. api/config.php-ში შეავსე FACEBOOK_APP_ID და FACEBOOK_APP_SECRET');

$body        = json_decode(file_get_contents('php://input'), true) ?: [];
$accessToken = $body['accessToken'] ?? '';
$fbUserId    = $body['userID']      ?? '';

if (!$accessToken || !$fbUserId) jsonErr('Facebook access token გვჭირდება');

// Verify token
$appToken  = FACEBOOK_APP_ID . '|' . FACEBOOK_APP_SECRET;
$verifyUrl = "https://graph.facebook.com/debug_token?input_token={$accessToken}&access_token=" . urlencode($appToken);
$verifyRes = @file_get_contents($verifyUrl);
if (!$verifyRes) jsonErr('Facebook ვერიფიკაცია ვერ მოხერხდა');

$verify = json_decode($verifyRes, true);
if (empty($verify['data']['is_valid']) || $verify['data']['user_id'] !== $fbUserId) {
    jsonErr('Facebook token არასწორია');
}

// Get user info
$fields   = 'id,name,email,first_name,last_name,picture.type(large)';
$infoUrl  = "https://graph.facebook.com/{$fbUserId}?fields={$fields}&access_token=" . urlencode($accessToken);
$infoRes  = @file_get_contents($infoUrl);
if (!$infoRes) jsonErr('Facebook მომხმარებლის ინფო ვერ მოიძებნა');

$info      = json_decode($infoRes, true);
$email     = $info['email']      ?? ($fbUserId . '@facebook.com');
$firstName = $info['first_name'] ?? 'Facebook';
$lastName  = $info['last_name']  ?? 'User';
$photo     = $info['picture']['data']['url'] ?? null;

$users   = readUsers();
$isFirst = empty($users);

$user = findUserByEmail($email);
if (!$user) {
    $user = [
        'id'         => generateId(),
        'firstName'  => sanitizeString($firstName, 50),
        'lastName'   => sanitizeString($lastName, 50),
        'email'      => strtolower($email),
        'password'   => password_hash(generateId(), PASSWORD_BCRYPT, ['cost' => 12]),
        'role'       => $isFirst ? ROLE_ADMIN : ROLE_USER,
        'phone'      => '',
        'bio'        => '',
        'photo'      => $photo,
        'cart'       => [],
        'wishlist'   => [],
        'orders'     => [],
        'totalSpent' => 0,
        'createdAt'  => date('Y-m-d H:i:s'),
        'lastLogin'  => date('Y-m-d H:i:s'),
        'provider'   => 'facebook',
        'facebookId' => $fbUserId,
    ];
    $users[] = $user;
    writeUsers($users);
} else {
    if (empty($user['role'])) $user['role'] = ROLE_USER;
    $user['lastLogin'] = date('Y-m-d H:i:s');
    if ($photo && !$user['photo']) $user['photo'] = $photo;
    updateUser($user);
}

$_SESSION['user_id'] = $user['id'];
$csrfToken = generateCsrfToken();

jsonOk(array_merge(safeUser($user), ['csrf_token' => $csrfToken]));
