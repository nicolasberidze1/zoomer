<?php
// ═══════════════════════════════════════════════════════════
// EZZWAY — Auth Me API
// /api/me.php
// Returns current user info + fresh CSRF token
// ═══════════════════════════════════════════════════════════
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') jsonErr('Method Not Allowed', 405);

$user = currentUser();
if (!$user) {
    // Return guest info with csrf token
    jsonOk([
        'user'       => null,
        'role'       => ROLE_GUEST,
        'csrf_token' => generateCsrfToken(),
    ]);
}

// Ensure role exists
if (empty($user['role'])) {
    $user['role'] = ROLE_USER;
    updateUser($user);
}

jsonOk([
    'user'       => safeUser($user),
    'role'       => $user['role'],
    'csrf_token' => generateCsrfToken(),
]);
