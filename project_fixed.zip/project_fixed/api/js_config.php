<?php
// Output buffering to capture any warnings/notices from config.php silently
ob_start();
require_once __DIR__ . '/config.php';
ob_end_clean();

// Override headers — output clean JavaScript
header('Content-Type: application/javascript; charset=utf-8');
header('Cache-Control: no-cache, no-store');

$fbAppId       = defined('FACEBOOK_APP_ID')   ? FACEBOOK_APP_ID   : '';
$googleClientId = defined('GOOGLE_CLIENT_ID') ? GOOGLE_CLIENT_ID  : '';

echo 'window.FB_APP_ID='          . json_encode($fbAppId        ?: null) . ';' . "\n";
echo 'window.GOOGLE_CLIENT_ID='   . json_encode($googleClientId ?: null) . ';' . "\n";
