<?php
// ═══════════════════════════════════════════════════════════
// EZZWAY — Login API
// /api/login.php
// ═══════════════════════════════════════════════════════════
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonErr('Method Not Allowed', 405);

// Rate limit: 10 login attempts per minute per IP
rateLimit('login_' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 10, 60);

$body     = json_decode(file_get_contents('php://input'), true) ?: [];
$email    = trim($body['email']    ?? '');
$password = $body['password']      ?? '';
$remember = (bool)($body['remember'] ?? false);

if (!$email || !$password) jsonErr('ელ-ფოსტა და პაროლი სავალდებულოა');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonErr('ელ-ფოსტა არასწორია');

$user = findUserByEmail($email);
if (!$user) jsonErr('ასეთი ანგარიში არ მოიძებნა');
if (!password_verify($password, $user['password'])) jsonErr('პაროლი არასწორია');

// Ensure all users have a role (legacy users default to 'user')
if (empty($user['role'])) {
    $user['role'] = ROLE_USER;
}

$user['lastLogin'] = date('Y-m-d H:i:s');
updateUser($user);

$_SESSION['user_id'] = $user['id'];
$_SESSION['remember'] = $remember;

// FIX: session_set_cookie_params() after session_start() has no effect.
// We override the session cookie directly using setcookie().
if ($remember) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        session_id(),
        [
            'expires'  => time() + 60 * 60 * 24 * 30, // 30 days
            'path'     => $params['path'],
            'domain'   => $params['domain'],
            'secure'   => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => 'Lax',
        ]
    );
}

// Generate CSRF token for this session
$csrfToken = generateCsrfToken();

jsonOk(array_merge(safeUser($user), ['csrf_token' => $csrfToken]));
