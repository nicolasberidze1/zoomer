<?php
// ═══════════════════════════════════════════════════════════
// EZZWAY — Categories API
// /api/categories.php
//
// GET    /api/categories.php          → all categories (public)
// POST   /api/categories.php          → create category [moderator+]
// PUT    /api/categories.php          → update category [moderator+]
// DELETE /api/categories.php          → delete category [admin]
// ═══════════════════════════════════════════════════════════
require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'];
$body   = json_decode(file_get_contents('php://input'), true) ?: [];

// ── GET ──────────────────────────────────────────────────────
if ($method === 'GET') {
    $data = readProducts();
    usort($data['categories'], fn($a, $b) => ($a['order'] ?? 99) - ($b['order'] ?? 99));
    jsonOk($data['categories']);
}

// ── POST — Create ─────────────────────────────────────────────
if ($method === 'POST') {
    requireAuth();
    requireRole(ROLE_MODERATOR);
    requireCsrf();

    if (empty($body['label'])) jsonErr('სახელი სავალდებულოა');

    $data = readProducts();
    $maxOrder = array_reduce($data['categories'], fn($c, $i) => max($c, $i['order'] ?? 0), 0);

    $cat = [
        'id'    => 'cat_' . generateId(),
        'label' => sanitizeString($body['label'], 100),
        'img'   => filter_var($body['img'] ?? '', FILTER_VALIDATE_URL) ? $body['img'] : '',
        'order' => $maxOrder + 1,
    ];
    $data['categories'][] = $cat;
    writeProducts($data);
    jsonOk($cat);
}

// ── PUT — Update ──────────────────────────────────────────────
if ($method === 'PUT') {
    requireAuth();
    requireRole(ROLE_MODERATOR);
    requireCsrf();

    $id = sanitizeString($body['id'] ?? '');
    if (!$id) jsonErr('ID სავალდებულოა');

    $data  = readProducts();
    $found = false;
    foreach ($data['categories'] as &$c) {
        if ($c['id'] === $id) {
            if (isset($body['label'])) $c['label'] = sanitizeString($body['label'], 100);
            if (isset($body['img']))   $c['img']   = filter_var($body['img'], FILTER_VALIDATE_URL) ? $body['img'] : $c['img'];
            if (isset($body['order'])) $c['order'] = (int)$body['order'];
            $found   = true;
            $updated = $c;
            break;
        }
    }

    if (!$found) jsonErr('კატეგორია ვერ მოიძებნა', 404);
    writeProducts($data);
    jsonOk($updated);
}

// ── DELETE ────────────────────────────────────────────────────
if ($method === 'DELETE') {
    requireAuth();
    requireRole(ROLE_ADMIN);
    requireCsrf();

    $id = sanitizeString($body['id'] ?? $_GET['id'] ?? '');
    if (!$id) jsonErr('ID სავალდებულოა');

    $data = readProducts();

    // Check if category has products
    $hasProducts = !empty(array_filter($data['products'], fn($p) => $p['category_id'] === $id));
    if ($hasProducts) jsonErr('კატეგორიას აქვს პროდუქტები. ჯერ წაშალეთ ან გადაიტანეთ პროდუქტები.');

    $before = count($data['categories']);
    $data['categories'] = array_values(array_filter($data['categories'], fn($c) => $c['id'] !== $id));
    if (count($data['categories']) === $before) jsonErr('კატეგორია ვერ მოიძებნა', 404);

    writeProducts($data);
    jsonOk(['deleted' => $id]);
}
