<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonErr('Method Not Allowed', 405);

if (!GOOGLE_CLIENT_ID) jsonErr('Google Client ID არ არის კონფიგურირებული. api/config.php-ში შეავსე GOOGLE_CLIENT_ID');

$body      = json_decode(file_get_contents('php://input'), true) ?: [];
$credential = $body['credential'] ?? '';
if (!$credential) jsonErr('Google credential გვჭირდება');

$response = @file_get_contents(
    'https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($credential)
);
if (!$response) jsonErr('Google ვერიფიკაცია ვერ მოხერხდა');

$info = json_decode($response, true);
if (empty($info['email']) || empty($info['sub'])) jsonErr('Google token არასწორია');
if ($info['aud'] !== GOOGLE_CLIENT_ID) jsonErr('Client ID არ ემთხვევა');

$email     = $info['email'];
$firstName = $info['given_name']  ?? 'Google';
$lastName  = $info['family_name'] ?? 'User';
$photo     = $info['picture']     ?? null;
$googleId  = $info['sub'];

$users   = readUsers();
$isFirst = empty($users);

$user = findUserByEmail($email);
if (!$user) {
    $user = [
        'id'         => generateId(),
        'firstName'  => sanitizeString($firstName, 50),
        'lastName'   => sanitizeString($lastName, 50),
        'email'      => strtolower($email),
        'password'   => password_hash(generateId(), PASSWORD_BCRYPT, ['cost' => 12]),
        'role'       => $isFirst ? ROLE_ADMIN : ROLE_USER,
        'phone'      => '',
        'bio'        => '',
        'photo'      => $photo,
        'cart'       => [],
        'wishlist'   => [],
        'orders'     => [],
        'totalSpent' => 0,
        'createdAt'  => date('Y-m-d H:i:s'),
        'lastLogin'  => date('Y-m-d H:i:s'),
        'provider'   => 'google',
        'googleId'   => $googleId,
    ];
    $users[] = $user;
    writeUsers($users);
} else {
    if (empty($user['role'])) $user['role'] = ROLE_USER;
    $user['lastLogin'] = date('Y-m-d H:i:s');
    if ($photo && !$user['photo']) $user['photo'] = $photo;
    updateUser($user);
}

$_SESSION['user_id'] = $user['id'];
$csrfToken = generateCsrfToken();

jsonOk(array_merge(safeUser($user), ['csrf_token' => $csrfToken]));
