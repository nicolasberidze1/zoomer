<?php
// ═══════════════════════════════════════════════════════════
// EZZWAY — Register API
// /api/register.php
// ═══════════════════════════════════════════════════════════
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonErr('Method Not Allowed', 405);

// Rate limit: 5 registrations per 10 min per IP
rateLimit('register_' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 5, 600);

$body      = json_decode(file_get_contents('php://input'), true) ?: [];
$firstName = trim($body['firstName'] ?? '');
$lastName  = trim($body['lastName']  ?? '');
$email     = trim($body['email']     ?? '');
$password  = $body['password']       ?? '';

if (!$firstName || !$lastName || !$email || !$password) jsonErr('ყველა ველი სავალდებულოა');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonErr('ელ-ფოსტა არასწორია');
if (mb_strlen($password) < 8) jsonErr('პაროლი მინიმუმ 8 სიმბოლო');
if (findUserByEmail($email)) jsonErr('ეს ელ-ფოსტა უკვე გამოყენებულია');

// First ever user gets admin role automatically
$users   = readUsers();
$isFirst = empty($users);

$user = [
    'id'         => generateId(),
    'firstName'  => sanitizeString($firstName, 50),
    'lastName'   => sanitizeString($lastName, 50),
    'email'      => strtolower($email),
    'password'   => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
    'role'       => $isFirst ? ROLE_ADMIN : ROLE_USER,
    'phone'      => '',
    'bio'        => '',
    'photo'      => null,
    'cart'       => [],
    'wishlist'   => [],
    'orders'     => [],
    'totalSpent' => 0,
    'createdAt'  => date('Y-m-d H:i:s'),
    'lastLogin'  => date('Y-m-d H:i:s'),
    'provider'   => 'email',
];

$users[] = $user;
writeUsers($users);

$_SESSION['user_id'] = $user['id'];
$csrfToken = generateCsrfToken();

jsonOk(array_merge(safeUser($user), ['csrf_token' => $csrfToken]));
