<?php
require_once __DIR__ . '/config.php';
echo json_encode(['appId' => FACEBOOK_APP_ID ?: null]);
