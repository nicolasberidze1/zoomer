<?php
// ═══════════════════════════════════════════════════════════
// EZZWAY — Core Config + Auth + Role System
// /api/config.php
// ═══════════════════════════════════════════════════════════

define('USERS_FILE',    __DIR__ . '/../data/users/users.json');
define('PHOTOS_DIR',    __DIR__ . '/../data/users-photos/');
define('PHOTOS_URL',    'data/users-photos/');
define('PRODUCTS_FILE', __DIR__ . '/../data/products.json');

// ── Google OAuth ─────────────────────────────────────────
define('GOOGLE_CLIENT_ID',    '');
// ── Facebook OAuth ────────────────────────────────────────
define('FACEBOOK_APP_ID',     '2412596752535602');
define('FACEBOOK_APP_SECRET', '1461b4504d1e8091d414290165abf229');

// ── Role Hierarchy ─────────────────────────────────────────
// guest(0) < user(1) < editor(2) < moderator(3) < admin(4)
define('ROLE_GUEST',     'guest');
define('ROLE_USER',      'user');
define('ROLE_EDITOR',    'editor');
define('ROLE_MODERATOR', 'moderator');
define('ROLE_ADMIN',     'admin');

const ROLE_LEVELS = [
    'guest'     => 0,
    'user'      => 1,
    'editor'    => 2,
    'moderator' => 3,
    'admin'     => 4,
];

// ── Session Setup ──────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_name('ezzway_session');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => false,   // true in production (HTTPS)
        'httponly' => true,    // prevent JS access
        'samesite' => 'Lax',
    ]);
    session_start();
}

// Regenerate session ID periodically (anti-hijacking)
if (!isset($_SESSION['_init'])) {
    session_regenerate_id(true);
    $_SESSION['_init'] = time();
} elseif (time() - $_SESSION['_init'] > 300) {
    session_regenerate_id(true);
    $_SESSION['_init'] = time();
    // If user chose "remember me", re-extend the new session cookie
    if (!empty($_SESSION['remember'])) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            session_id(),
            [
                'expires'  => time() + 60 * 60 * 24 * 30,
                'path'     => $params['path'],
                'domain'   => $params['domain'],
                'secure'   => $params['secure'],
                'httponly' => $params['httponly'],
                'samesite' => 'Lax',
            ]
        );
    }
}

// ── CORS / Headers ─────────────────────────────────────────
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed_origins = ['http://localhost', 'http://127.0.0.1'];
if (in_array($origin, $allowed_origins, true)) {
    header("Access-Control-Allow-Origin: $origin");
    header('Access-Control-Allow-Credentials: true');
}
header('Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ── CSRF Protection ─────────────────────────────────────────
function generateCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken(): bool {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN']
          ?? $_POST['csrf_token']
          ?? (json_decode(file_get_contents('php://input'), true)['csrf_token'] ?? '');
    return hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

// Enforce CSRF on state-changing requests
function requireCsrf(): void {
    if (in_array($_SERVER['REQUEST_METHOD'], ['POST','PUT','DELETE'], true)) {
        if (!verifyCsrfToken()) {
            jsonErr('CSRF token არასწორია', 403);
        }
    }
}

// ── Rate Limiting (simple file-based) ──────────────────────
function rateLimit(string $key, int $maxCalls = 10, int $windowSec = 60): void {
    $dir  = sys_get_temp_dir() . '/ezzway_rl/';
    if (!is_dir($dir)) mkdir($dir, 0700, true);
    $file = $dir . md5($key) . '.json';
    $now  = time();

    $data = file_exists($file) ? (json_decode(file_get_contents($file), true) ?: []) : [];
    $data = array_filter($data, fn($t) => $t > $now - $windowSec);

    if (count($data) >= $maxCalls) {
        http_response_code(429);
        echo json_encode(['success' => false, 'error' => 'ძალიან ბევრი მოთხოვნა. ცადეთ მოგვიანებით.']);
        exit;
    }
    $data[] = $now;
    file_put_contents($file, json_encode(array_values($data)));
}

// ── User Helpers ────────────────────────────────────────────
function readUsers(): array {
    $f = USERS_FILE;
    if (!file_exists($f)) { file_put_contents($f, '[]'); return []; }
    return json_decode(file_get_contents($f), true) ?: [];
}

function writeUsers(array $users): void {
    file_put_contents(USERS_FILE, json_encode(array_values($users), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function findUserByEmail(string $email): ?array {
    foreach (readUsers() as $u) {
        if (strtolower($u['email']) === strtolower($email)) return $u;
    }
    return null;
}

function findUserById(string $id): ?array {
    foreach (readUsers() as $u) {
        if ($u['id'] === $id) return $u;
    }
    return null;
}

function updateUser(array $updated): void {
    $users = readUsers();
    foreach ($users as &$u) {
        if ($u['id'] === $updated['id']) { $u = $updated; break; }
    }
    writeUsers($users);
}

// ── Product Helpers ─────────────────────────────────────────
function readProducts(): array {
    $f = PRODUCTS_FILE;
    if (!file_exists($f)) {
        $empty = ['categories' => [], 'products' => []];
        file_put_contents($f, json_encode($empty, JSON_PRETTY_PRINT));
        return $empty;
    }
    return json_decode(file_get_contents($f), true) ?: ['categories' => [], 'products' => []];
}

function writeProducts(array $data): void {
    file_put_contents(PRODUCTS_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// ── Role Helpers ─────────────────────────────────────────────
function currentUser(): ?array {
    $id = $_SESSION['user_id'] ?? null;
    if (!$id) return null;
    return findUserById($id);
}

function currentRole(): string {
    $user = currentUser();
    return $user['role'] ?? ROLE_GUEST;
}

function hasRole(string $minRole): bool {
    $current = currentRole();
    return (ROLE_LEVELS[$current] ?? 0) >= (ROLE_LEVELS[$minRole] ?? 99);
}

function requireRole(string $minRole): void {
    if (!hasRole($minRole)) {
        jsonErr('წვდომა უარყოფილია — საჭირო როლი: ' . $minRole, 403);
    }
}

function requireAuth(): void {
    if (!currentUser()) {
        jsonErr('ავტორიზაცია საჭიროა', 401);
    }
}

// ── Response Helpers ─────────────────────────────────────────
function jsonOk(mixed $data = null): void {
    echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonErr(string $msg, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['success' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

// ── Misc Helpers ─────────────────────────────────────────────
function generateId(): string {
    return bin2hex(random_bytes(12));
}

function safeUser(array $u): array {
    $safe = $u;
    unset($safe['password']);
    return $safe;
}

function sanitizeString(string $val, int $max = 255): string {
    return mb_substr(htmlspecialchars(trim($val), ENT_QUOTES | ENT_HTML5, 'UTF-8'), 0, $max);
}

function currentUserId(): ?string {
    return $_SESSION['user_id'] ?? null;
}
