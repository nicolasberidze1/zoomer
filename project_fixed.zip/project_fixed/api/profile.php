<?php
require_once __DIR__ . '/config.php';

$uid = currentUserId();

// ── GET: return profile ───────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!$uid) jsonOk(null); // not logged in → return null (not error)
    $user = findUserById($uid);
    if (!$user) { session_destroy(); jsonOk(null); }
    jsonOk(safeUser($user));
}

// ── POST: update profile ──────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$uid) jsonErr('ავტორიზაცია საჭიროა', 401);

    $body      = json_decode(file_get_contents('php://input'), true) ?: [];
    $user      = findUserById($uid);
    if (!$user) jsonErr('მომხმარებელი ვერ მოიძებნა', 404);

    $allowed = ['firstName','lastName','phone','bio'];
    foreach ($allowed as $field) {
        if (isset($body[$field])) {
            $user[$field] = trim($body[$field]);
        }
    }

    // Change password
    if (!empty($body['newPassword'])) {
        if (empty($body['currentPassword'])) jsonErr('მიმდინარე პაროლი საჭიროა');
        if (!password_verify($body['currentPassword'], $user['password'])) jsonErr('მიმდინარე პაროლი არასწორია');
        if (mb_strlen($body['newPassword']) < 8) jsonErr('ახალი პაროლი მინ. 8 სიმბოლო');
        $user['password'] = password_hash($body['newPassword'], PASSWORD_DEFAULT);
    }

    updateUser($user);
    jsonOk(safeUser($user));
}

jsonErr('Method Not Allowed', 405);
