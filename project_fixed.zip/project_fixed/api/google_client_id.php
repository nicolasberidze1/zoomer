<?php
require_once __DIR__ . '/config.php';
echo json_encode(['client_id' => GOOGLE_CLIENT_ID ?: null]);
