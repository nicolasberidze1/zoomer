<?php
// ═══════════════════════════════════════════════════════════
// EZZWAY — Products API
// /api/products.php
//
// GET    /api/products.php              → public CATS format (filter)
// GET    /api/products.php?admin=1      → all products (admin view)
// POST   /api/products.php              → create product  [editor+]
// PUT    /api/products.php              → update product  [editor+]
// DELETE /api/products.php              → delete product  [moderator+]
// ═══════════════════════════════════════════════════════════
require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'];
$body   = json_decode(file_get_contents('php://input'), true) ?: [];

// ── GET ──────────────────────────────────────────────────────
if ($method === 'GET') {
    $data = readProducts();

    // Admin view — return raw data (requires editor+)
    if (!empty($_GET['admin'])) {
        requireAuth();
        requireRole(ROLE_EDITOR);
        jsonOk($data);
    }

    // Allow short browser cache on public endpoint (30 seconds)
    header('Cache-Control: public, max-age=30, stale-while-revalidate=60');
    $catMap = [];
    foreach ($data['categories'] as $cat) {
        $catMap[$cat['id']] = $cat;
    }

    usort($data['categories'], fn($a, $b) => ($a['order'] ?? 99) - ($b['order'] ?? 99));

    $cats = [];
    foreach ($data['categories'] as $cat) {
        $products = array_values(array_filter($data['products'], function($p) use ($cat) {
            return $p['category_id'] === $cat['id']
                && ($p['active'] ?? true)
                && ($p['show_in_filter'] ?? true);
        }));

        // Format price as ₾XXX string for filter compatibility
        $formatted = array_map(function($p) {
            return [
                'id'      => $p['id'],
                'name'    => $p['name'],
                'desc'    => $p['desc'],
                'price'   => '₾' . number_format($p['price'], 0, '.', ','),
                'badge'   => $p['badge'],
                'rating'  => (int)$p['rating'],
                'reviews' => (int)$p['reviews'],
                'img'     => $p['img'],
            ];
        }, $products);

        if (!empty($formatted)) {
            $cats[] = [
                'label'    => $cat['label'],
                'img'      => $cat['img'],
                'products' => $formatted,
            ];
        }
    }

    jsonOk(['cats' => $cats]);
}

// ── POST — Create Product ────────────────────────────────────
if ($method === 'POST') {
    requireAuth();
    requireRole(ROLE_EDITOR);
    requireCsrf();

    $errors = validateProductInput($body);
    if ($errors) jsonErr(implode(', ', $errors));

    $data    = readProducts();
    $product = buildProduct($body);
    $data['products'][] = $product;
    writeProducts($data);

    jsonOk($product);
}

// ── PUT — Update Product ─────────────────────────────────────
if ($method === 'PUT') {
    requireAuth();
    requireRole(ROLE_EDITOR);
    requireCsrf();

    $id = sanitizeString($body['id'] ?? '');
    if (!$id) jsonErr('პროდუქტის ID საჭიროა');

    $data = readProducts();
    $found = false;
    foreach ($data['products'] as &$p) {
        if ($p['id'] === $id) {
            // Merge updates
            if (isset($body['name']))           $p['name']           = sanitizeString($body['name'], 200);
            if (isset($body['desc']))           $p['desc']           = sanitizeString($body['desc'], 500);
            if (isset($body['price']))          $p['price']          = max(0, (int)$body['price']);
            if (isset($body['badge']))          $p['badge']          = $body['badge'] ? sanitizeString($body['badge'], 50) : null;
            if (isset($body['rating']))         $p['rating']         = max(1, min(5, (int)$body['rating']));
            if (isset($body['reviews']))        $p['reviews']        = max(0, (int)$body['reviews']);
            if (isset($body['img']))            $p['img']            = filter_var($body['img'], FILTER_VALIDATE_URL) ? $body['img'] : $p['img'];
            if (isset($body['category_id']))    $p['category_id']    = sanitizeString($body['category_id'], 50);
            if (isset($body['show_in_filter'])) $p['show_in_filter'] = (bool)$body['show_in_filter'];
            if (isset($body['active']))         $p['active']         = (bool)$body['active'];
            $p['updatedAt'] = date('Y-m-d H:i:s');
            $found = true;
            $updated = $p;
            break;
        }
    }

    if (!$found) jsonErr('პროდუქტი ვერ მოიძებნა', 404);
    writeProducts($data);
    jsonOk($updated);
}

// ── DELETE — Delete Product ──────────────────────────────────
if ($method === 'DELETE') {
    requireAuth();
    requireRole(ROLE_MODERATOR);
    requireCsrf();

    $id = sanitizeString($body['id'] ?? $_GET['id'] ?? '');
    if (!$id) jsonErr('პროდუქტის ID საჭიროა');

    $data    = readProducts();
    $before  = count($data['products']);
    $data['products'] = array_values(array_filter($data['products'], fn($p) => $p['id'] !== $id));

    if (count($data['products']) === $before) jsonErr('პროდუქტი ვერ მოიძებნა', 404);
    writeProducts($data);
    jsonOk(['deleted' => $id]);
}

// ── Helpers ──────────────────────────────────────────────────
function validateProductInput(array $body): array {
    $errors = [];
    if (empty($body['name']))        $errors[] = 'სახელი სავალდებულოა';
    if (empty($body['category_id'])) $errors[] = 'კატეგორია სავალდებულოა';
    if (!isset($body['price']) || (int)$body['price'] < 0) $errors[] = 'ფასი სავალდებულოა';
    if (!empty($body['img']) && !filter_var($body['img'], FILTER_VALIDATE_URL)) $errors[] = 'სურათის URL არასწორია';
    return $errors;
}

function buildProduct(array $body): array {
    return [
        'id'             => generateId(),
        'category_id'    => sanitizeString($body['category_id'], 50),
        'name'           => sanitizeString($body['name'], 200),
        'desc'           => sanitizeString($body['desc'] ?? '', 500),
        'price'          => max(0, (int)$body['price']),
        'badge'          => !empty($body['badge']) ? sanitizeString($body['badge'], 50) : null,
        'rating'         => max(1, min(5, (int)($body['rating'] ?? 5))),
        'reviews'        => max(0, (int)($body['reviews'] ?? 0)),
        'img'            => filter_var($body['img'] ?? '', FILTER_VALIDATE_URL) ? $body['img'] : '',
        'show_in_filter' => (bool)($body['show_in_filter'] ?? true),
        'active'         => (bool)($body['active'] ?? true),
        'createdAt'      => date('Y-m-d H:i:s'),
        'updatedAt'      => date('Y-m-d H:i:s'),
    ];
}
