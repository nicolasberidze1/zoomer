<?php
require_once __DIR__ . '/config.php';

$uid = currentUserId();
if (!$uid) jsonErr('ავტორიზაცია საჭიროა', 401);

$user = findUserById($uid);
if (!$user) jsonErr('მომხმარებელი ვერ მოიძებნა', 404);

$method = $_SERVER['REQUEST_METHOD'];
$body   = json_decode(file_get_contents('php://input'), true) ?: [];

// ── GET: return cart ─────────────────────
if ($method === 'GET') {
    jsonOk($user['cart'] ?? []);
}

// ── POST: add item ───────────────────────
if ($method === 'POST') {
    $name  = trim($body['name']  ?? '');
    $price = trim($body['price'] ?? '');
    $img   = trim($body['img']   ?? '');
    $cat   = trim($body['cat']   ?? '');
    if (!$name || !$price) jsonErr('პროდუქტის მონაცემები სავალდებულოა');

    // Check duplicate
    foreach ($user['cart'] as &$item) {
        if ($item['name'] === $name) {
            $item['qty'] = ($item['qty'] ?? 1) + 1;
            updateUser($user);
            jsonOk($user['cart']);
        }
    }

    $user['cart'][] = [
        'id'    => generateId(),
        'name'  => $name,
        'price' => $price,
        'img'   => $img,
        'cat'   => $cat,
        'qty'   => 1,
        'addedAt' => date('Y-m-d H:i:s'),
    ];
    updateUser($user);
    jsonOk($user['cart']);
}

// ── DELETE: remove item ──────────────────
if ($method === 'DELETE') {
    $itemId = $body['id'] ?? '';
    if (!$itemId) jsonErr('item id საჭიროა');
    $user['cart'] = array_values(array_filter($user['cart'], fn($i) => $i['id'] !== $itemId));
    updateUser($user);
    jsonOk($user['cart']);
}

// ── PUT: update qty ─────────────────────
if ($method === 'PUT') {
    $itemId = $body['id']  ?? '';
    $qty    = (int)($body['qty'] ?? 1);
    if (!$itemId) jsonErr('item id საჭიროა');
    if ($qty < 1) {
        $user['cart'] = array_values(array_filter($user['cart'], fn($i) => $i['id'] !== $itemId));
    } else {
        foreach ($user['cart'] as &$item) {
            if ($item['id'] === $itemId) { $item['qty'] = $qty; break; }
        }
    }
    updateUser($user);
    jsonOk($user['cart']);
}

jsonErr('Method Not Allowed', 405);
