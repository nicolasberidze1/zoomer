<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonErr('Method Not Allowed', 405);

$uid = currentUserId();
if (!$uid) jsonErr('ავტორიზაცია საჭიროა', 401);

if (empty($_FILES['photo'])) jsonErr('ფოტო ვერ მოიძებნა');

$file = $_FILES['photo'];
if ($file['error'] !== UPLOAD_ERR_OK) jsonErr('ატვირთვა ვერ მოხერხდა');

$maxSize = 5 * 1024 * 1024; // 5MB
if ($file['size'] > $maxSize) jsonErr('ფოტო 5MB-ზე მეტი არ უნდა იყოს');

$mime = mime_content_type($file['tmp_name']);
$allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
if (!in_array($mime, $allowed)) jsonErr('მხოლოდ JPG, PNG, WEBP, GIF ფოტოები');

// Extension
$ext = match($mime) {
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
    'image/webp' => 'webp',
    'image/gif'  => 'gif',
};

// Save
if (!is_dir(PHOTOS_DIR)) mkdir(PHOTOS_DIR, 0755, true);

$user = findUserById($uid);

// Delete old photo
if (!empty($user['photo'])) {
    $oldPath = __DIR__ . '/../' . $user['photo'];
    if (file_exists($oldPath)) @unlink($oldPath);
}

$filename = $uid . '_' . time() . '.' . $ext;
$destPath = PHOTOS_DIR . $filename;
if (!move_uploaded_file($file['tmp_name'], $destPath)) jsonErr('ფაილის შენახვა ვერ მოხერხდა');

// Update user
$user['photo'] = PHOTOS_URL . $filename;
updateUser($user);

jsonOk(['photoUrl' => $user['photo']]);
