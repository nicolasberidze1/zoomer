<?php
// ═══════════════════════════════════════════════════════════
// EZZWAY — Users Admin API
// /api/users_admin.php
//
// GET    /api/users_admin.php          → list users    [moderator+]
// PUT    /api/users_admin.php          → update role   [admin only]
// DELETE /api/users_admin.php          → delete user   [admin only]
// ═══════════════════════════════════════════════════════════
require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'];
$body   = json_decode(file_get_contents('php://input'), true) ?: [];

requireAuth();

// ── GET — List Users ─────────────────────────────────────────
if ($method === 'GET') {
    requireRole(ROLE_MODERATOR);
    $users = array_map('safeUser', readUsers());
    jsonOk($users);
}

// ── PUT — Update Role ─────────────────────────────────────────
if ($method === 'PUT') {
    requireRole(ROLE_ADMIN);
    requireCsrf();

    $targetId = sanitizeString($body['id']   ?? '');
    $newRole  = sanitizeString($body['role'] ?? '');

    if (!$targetId || !$newRole) jsonErr('ID და role სავალდებულოა');
    if (!array_key_exists($newRole, ROLE_LEVELS)) jsonErr('არასწორი role: ' . $newRole);

    // Cannot demote another admin (only superadmin pattern — first user)
    $me = currentUser();
    if ($targetId === $me['id']) jsonErr('საკუთარ role-ს ვერ შეცვლი');

    $target = findUserById($targetId);
    if (!$target) jsonErr('მომხმარებელი ვერ მოიძებნა', 404);

    // Admin cannot elevate someone to admin unless they are also admin
    if ($newRole === ROLE_ADMIN && $me['role'] !== ROLE_ADMIN) {
        jsonErr('მხოლოდ ადმინი ადმინს დანიშნავს', 403);
    }

    $target['role']      = $newRole;
    $target['updatedAt'] = date('Y-m-d H:i:s');
    updateUser($target);
    jsonOk(safeUser($target));
}

// ── DELETE — Delete User ──────────────────────────────────────
if ($method === 'DELETE') {
    requireRole(ROLE_ADMIN);
    requireCsrf();

    $targetId = sanitizeString($body['id'] ?? $_GET['id'] ?? '');
    if (!$targetId) jsonErr('ID სავალდებულოა');

    $me = currentUser();
    if ($targetId === $me['id']) jsonErr('საკუთარ ანგარიშს ვერ წაშლი');

    $users  = readUsers();
    $before = count($users);
    $users  = array_values(array_filter($users, fn($u) => $u['id'] !== $targetId));
    if (count($users) === $before) jsonErr('მომხმარებელი ვერ მოიძებნა', 404);

    writeUsers($users);
    jsonOk(['deleted' => $targetId]);
}
