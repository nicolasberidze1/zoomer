/* ═══════════════════════════════════════════════
   SECTIONS NAVIGATION — sections.js
   ელემენტი: sections folder-ის ყველა სექცია
═══════════════════════════════════════════════ */
(function() {
  'use strict';

  // Each entry: [trackId, prevBtnId, nextBtnId, itemWidth, gap]
  const SECTION_CONFIGS = [
    ['sonic-track',      'sonic-prev',      'sonic-next',      220, 16],
    ['ultrabook-track',  'ultrabook-prev',  'ultrabook-next',  215, 16],
    ['rig-track',        'rig-prev',        'rig-next',        215, 16],
    ['click-track',      'click-prev',      'click-next',      215, 16],
    ['keystroke-track',  'keystroke-prev',  'keystroke-next',  215, 16],
    ['screen-track',     'screen-prev',     'screen-next',     215, 16],
    ['arena-track',      'arena-prev',      'arena-next',      215, 16],
    ['mobile-track',     'mobile-prev',     'mobile-next',     215, 16],
    ['stream-track',     'stream-prev',     'stream-next',     215, 16],
    ['audio-track',      'audio-prev',      'audio-next',      215, 16],
  ];

  SECTION_CONFIGS.forEach(function(cfg) {
    var trackId  = cfg[0];
    var prevId   = cfg[1];
    var nextId   = cfg[2];
    var itemW    = cfg[3];
    var gap      = cfg[4];
    var step     = itemW + gap;

    var track = document.getElementById(trackId);
    var prevBtn = document.getElementById(prevId);
    var nextBtn = document.getElementById(nextId);

    if (!track || !prevBtn || !nextBtn) return;

    var offset = 0;

    function getMax() {
      var items = track.children.length;
      var wrapW = track.parentElement ? track.parentElement.offsetWidth : 0;
      var visible = Math.max(1, Math.floor(wrapW / step));
      return Math.max(0, (items - visible) * step);
    }

    function slideTo(newOffset) {
      var max = getMax();
      offset = Math.max(0, Math.min(newOffset, max));
      track.style.transform = 'translateX(-' + offset + 'px)';
    }

    prevBtn.addEventListener('click', function() {
      slideTo(offset - step);
    });

    nextBtn.addEventListener('click', function() {
      slideTo(offset + step);
    });

    // Touch swipe support
    var touchStartX = 0;
    track.addEventListener('touchstart', function(e) {
      touchStartX = e.touches[0].clientX;
    }, { passive: true });
    track.addEventListener('touchend', function(e) {
      var dx = touchStartX - e.changedTouches[0].clientX;
      if (Math.abs(dx) > 40) {
        slideTo(dx > 0 ? offset + step : offset - step);
      }
    }, { passive: true });
  });

})();
