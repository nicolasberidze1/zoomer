<!DOCTYPE html>
<html lang="ka">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TechZone</title>
<?php include 'components/styles.html'; ?>
</head>
<body>
<?php include 'components/loader.html'; ?>

<?php include 'components/header.html'; ?>
<div class="wrap">

<?php include 'components/hero.html'; ?>
<?php include 'components/divider.html'; ?>
<br>
<?php include 'components/bottom.html'; ?>

<!-- ══════════════════════ CATEGORY SECTIONS ══════════════════════ -->

<?php include 'sections/headphones.html'; ?>
<br>
<?php include 'sections/laptops.html'; ?>
<br>
<?php include 'sections/computers.html'; ?>
<br>
<?php include 'sections/mouse.html'; ?>
<br>
<?php include 'sections/keyboard.html'; ?>
<br>
<?php include 'sections/monitor.html'; ?>
<br>
<?php include 'sections/gaming.html'; ?>
<br>
<?php include 'sections/smartphones.html'; ?>
<br>
<?php include 'sections/webcam.html'; ?>
<br>
<?php include 'sections/speakers.html'; ?>

<?php include 'components/footer.html'; ?>

<!-- ══════════════════════ MODALS ══════════════════════ -->

<?php include 'components/modals/login.html'; ?>

<?php include 'components/modals/register.html'; ?>

<?php include 'components/modals/profile.html'; ?>

<?php include 'components/modals/payment.html'; ?>

<?php include 'components/toast.html'; ?>

<?php include 'filter/filter.html'; ?>

<!-- ══════════════════════ NEXCHAT ══════════════════════ -->
<?php include 'chat/chat_modal.html'; ?>

<?php include 'components/scripts.html'; ?>
</div>
</body>
</html>
