/* ══════════════════════════════════════════════════
   EZZWAY — ADVANCED FILTER SYSTEM
   /filter/filter.js
   
   Updated: waits for 'cats-ready' event from data.js
   (API-loaded CATS instead of hardcoded)
══════════════════════════════════════════════════ */
(function () {
    'use strict';

    /* ─── STATE ──────────────────────────────────────── */
    const state = {
        open: false,
        search: '',
        categories: new Set(),
        priceMin: 0,
        priceMax: Infinity,
        rating: null,
        badges: new Set(),
        sort: 'default',
        view: 'grid',
    };

    /* ─── CONSTANTS ──────────────────────────────────── */
    const PAGE_SIZE = 12;
    const SORT_OPTIONS = [
        { id: 'default',      label: 'სტანდარტული',    icon: '◈' },
        { id: 'price-asc',    label: 'ფასი: იაფიდან',  icon: '↑' },
        { id: 'price-desc',   label: 'ფასი: ძვირიდან', icon: '↓' },
        { id: 'rating-desc',  label: 'რეიტინგი',        icon: '★' },
        { id: 'reviews-desc', label: 'მიმოხილვები',    icon: '💬' },
        { id: 'name-asc',     label: 'სახელი A-Z',     icon: 'Az' },
    ];
    const RATING_OPTIONS = [
        { val: 5, label: 'მხოლოდ 5 ★' },
        { val: 4, label: '4+ ★' },
    ];

    /* ─── DERIVED DATA ────────────────────────────────── */
    let allProducts = [];
    let filteredProducts = [];
    let renderedCount = 0;

    function buildAllProducts() {
        allProducts = [];
        CATS.forEach(cat => {
            cat.products.forEach(p => {
                allProducts.push({ ...p, catLabel: cat.label, catImg: cat.img });
            });
        });
    }

    function parsePriceGEL(str) {
        return parseInt((str || '').replace(/[^\d]/g, ''), 10) || 0;
    }

    /* ─── PRICE BOUNDS ───────────────────────────────── */
    let PRICE_GLOBAL_MIN = 0;
    let PRICE_GLOBAL_MAX = 9999;

    function calcPriceBounds() {
        const prices = allProducts.map(p => parsePriceGEL(p.price));
        PRICE_GLOBAL_MIN = Math.min(...prices);
        PRICE_GLOBAL_MAX = Math.max(...prices);
        state.priceMin = PRICE_GLOBAL_MIN;
        state.priceMax = PRICE_GLOBAL_MAX;
    }

    /* ─── DOM REFS ───────────────────────────────────── */
    const overlay    = document.getElementById('filter-overlay');
    const modal      = document.getElementById('filter-modal');
    const closeBtn   = document.getElementById('fm-close-btn');
    const searchEl   = document.getElementById('fm-search');
    const searchClear= document.getElementById('fm-search-clear');
    const catBody    = document.getElementById('fms-cat-body');
    const catCount   = document.getElementById('fms-cat-count');
    const rangeMin   = document.getElementById('fm-range-min');
    const rangeMax   = document.getElementById('fm-range-max');
    const rangeFill  = document.getElementById('fm-range-fill');
    const pMinLabel  = document.getElementById('fm-price-min-label');
    const pMaxLabel  = document.getElementById('fm-price-max-label');
    const priceCount = document.getElementById('fms-price-count');
    const ratingOpts = document.getElementById('fm-rating-opts');
    const ratingCount= document.getElementById('fms-rating-count');
    const badgeOpts  = document.getElementById('fm-badge-opts');
    const badgeCount = document.getElementById('fms-badge-count');
    const sortOpts   = document.getElementById('fm-sort-opts');
    const grid       = document.getElementById('fm-grid');
    const spinner    = document.getElementById('fm-spinner');
    const sentinel   = document.getElementById('fm-sentinel');
    const countLabel = document.getElementById('fm-count-label');
    const rightCount = document.getElementById('fm-right-count');
    const chipsEl    = document.getElementById('fm-chips');
    const viewGrid   = document.getElementById('fm-view-grid');
    const viewList   = document.getElementById('fm-view-list');
    const filterBtn  = document.getElementById('hdr-filter-btn');

    /* ─── INIT ───────────────────────────────────────── */
    function init() {
        buildAllProducts();
        if (allProducts.length === 0) {
            // Show loading skeleton if no products yet
            renderSkeletons(8);
        } else {
            calcPriceBounds();
            buildCategoryItems();
            buildRatingOptions();
            buildBadgeOptions();
            buildSortOptions();
            initRangeSlider();
        }
        bindEvents();
        bindSectionToggles();
        initIntersectionObserver();
    }

    /* ─── OPEN / CLOSE ────────────────────────────────── */
    function openFilter() {
        state.open = true;
        overlay.classList.add('open');
        modal.classList.add('open');
        document.body.style.overflow = 'hidden';
        filterBtn.classList.add('active');
        searchEl.focus();
        applyAndRender();
    }

    function closeFilter() {
        state.open = false;
        overlay.classList.remove('open');
        modal.classList.remove('open');
        document.body.style.overflow = '';
        filterBtn.classList.remove('active');
    }

    /* ─── FILTER LOGIC ───────────────────────────────── */
    function applyFilters() {
        const q = state.search.toLowerCase().trim();

        filteredProducts = allProducts.filter(p => {
            if (q) {
                const haystack = (p.name + ' ' + p.desc + ' ' + p.catLabel).toLowerCase();
                if (!haystack.includes(q)) return false;
            }
            if (state.categories.size > 0 && !state.categories.has(p.catLabel)) return false;
            const price = parsePriceGEL(p.price);
            if (price < state.priceMin || price > state.priceMax) return false;
            if (state.rating !== null && p.rating < state.rating) return false;
            if (state.badges.size > 0) {
                if (!p.badge || !state.badges.has(p.badge)) return false;
            }
            return true;
        });

        filteredProducts = sortProducts(filteredProducts);
    }

    function sortProducts(arr) {
        const a = [...arr];
        switch (state.sort) {
            case 'price-asc':    return a.sort((x,y) => parsePriceGEL(x.price) - parsePriceGEL(y.price));
            case 'price-desc':   return a.sort((x,y) => parsePriceGEL(y.price) - parsePriceGEL(x.price));
            case 'rating-desc':  return a.sort((x,y) => y.rating - x.rating);
            case 'reviews-desc': return a.sort((x,y) => y.reviews - x.reviews);
            case 'name-asc':     return a.sort((x,y) => x.name.localeCompare(y.name));
            default: return a;
        }
    }

    /* ─── RENDER ─────────────────────────────────────── */
    function applyAndRender() {
        applyFilters();
        renderedCount = 0;
        grid.innerHTML = '';
        updateCountLabels();
        updateChips();
        updateFilterCountBadges();
        renderNextBatch();
    }

    function renderNextBatch() {
        if (renderedCount >= filteredProducts.length) {
            spinner.classList.remove('vis');
            if (filteredProducts.length === 0) renderNoResults();
            return;
        }
        const batch = filteredProducts.slice(renderedCount, renderedCount + PAGE_SIZE);
        batch.forEach((p, i) => {
            const card = createCard(p, renderedCount + i);
            grid.appendChild(card);
        });
        renderedCount += batch.length;
        spinner.classList.remove('vis');
    }

    function renderSkeletons(count = 8) {
        grid.innerHTML = '';
        for (let i = 0; i < count; i++) {
            const s = document.createElement('div');
            s.className = 'fm-skel';
            s.innerHTML = `<div class="fm-skel-img"></div><div class="fm-skel-body"><div class="fm-skel-line w80"></div><div class="fm-skel-line w55"></div><div class="fm-skel-line w40"></div></div>`;
            s.style.animationDelay = (i * 0.06) + 's';
            grid.appendChild(s);
        }
    }

    function renderNoResults() {
        grid.innerHTML = `
            <div class="fm-no-results" style="grid-column:1/-1">
                <div class="fm-no-results-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
                        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        <line x1="8" y1="11" x2="14" y2="11"/>
                    </svg>
                </div>
                <div class="fm-no-results-text">პროდუქტი ვერ მოიძებნა</div>
                <div class="fm-no-results-sub">სხვა ფილტრი სცადეთ ან გაასუფთავეთ</div>
            </div>`;
    }

    /* ─── CARD BUILDER ───────────────────────────────── */
    function starsHTML(rating, cls1 = 'fc-star f', cls2 = 'fc-star e') {
        let h = '';
        for (let i = 1; i <= 5; i++) {
            h += `<svg class="${i <= rating ? cls1 : cls2}" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>`;
        }
        return h;
    }

    function createCard(p, idx) {
        const c = document.createElement('div');
        c.className = 'fm-card';
        c.style.animationDelay = ((idx % PAGE_SIZE) * 0.04) + 's';

        if (state.view === 'list') {
            c.innerHTML = `
                <div class="fm-card-img">
                    ${p.badge ? `<span class="fm-card-badge">${p.badge}</span>` : ''}
                    <img src="${p.img}" alt="${p.name}" loading="lazy"/>
                </div>
                <div class="fm-card-body">
                    <div class="fm-card-info">
                        <div class="fm-card-cat-tag" style="position:static;display:inline-block;margin-bottom:5px">${p.catLabel}</div>
                        <div class="fm-card-name">${p.name}</div>
                        <div class="fm-card-desc">${p.desc}</div>
                        <div class="fm-card-stars">${starsHTML(p.rating)}<span class="fm-card-rv">(${p.reviews})</span></div>
                    </div>
                    <div class="fm-card-foot">
                        <div class="fm-card-price">${p.price} <sub>GEL</sub></div>
                        <button class="fm-card-add" title="კალათაში დამატება">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
                        </button>
                    </div>
                </div>`;
        } else {
            c.innerHTML = `
                <div class="fm-card-img">
                    ${p.badge ? `<span class="fm-card-badge">${p.badge}</span>` : ''}
                    <span class="fm-card-cat-tag">${p.catLabel}</span>
                    <img src="${p.img}" alt="${p.name}" loading="lazy"/>
                </div>
                <div class="fm-card-body">
                    <div class="fm-card-name">${p.name}</div>
                    <div class="fm-card-desc">${p.desc}</div>
                    <div class="fm-card-stars">${starsHTML(p.rating)}<span class="fm-card-rv">(${p.reviews})</span></div>
                    <div class="fm-card-foot">
                        <div class="fm-card-price">${p.price} <sub>GEL</sub></div>
                        <button class="fm-card-add" title="კალათაში დამატება">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
                        </button>
                    </div>
                </div>`;
        }

        const addBtn = c.querySelector('.fm-card-add');
        if (addBtn) {
            addBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (typeof addToCart === 'function') {
                    addToCart({ name: p.name, price: p.price, img: p.img, cat: p.catLabel });
                }
            });
        }
        return c;
    }

    /* ─── COUNT LABELS ────────────────────────────────── */
    function updateCountLabels() {
        const total = filteredProducts.length;
        countLabel.textContent = total + ' პროდუქტი';
        rightCount.textContent = total;
        const badge = document.querySelector('.hdr-filter-btn .filter-badge');
        if (badge) badge.textContent = total;
    }

    /* ─── CHIPS ───────────────────────────────────────── */
    function updateChips() {
        chipsEl.innerHTML = '';
        let hasAny = false;

        if (state.search.trim()) {
            hasAny = true;
            addChip('🔍 ' + state.search.trim(), () => {
                state.search = '';
                searchEl.value = '';
                searchClear.classList.remove('vis');
                applyAndRender();
            });
        }
        state.categories.forEach(cat => {
            hasAny = true;
            addChip('📦 ' + cat, () => {
                state.categories.delete(cat);
                document.querySelectorAll('.fm-cat-item').forEach(el => {
                    if (el.dataset.cat === cat) el.classList.remove('selected');
                });
                updateCatSectionCount();
                applyAndRender();
            });
        });
        if (state.priceMin > PRICE_GLOBAL_MIN || state.priceMax < PRICE_GLOBAL_MAX) {
            hasAny = true;
            addChip(`₾${state.priceMin} — ₾${state.priceMax}`, () => {
                state.priceMin = PRICE_GLOBAL_MIN;
                state.priceMax = PRICE_GLOBAL_MAX;
                rangeMin.value = PRICE_GLOBAL_MIN;
                rangeMax.value = PRICE_GLOBAL_MAX;
                updateRangeFill();
                updatePriceLabels();
                applyAndRender();
            });
        }
        if (state.rating !== null) {
            hasAny = true;
            addChip('★ ' + state.rating + '+', () => {
                state.rating = null;
                document.querySelectorAll('.fm-rating-item').forEach(el => el.classList.remove('selected'));
                applyAndRender();
            });
        }
        state.badges.forEach(b => {
            hasAny = true;
            addChip('🏷️ ' + b, () => {
                state.badges.delete(b);
                document.querySelectorAll('.fm-badge-pill').forEach(el => {
                    if (el.dataset.badge === b) el.classList.remove('selected');
                });
                updateBadgeSectionCount();
                applyAndRender();
            });
        });
        if (hasAny) {
            const clearAll = document.createElement('div');
            clearAll.className = 'fm-chip fm-chip-clear';
            clearAll.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> ყველა გასუფთავება`;
            clearAll.addEventListener('click', clearAllFilters);
            chipsEl.appendChild(clearAll);
        }

        chipsEl.classList.toggle('has-chips', hasAny);

        const hBadge = filterBtn ? filterBtn.querySelector('.filter-badge') : null;
        if (hBadge) {
            const activeCount = (state.search ? 1 : 0) + state.categories.size + state.badges.size +
                (state.rating !== null ? 1 : 0) +
                (state.priceMin > PRICE_GLOBAL_MIN || state.priceMax < PRICE_GLOBAL_MAX ? 1 : 0);
            hBadge.textContent = activeCount;
            filterBtn.classList.toggle('has-filters', activeCount > 0);
        }
    }

    function addChip(label, onRemove) {
        const chip = document.createElement('div');
        chip.className = 'fm-chip';
        chip.innerHTML = `${label} <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
        chip.addEventListener('click', onRemove);
        chipsEl.appendChild(chip);
    }

    function clearAllFilters() {
        state.search = '';
        state.categories.clear();
        state.priceMin = PRICE_GLOBAL_MIN;
        state.priceMax = PRICE_GLOBAL_MAX;
        state.rating = null;
        state.badges.clear();
        state.sort = 'default';
        searchEl.value = '';
        searchClear.classList.remove('vis');
        document.querySelectorAll('.fm-cat-item').forEach(el => el.classList.remove('selected'));
        document.querySelectorAll('.fm-rating-item').forEach(el => el.classList.remove('selected'));
        document.querySelectorAll('.fm-badge-pill').forEach(el => el.classList.remove('selected'));
        document.querySelectorAll('.fm-sort-item').forEach((el,i) => el.classList.toggle('selected', i===0));
        rangeMin.value = PRICE_GLOBAL_MIN;
        rangeMax.value = PRICE_GLOBAL_MAX;
        updateRangeFill();
        updatePriceLabels();
        updateFilterCountBadges();
        applyAndRender();
    }

    /* ─── SECTION COUNT BADGES ────────────────────────── */
    function updateFilterCountBadges() {
        updateCatSectionCount();
        updateBadgeSectionCount();
        updateRatingSectionCount();
        updatePriceSectionCount();
    }

    function updateCatSectionCount() {
        catCount.textContent = state.categories.size > 0 ? `(${state.categories.size})` : '';
    }
    function updateBadgeSectionCount() {
        badgeCount.textContent = state.badges.size > 0 ? `(${state.badges.size})` : '';
    }
    function updateRatingSectionCount() {
        ratingCount.textContent = state.rating !== null ? `(${state.rating}+★)` : '';
    }
    function updatePriceSectionCount() {
        const hasPrice = state.priceMin > PRICE_GLOBAL_MIN || state.priceMax < PRICE_GLOBAL_MAX;
        priceCount.textContent = hasPrice ? `(₾${state.priceMin}-₾${state.priceMax})` : '';
    }

    /* ─── BUILD CATEGORY ITEMS ────────────────────────── */
    function buildCategoryItems() {
        catBody.innerHTML = '';
        CATS.forEach(cat => {
            const item = document.createElement('div');
            item.className = 'fm-cat-item';
            item.dataset.cat = cat.label;
            item.innerHTML = `
                <div class="fm-cat-checkbox">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <img class="fm-cat-thumb" src="${cat.img}" alt="${cat.label}" loading="lazy"/>
                <div class="fm-cat-info">
                    <div class="fm-cat-name">${cat.label}</div>
                    <div class="fm-cat-sub">${cat.products.length} პროდ.</div>
                </div>`;
            item.addEventListener('click', () => {
                const isSelected = item.classList.toggle('selected');
                if (isSelected) state.categories.add(cat.label);
                else state.categories.delete(cat.label);
                updateCatSectionCount();
                applyAndRender();
            });
            catBody.appendChild(item);
        });
    }

    /* ─── BUILD RATING OPTIONS ────────────────────────── */
    function buildRatingOptions() {
        ratingOpts.innerHTML = '';
        RATING_OPTIONS.forEach(opt => {
            const item = document.createElement('div');
            item.className = 'fm-rating-item';
            item.dataset.val = opt.val;
            const stars = Array.from({length:5}, (_,i) =>
                `<svg class="fm-star-icon ${i < opt.val ? 'filled' : 'empty'}" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>`
            ).join('');
            item.innerHTML = `<div class="fm-rating-stars">${stars}</div><span class="fm-rating-label">${opt.label}</span>`;
            item.addEventListener('click', () => {
                const same = state.rating === opt.val;
                state.rating = same ? null : opt.val;
                document.querySelectorAll('.fm-rating-item').forEach(el => el.classList.remove('selected'));
                if (!same) item.classList.add('selected');
                updateRatingSectionCount();
                applyAndRender();
            });
            ratingOpts.appendChild(item);
        });
    }

    /* ─── BUILD BADGE OPTIONS ─────────────────────────── */
    function buildBadgeOptions() {
        const badges = [...new Set(allProducts.map(p => p.badge).filter(Boolean))];
        badgeOpts.innerHTML = '';
        badges.forEach(b => {
            const pill = document.createElement('div');
            pill.className = 'fm-badge-pill';
            pill.dataset.badge = b;
            pill.textContent = b;
            pill.addEventListener('click', () => {
                const isSelected = pill.classList.toggle('selected');
                if (isSelected) state.badges.add(b);
                else state.badges.delete(b);
                updateBadgeSectionCount();
                applyAndRender();
            });
            badgeOpts.appendChild(pill);
        });
    }

    /* ─── BUILD SORT OPTIONS ──────────────────────────── */
    function buildSortOptions() {
        sortOpts.innerHTML = '';
        SORT_OPTIONS.forEach((opt, i) => {
            const item = document.createElement('div');
            item.className = 'fm-sort-item' + (i === 0 ? ' selected' : '');
            item.dataset.sort = opt.id;
            item.innerHTML = `<div class="fm-sort-dot"></div><span>${opt.label}</span>`;
            item.addEventListener('click', () => {
                state.sort = opt.id;
                document.querySelectorAll('.fm-sort-item').forEach(el => el.classList.remove('selected'));
                item.classList.add('selected');
                applyAndRender();
            });
            sortOpts.appendChild(item);
        });
    }

    /* ─── RANGE SLIDER ────────────────────────────────── */
    function initRangeSlider() {
        rangeMin.min = PRICE_GLOBAL_MIN;
        rangeMin.max = PRICE_GLOBAL_MAX;
        rangeMin.value = PRICE_GLOBAL_MIN;
        rangeMax.min = PRICE_GLOBAL_MIN;
        rangeMax.max = PRICE_GLOBAL_MAX;
        rangeMax.value = PRICE_GLOBAL_MAX;
        updateRangeFill();
        updatePriceLabels();
    }

    function updateRangeFill() {
        const min = PRICE_GLOBAL_MIN;
        const max = PRICE_GLOBAL_MAX;
        const range = max - min || 1;
        const leftPct  = ((parseInt(rangeMin.value) - min) / range) * 100;
        const rightPct = ((parseInt(rangeMax.value) - min) / range) * 100;
        rangeFill.style.left  = leftPct + '%';
        rangeFill.style.width = (rightPct - leftPct) + '%';
    }

    function updatePriceLabels() {
        pMinLabel.textContent = '₾' + state.priceMin;
        pMaxLabel.textContent = '₾' + state.priceMax;
    }

    let priceDebounce = null;
    rangeMin.addEventListener('input', () => {
        let v = parseInt(rangeMin.value);
        if (v >= parseInt(rangeMax.value)) { v = parseInt(rangeMax.value) - 50; rangeMin.value = v; }
        state.priceMin = v;
        updateRangeFill();
        updatePriceLabels();
        clearTimeout(priceDebounce);
        priceDebounce = setTimeout(applyAndRender, 250);
        updatePriceSectionCount();
    });
    rangeMax.addEventListener('input', () => {
        let v = parseInt(rangeMax.value);
        if (v <= parseInt(rangeMin.value)) { v = parseInt(rangeMin.value) + 50; rangeMax.value = v; }
        state.priceMax = v;
        updateRangeFill();
        updatePriceLabels();
        clearTimeout(priceDebounce);
        priceDebounce = setTimeout(applyAndRender, 250);
        updatePriceSectionCount();
    });

    /* ─── SECTION TOGGLES ─────────────────────────────── */
    function bindSectionToggles() {
        document.querySelectorAll('.fm-section-head').forEach(head => {
            head.addEventListener('click', () => {
                const sec = document.getElementById(head.dataset.target);
                if (sec) sec.classList.toggle('collapsed');
            });
        });
    }

    /* ─── INFINITY SCROLL ─────────────────────────────── */
    let observer;
    function initIntersectionObserver() {
        observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && renderedCount < filteredProducts.length) {
                    spinner.classList.add('vis');
                    setTimeout(renderNextBatch, 300);
                }
            });
        }, {
            root: document.getElementById('fm-results-wrap'),
            rootMargin: '0px',
            threshold: 0.1
        });
        observer.observe(sentinel);
    }

    /* ─── VIEW TOGGLE ─────────────────────────────────── */
    viewGrid.addEventListener('click', () => {
        state.view = 'grid';
        viewGrid.classList.add('active');
        viewList.classList.remove('active');
        grid.classList.remove('list-view');
        applyAndRender();
    });
    viewList.addEventListener('click', () => {
        state.view = 'list';
        viewList.classList.add('active');
        viewGrid.classList.remove('active');
        grid.classList.add('list-view');
        applyAndRender();
    });

    /* ─── SEARCH ──────────────────────────────────────── */
    let searchDebounce = null;
    searchEl.addEventListener('input', () => {
        state.search = searchEl.value;
        searchClear.classList.toggle('vis', state.search.length > 0);
        clearTimeout(searchDebounce);
        searchDebounce = setTimeout(applyAndRender, 200);
    });
    searchClear.addEventListener('click', () => {
        state.search = '';
        searchEl.value = '';
        searchClear.classList.remove('vis');
        searchEl.focus();
        applyAndRender();
    });

    /* ─── BIND EVENTS ─────────────────────────────────── */
    function bindEvents() {
        closeBtn.addEventListener('click', closeFilter);
        overlay.addEventListener('click', closeFilter);

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && state.open) closeFilter();
        });

        if (filterBtn) {
            filterBtn.addEventListener('click', () => {
                if (state.open) closeFilter();
                else openFilter();
            });
        }
    }

    /* ─── START — uses Promise, race-condition-proof ──── */
    function start() {
        // window.__catsPromise always resolves (see data.js).
        // If CATS are already loaded .then() fires on next microtask.
        window.__catsPromise.then(function() {
            init();
            if (state.open) applyAndRender();
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }

    // Expose for external use
    window.FilterSystem = { open: openFilter, close: closeFilter, clearAll: clearAllFilters };

})();
