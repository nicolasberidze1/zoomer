<?php
session_start();
// ========= CONFIG ==========
$USERNAME = "nicolas";      // ჩააწერე შენი სახელი
$PASSWORD = "Shechema1!";     // ჩააწერე შენი პაროლი
// ===========================

// თუ უკვე შემოსულია
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // ჩვეულებრივად აგრძელებს ქვემოთ არსებულ კოდს (API + UI)
} else {
    // თუ არის submit
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $u = $_POST['username'] ?? '';
        $p = $_POST['password'] ?? '';
        if ($u === $USERNAME && $p === $PASSWORD) {
            $_SESSION['loggedin'] = true;
            header("Location: ".$_SERVER['PHP_SELF']);
            exit;
        } else {
            $error = "არასწორია!";
        }
    }
    // ვაჩვენოთ login ფორმა და გავჩერდეთ
    ?>
    <!DOCTYPE html>
    <html lang="ka">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <title>Login</title>
      <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    backdrop-filter: brightness(50%) blur(3px);
    background: #0a0a0a;
    background-image: url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072');
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    padding: 20px;
    color: #fff;
    font-family: 'Segoe UI', Arial, sans-serif;
    overflow-x: hidden;
}

body::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.4);
    z-index: -1;
}

form {
    position: relative;
    border: 2px solid transparent;
    background: linear-gradient(135deg, rgba(255, 69, 0, 0.15) 0%, rgba(0, 0, 0, 0.9) 50%, rgba(255, 69, 0, 0.15) 100%);
    backdrop-filter: blur(10px) saturate(180%);
    padding: 40px 50px;
    border-radius: 20px;
    width: 100%;
    max-width: 420px;
    box-shadow: 
        0 8px 32px 0 rgba(255, 69, 0, 0.3),
        0 0 100px rgba(255, 69, 0, 0.1),
        inset 0 0 50px rgba(255, 69, 0, 0.05);
    animation: formGlow 3s ease-in-out infinite;
    transition: all 0.4s ease;
}

form::before {
    content: '';
    position: absolute;
    top: -2px;
    left: -2px;
    right: -2px;
    bottom: -2px;
    background: linear-gradient(45deg, #ff4500, #ff8c00, #ff4500);
    border-radius: 20px;
    z-index: -1;
    opacity: 0.6;
    animation: borderRotate 4s linear infinite;
}

form:hover {
    transform: translateY(-5px);
    box-shadow: 
        0 12px 40px 0 rgba(255, 69, 0, 0.5),
        0 0 120px rgba(255, 69, 0, 0.2),
        inset 0 0 60px rgba(255, 69, 0, 0.08);
}

input {
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(5px);
    display: block;
    margin: 15px 0;
    padding: 12px 15px;
    width: 100%;
    border-radius: 10px;
    border: 1px solid rgba(255, 69, 0, 0.3);
    color: #fff;
    font-size: 14px;
    transition: all 0.3s ease;
    outline: none;
}

input::placeholder {
    color: rgba(255, 255, 255, 0.5);
}

input:focus {
    background: rgba(0, 0, 0, 0.8);
    border: 1px solid #ff4500;
    box-shadow: 
        0 0 20px rgba(255, 69, 0, 0.4),
        inset 0 0 10px rgba(255, 69, 0, 0.1);
    transform: scale(1.02);
}

button {
    padding: 12px 30px;
    margin-top: 10px;
    width: 100%;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    background: linear-gradient(135deg, #ff4500 0%, #ff6347 100%);
    color: #fff;
    font-size: 15px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
    box-shadow: 0 4px 15px rgba(255, 69, 0, 0.4);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

button::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    transition: left 0.5s ease;
}

button:hover::before {
    left: 100%;
}

button:hover {
    background: linear-gradient(135deg, #ff6347 0%, #ff4500 100%);
    box-shadow: 0 6px 25px rgba(255, 69, 0, 0.6);
    transform: translateY(-2px) scale(1.05);
}

button:active {
    transform: translateY(0) scale(0.98);
    box-shadow: 0 2px 10px rgba(255, 69, 0, 0.5);
}

.err {
    color: #ff5555;
    font-size: 13px;
    margin: 5px 0;
    animation: shake 0.3s ease;
    text-shadow: 0 0 10px rgba(255, 85, 85, 0.5);
}

@keyframes formGlow {
    0%, 100% {
        box-shadow: 
            0 8px 32px 0 rgba(255, 69, 0, 0.3),
            0 0 100px rgba(255, 69, 0, 0.1),
            inset 0 0 50px rgba(255, 69, 0, 0.05);
    }
    50% {
        box-shadow: 
            0 8px 32px 0 rgba(255, 69, 0, 0.5),
            0 0 120px rgba(255, 69, 0, 0.2),
            inset 0 0 60px rgba(255, 69, 0, 0.1);
    }
}

@keyframes borderRotate {
    0% {
        filter: hue-rotate(0deg);
    }
    100% {
        filter: hue-rotate(360deg);
    }
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-5px); }
    75% { transform: translateX(5px); }
}

@media screen and (max-width: 768px) {
    body {
        padding: 15px;
        background-attachment: scroll;
    }
    
    form {
        padding: 30px 25px;
        border-radius: 15px;
        max-width: 100%;
    }
    
    form:hover {
        transform: none;
    }
    
    input {
        padding: 10px 12px;
        font-size: 16px;
        margin: 12px 0;
    }
    
    button {
        padding: 14px 25px;
        font-size: 14px;
    }
    
    .err {
        font-size: 12px;
    }
}
      </style>
    </head>
    <body>
      <form method="post">
        <h2>🔒 ავტორიზაცია</h2>
        <?php if (!empty($error)) echo "<div class='err'>$error</div>"; ?>
        <input type="text" name="username" placeholder="მომხმარებელი" required>
        <input type="password" name="password" placeholder="პაროლი" required>
        <button type="submit">შესვლა</button>
      </form>
    </body>
    </html>
    <?php
    exit;
}

// ---------- small helpers & API ----------
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $root = __DIR__;

    function normalize_path($p) {
        $p = str_replace("\0", "", $p);
        $p = str_replace(array('../','..\\'), '', $p);
        $p = ltrim($p, "/\\");
        return $p;
    }

    function getDirTree($dir, $base) {
        $items = @scandir($dir);
        if (!$items) return [];
        $result = [];
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path)) {
                $children = getDirTree($path, $base);
                $result[] = [
                    'type' => 'dir',
                    'name' => $item,
                    'path' => ltrim(str_replace($base, '', $path), '/\\'),
                    'children' => $children
                ];
            } else {
                $result[] = [
                    'type' => 'file',
                    'name' => $item,
                    'path' => ltrim(str_replace($base . DIRECTORY_SEPARATOR, '', $path), '/\\')
                ];
            }
        }
        return $result;
    }

    if ($action === 'list') {
        header('Content-Type: application/json');
        echo json_encode(getDirTree($root, $root));
        exit;
    }

    if ($action === 'read' && isset($_GET['file'])) {
        $file = normalize_path($_GET['file']);
        $path = $root . DIRECTORY_SEPARATOR . $file;
        if (is_file($path)) {
            header('Content-Type: text/plain; charset=utf-8');
            echo file_get_contents($path);
        } else {
            http_response_code(404);
            echo "File not found";
        }
        exit;
    }

    if ($action === 'save' && isset($_POST['file'])) {
        $file = normalize_path($_POST['file']);
        $path = $root . DIRECTORY_SEPARATOR . $file;
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
        $content = $_POST['content'] ?? '';
        file_put_contents($path, $content);
        echo "Saved";
        exit;
    }

    if ($action === 'delete' && isset($_GET['file'])) {
        $file = normalize_path($_GET['file']);
        $path = $root . DIRECTORY_SEPARATOR . $file;
        if (is_file($path)) {
            unlink($path);
            echo "Deleted";
        } else {
            http_response_code(404);
            echo "File not found";
        }
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Ezzway - Code Editor</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    
    :root { 
      --bg-primary: #1e1e1e;
      --bg-secondary: #252526;
      --bg-tertiary: #2d2d30;
      --bg-hover: #37373d;
      --border-color: #3c3c3c;
      --text-primary: #cccccc;
      --text-secondary: #969696;
      --accent-blue: #0e639c;
      --accent-hover: #1177bb;
      --accent-bright: #007acc;
      --success-green: #4ec9b0;
      --warning-orange: #ce9178;
      --error-red: #f48771;
      --sidebar-width: 300px;
      --toolbar-height: 35px;
      --tabs-height: 35px;
      --statusbar-height: 22px;
    }
    
    html, body { 
      height: 100%; 
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Ubuntu', 'Roboto', sans-serif; 
      background: var(--bg-primary);
      color: var(--text-primary);
      overflow: hidden;
    }
    
    .wrap { 
      display: flex; 
      height: 100vh; 
      flex-direction: row;
    }
    
    /* ============= SIDEBAR ============= */
    #sidebar {
      width: var(--sidebar-width);
      background: var(--bg-secondary);
      border-right: 1px solid var(--border-color);
      display: flex;
      flex-direction: column;
      transition: width 0.3s ease;
    }
    
    #sidebar-header {
      padding: 8px 16px;
      background: var(--bg-tertiary);
      border-bottom: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: var(--toolbar-height);
    }
    
    #sidebar-header h3 {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: var(--text-secondary);
    }
    
    #file-list-container {
      flex: 1;
      overflow-y: auto;
      overflow-x: hidden;
      padding: 8px 0;
    }
    
    #file-list-container::-webkit-scrollbar {
      width: 10px;
    }
    
    #file-list-container::-webkit-scrollbar-track {
      background: var(--bg-secondary);
    }
    
    #file-list-container::-webkit-scrollbar-thumb {
      background: #424242;
      border-radius: 5px;
    }
    
    #file-list-container::-webkit-scrollbar-thumb:hover {
      background: #4f4f4f;
    }
    
    .controls {
      padding: 12px;
      border-top: 1px solid var(--border-color);
      display: flex;
      flex-direction: column;
      gap: 8px;
      background: var(--bg-tertiary);
    }
    
    .controls button {
      background: var(--bg-hover);
      color: var(--text-primary);
      border: 1px solid var(--border-color);
      padding: 8px 12px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 12px;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }
    
    .controls button:hover {
      background: var(--accent-blue);
      border-color: var(--accent-bright);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px rgba(0, 122, 204, 0.3);
    }

    .controls .auto-save-toggle {
      background: transparent;
      border: 1px solid var(--border-color);
      padding: 10px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      cursor: pointer;
      border-radius: 4px;
      transition: all 0.2s;
    }

    .controls .auto-save-toggle:hover {
      background: var(--bg-hover);
      border-color: var(--accent-bright);
    }

    .controls .auto-save-toggle.active {
      background: rgba(0, 122, 204, 0.15);
      border-color: var(--accent-bright);
    }

    .toggle-switch {
      position: relative;
      width: 40px;
      height: 20px;
      background: #555;
      border-radius: 10px;
      transition: background 0.3s;
    }

    .toggle-switch::after {
      content: '';
      position: absolute;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: white;
      top: 2px;
      left: 2px;
      transition: transform 0.3s;
    }

    .auto-save-toggle.active .toggle-switch {
      background: var(--accent-bright);
    }

    .auto-save-toggle.active .toggle-switch::after {
      transform: translateX(20px);
    }
    
    /* File tree styles with SVG icons */
    details {
      user-select: none;
    }
    
    summary {
      list-style: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 5px 12px 5px 20px;
      font-size: 13px;
      transition: background 0.15s;
      position: relative;
    }
    
    summary::-webkit-details-marker {
      display: none;
    }
    
    summary:hover {
      background: var(--bg-hover);
    }
    
    details[open] > summary::before {
      content: "▾";
      position: absolute;
      left: 4px;
      color: var(--text-secondary);
      font-size: 10px;
    }
    
    details > summary::before {
      content: "▸";
      position: absolute;
      left: 4px;
      color: var(--text-secondary);
      font-size: 10px;
    }
    
    .dir-item {
      color: #c5c5c5;
    }
    
    .file-item {
      padding: 5px 12px 5px 28px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      transition: background 0.15s;
      position: relative;
    }
    
    .file-item:hover {
      background: var(--bg-hover);
    }
    
    .file-item.active {
      background: rgba(0, 122, 204, 0.2);
      border-left: 2px solid var(--accent-bright);
    }

    .file-item.editing {
      background: var(--bg-hover);
    }

    .file-name {
      flex: 1;
    }

    .rename-input {
      flex: 1;
      background: var(--bg-primary);
      color: var(--text-primary);
      border: 1px solid var(--accent-bright);
      padding: 2px 6px;
      border-radius: 3px;
      font-size: 13px;
      outline: none;
      font-family: inherit;
    }
    
    .children {
      margin-left: 16px;
    }
    
    .file-icon {
      width: 16px;
      height: 16px;
      flex-shrink: 0;
    }

    .folder-icon {
      width: 16px;
      height: 16px;
      flex-shrink: 0;
    }
    
    /* ============= EDITOR CONTAINER ============= */
    #editor-container {
      flex: 1;
      display: flex;
      flex-direction: column;
      background: var(--bg-primary);
    }
    
    /* ============= TABS ============= */
    #tabs-container {
      background: var(--bg-secondary);
      border-bottom: 1px solid var(--border-color);
      display: flex;
      align-items: flex-end;
      height: var(--tabs-height);
      overflow-x: auto;
      overflow-y: hidden;
    }
    
    #tabs-container::-webkit-scrollbar {
      height: 2px;
    }
    
    #tabs-container::-webkit-scrollbar-track {
      background: var(--bg-secondary);
    }
    
    #tabs-container::-webkit-scrollbar-thumb {
      background: var(--accent-blue);
    }
    
    .tab {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: var(--bg-tertiary);
      border-right: 1px solid var(--border-color);
      cursor: pointer;
      font-size: 13px;
      white-space: nowrap;
      transition: background 0.15s;
      min-width: 120px;
      max-width: 200px;
      position: relative;
      height: var(--tabs-height);
    }
    
    .tab:hover {
      background: var(--bg-hover);
    }
    
    .tab.active {
      background: var(--bg-primary);
      border-bottom: 2px solid var(--accent-bright);
    }

    .tab.modified .tab-name::after {
      content: '●';
      margin-left: 4px;
      color: var(--success-green);
    }
    
    .tab-name {
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .tab-close {
      opacity: 0;
      padding: 2px 4px;
      border-radius: 3px;
      font-size: 16px;
      line-height: 1;
      transition: opacity 0.2s;
    }
    
    .tab:hover .tab-close,
    .tab.active .tab-close {
      opacity: 0.7;
    }
    
    .tab-close:hover {
      opacity: 1 !important;
      background: rgba(255, 255, 255, 0.1);
    }
    
    .tab-icon {
      width: 16px;
      height: 16px;
      flex-shrink: 0;
    }
    
    /* ============= TOOLBAR ============= */
    #toolbar {
      background: var(--bg-secondary);
      color: var(--text-primary);
      padding: 6px 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      border-bottom: 1px solid var(--border-color);
      height: var(--toolbar-height);
    }
    
    #toolbar .left {
      display: flex;
      gap: 12px;
      align-items: center;
    }
    
    #toolbar button {
      background: var(--accent-blue);
      color: white;
      border: none;
      padding: 6px 16px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 12px;
      font-weight: 500;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    
    #toolbar button:hover {
      background: var(--accent-hover);
      transform: translateY(-1px);
      box-shadow: 0 2px 8px rgba(0, 122, 204, 0.3);
    }
    
    #toolbar button:active {
      transform: translateY(0);
    }
    
    .filename {
      font-weight: 500;
      font-size: 13px;
      color: var(--text-primary);
    }
    
    .small-muted {
      color: var(--text-secondary);
      font-size: 11px;
    }
    
    /* ============= EDITOR ============= */
    #editor {
      flex: 1;
      height: calc(100vh - var(--toolbar-height) - var(--tabs-height) - var(--statusbar-height));
    }
    
    /* ============= STATUS BAR ============= */
    #statusbar {
      background: var(--accent-blue);
      color: white;
      padding: 2px 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 11px;
      height: var(--statusbar-height);
      border-top: 1px solid var(--border-color);
    }
    
    #statusbar .left,
    #statusbar .right {
      display: flex;
      gap: 16px;
      align-items: center;
    }
    
    .status-item {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .status-item.auto-save-indicator {
      padding: 2px 8px;
      background: rgba(255, 255, 255, 0.15);
      border-radius: 3px;
      font-weight: 500;
    }
    
    /* ============= TOOLTIP ============= */
    .tooltip {
      background: var(--bg-tertiary);
      color: var(--text-primary);
      padding: 12px;
      margin: 12px;
      border-radius: 6px;
      font-size: 11px;
      border: 1px solid var(--border-color);
      line-height: 1.6;
    }
    
    .tooltip code {
      background: rgba(255, 255, 255, 0.1);
      padding: 2px 6px;
      border-radius: 3px;
      font-family: 'Courier New', monospace;
      color: var(--success-green);
    }
    
    .tooltip kbd {
      background: var(--bg-primary);
      padding: 2px 6px;
      border-radius: 3px;
      border: 1px solid var(--border-color);
      font-family: 'Courier New', monospace;
      font-size: 10px;
    }
    
    /* ============= RESPONSIVE ============= */
    @media (max-width: 900px) {
      :root {
        --sidebar-width: 240px;
      }
    }
    
    @media (max-width: 600px) {
      :root {
        --sidebar-width: 200px;
      }
      
      .controls button {
        padding: 6px 10px;
        font-size: 11px;
      }
    }
  </style>
</head>
<body>
  <div class="wrap">
    <aside id="sidebar">
      <div id="sidebar-header">
        <h3>Explorer</h3>
        <span style="font-size: 18px; opacity: 0.7; cursor: pointer;" title="Collapse">⋯</span>
      </div>
      
      <div id="file-list-container">
        <div id="file-list"></div>
      </div>
      
      <div class="controls">
        <button onclick="promptNew()" title="New File">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
            <path d="M14 7v1H8v6H7V8H1V7h6V1h1v6h6z"/>
          </svg>
          <span>ახალი ფაილი</span>
        </button>
        <button onclick="doDelete()" title="Delete File">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
            <path d="M10 3h3v1h-1v9l-1 1H4l-1-1V4H2V3h3V2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v1zM9 2H6v1h3V2zM4 13h7V4H4v9zm2-8H5v7h1V5zm1 0h1v7H7V5zm2 0h1v7H9V5z"/>
          </svg>
          <span>წაშლა</span>
        </button>
        <button onclick="refresh()" title="Refresh">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
            <path d="M13.451 5.609l-.579-.939-1.068.812-.076.094c-.335.415-.927 1.341-1.124 2.876l-.021.165.033.163.071.345c0 1.654-1.346 3-3 3-.795 0-1.545-.311-2.107-.868-.563-.567-.873-1.317-.873-2.111 0-1.431 1.007-2.632 2.351-2.929v2.926s2.528-2.087 2.984-2.461h.012l3.061-2.582-4.919-4.1h-1.137v2.404c-3.429.318-6.121 3.211-6.121 6.721 0 1.809.707 3.508 1.986 4.782 1.277 1.282 2.976 1.988 4.785 1.988 3.722 0 6.75-3.028 6.75-6.75 0-2.096-.953-3.983-2.451-5.291z"/>
          </svg>
          <span>ხელახლა ჩატვირთვა</span>
        </button>
        
        <div class="auto-save-toggle" onclick="toggleAutoSave()" title="Toggle Auto Save">
          <span style="font-size: 11px; font-weight: 500;">Auto Save</span>
          <div class="toggle-switch"></div>
        </div>
      </div>
      
      <div class="tooltip">
        ezzway
      </div>
    </aside>

    <main id="editor-container">
      <div id="tabs-container"></div>
      
      <div id="toolbar">
        <div class="left">
          <span class="filename" id="current-file">No file open</span>
          <span class="small-muted" id="current-lang"></span>
        </div>
        <div>
          <button onclick="saveFile()">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
              <path d="M13.353 1.146l1.5 1.5L15 3v11.5l-.5.5h-13l-.5-.5v-13l.5-.5H13l.353.146zM2 2v12h12V3.208L12.793 2H11v4H4V2H2zm6 0v3h3V2H8z"/>
            </svg>
            <span>Save</span>
          </button>
        </div>
      </div>
      
      <div id="editor"></div>
      
      <div id="statusbar">
        <div class="left">
          <div class="status-item">⚡ Ready</div>
          <div class="status-item auto-save-indicator" id="auto-save-status" style="display: none;">Auto-Save: OFF</div>
          <div class="status-item" id="status-encoding">UTF-8</div>
        </div>
        <div class="right">
          <div class="status-item" id="status-lang">JavaScript</div>
          <div class="status-item" id="status-lines">Lines: 0</div>
        </div>
      </div>
    </main>
  </div>

  <!-- Monaco (AMD loader) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs/loader.min.js"></script>
  <!-- Emmet plugin (browser build) -->
  <script src="https://unpkg.com/emmet-monaco-es/dist/emmet-monaco.min.js"></script>

  <script>
    // ============= STATE MANAGEMENT =============
    let editor;
    let openTabs = [];
    let currentTabIndex = -1;
    let autoSaveEnabled = false;
    let autoSaveTimeout = null;
    let modifiedTabs = new Set();

    // ============= SVG ICONS =============
    const svgIcons = {
      javascript: '<svg viewBox="0 0 16 16" fill="#f0db4f"><path d="M1 1v14h14V1H1zm12.5 11.5c0 1.381-1.119 2.5-2.5 2.5H5c-1.381 0-2.5-1.119-2.5-2.5v-9C2.5 2.119 3.619 1 5 1h6c1.381 0 2.5 1.119 2.5 2.5v9z"/><text x="4" y="11" font-family="Arial" font-size="7" font-weight="bold" fill="#000">JS</text></svg>',
      typescript: '<svg viewBox="0 0 16 16" fill="#3178c6"><rect width="16" height="16" rx="2"/><text x="3" y="11" font-family="Arial" font-size="7" font-weight="bold" fill="#fff">TS</text></svg>',
      html: '<svg viewBox="0 0 16 16" fill="#e34c26"><path d="M2 1l1.2 13.5L8 16l4.8-1.5L14 1H2zm9.5 5H6l.2 2h5.1l-.4 4-2.9.9-2.9-.9-.2-2h1.4l.1 1 1.6.5 1.6-.5.2-1.5H5.5l-.5-5h7l-.5 2z"/></svg>',
      css: '<svg viewBox="0 0 16 16" fill="#264de4"><path d="M2 1l1.2 13.5L8 16l4.8-1.5L14 1H2zm9.5 5H6l.2 2h5.1l-.4 4-2.9.9-2.9-.9-.2-2h1.4l.1 1 1.6.5 1.6-.5.2-1.5H5.5l-.5-5h7l-.5 2z"/></svg>',
      php: '<svg viewBox="0 0 16 16" fill="#777bb3"><ellipse cx="8" cy="8" rx="7" ry="4"/><text x="2.5" y="10" font-family="Arial" font-size="5" font-weight="bold" fill="#fff">php</text></svg>',
      json: '<svg viewBox="0 0 16 16" fill="#ffca28"><path d="M3 3v10h10V3H3zm8 2v2h-2V5h2zm-4 0v2H5V5h2zm0 4v2H5V9h2zm2 0h2v2H9V9z"/></svg>',
      markdown: '<svg viewBox="0 0 16 16" fill="#083fa1"><path d="M2 3v10h12V3H2zm10 8H9l-2-2.5L5 11H4V5h1l2 2.5L9 5h1v6zm2-6h-1v4l-1-1-1 1V5h-1v6h1l1-1 1 1h1V5z"/></svg>',
      python: '<svg viewBox="0 0 16 16" fill="#3776ab"><path d="M7.5 1C4.5 1 4.7 2.4 4.7 2.4l.1 1.4h2.8v.4H3.8S1 3.9 1 7s2.4 3 2.4 3h1.4V8.5s-.1-1.4 1.4-1.4h2.7s1.3.1 1.3-1.3V2.7S10.4 1 7.5 1zm-.8 1.5c.3 0 .5.2.5.5s-.2.5-.5.5-.5-.2-.5-.5.2-.5.5-.5z"/><path d="M8.5 15c3 0 2.8-1.4 2.8-1.4l-.1-1.4H8.4v-.4h3.8S15 12.1 15 9s-2.4-3-2.4-3h-1.4v1.5s.1 1.4-1.4 1.4H7.1s-1.3-.1-1.3 1.3v2.1s-.2 1.7 2.7 1.7zm.8-1.5c-.3 0-.5-.2-.5-.5s.2-.5.5-.5.5.2.5.5-.2.5-.5.5z" fill="#ffd43b"/></svg>',
      folder: '<svg viewBox="0 0 16 16" fill="#dcb67a"><path d="M14.5 3H7.71l-.85-.85L6.51 2h-5l-.5.5v11l.5.5h13l.5-.5v-10L14.5 3zm-.51 8.49V13h-12V7h4.49l.35-.15.86-.86H14v1.5l-.01 4zm0-6.49h-6.5l-.35.15-.86.86H2v-3h4.29l.85.85.36.15H14l-.01.99z"/></svg>',
      folderOpen: '<svg viewBox="0 0 16 16" fill="#dcb67a"><path d="M1.5 14h11l.48-.37 2.63-7-.48-.63H14V4.5l-.5-.5H7.71l-.86-.85L6.5 3h-5l-.5.5v10l.5.5zM2 4h4.29l.86.85.35.15H13v1H8.5l-.35.15-.86.86H2V4zm6.15 2.15L8.5 6h6.61l-2.15 6H2.4l4.49-5.01L7.15 6.15z"/></svg>',
      default: '<svg viewBox="0 0 16 16" fill="#858585"><path d="M13.5 1h-12l-.5.5v13l.5.5h12l.5-.5v-13l-.5-.5zM13 14H2V2h11v12zM4 6h7v1H4V6zm0 2h7v1H4V8zm0 2h7v1H4v-1z"/></svg>'
    };

    function getFileIconSVG(filename) {
      const ext = (filename.split('.').pop() || '').toLowerCase();
      const map = {
        'js': 'javascript', 'jsx': 'javascript',
        'ts': 'typescript', 'tsx': 'typescript',
        'html': 'html', 'htm': 'html',
        'css': 'css', 'scss': 'css', 'sass': 'css', 'less': 'css',
        'php': 'php',
        'py': 'python',
        'json': 'json',
        'md': 'markdown'
      };
      return svgIcons[map[ext]] || svgIcons.default;
    }

    // ============= AUTO SAVE =============
    function toggleAutoSave() {
      autoSaveEnabled = !autoSaveEnabled;
      const toggle = document.querySelector('.auto-save-toggle');
      const indicator = document.getElementById('auto-save-status');
      
      if (autoSaveEnabled) {
        toggle.classList.add('active');
        indicator.style.display = 'flex';
        indicator.textContent = 'Auto-Save: ON';
        updateStatusBar('✓ Auto-save enabled');
      } else {
        toggle.classList.remove('active');
        indicator.style.display = 'none';
        if (autoSaveTimeout) {
          clearTimeout(autoSaveTimeout);
          autoSaveTimeout = null;
        }
        updateStatusBar('✗ Auto-save disabled');
      }
      
      setTimeout(() => updateStatusBar('⚡ Ready'), 2000);
    }

    function scheduleAutoSave() {
      if (!autoSaveEnabled || currentTabIndex < 0) return;
      
      if (autoSaveTimeout) {
        clearTimeout(autoSaveTimeout);
      }
      
      autoSaveTimeout = setTimeout(() => {
        if (modifiedTabs.has(currentTabIndex)) {
          saveFile(true);
        }
      }, 1000); // 1 second delay like VS Code
    }

    // ============= LANGUAGE DETECTION =============
    function detectLanguage(filename) {
      const ext = (filename.split('.').pop() || '').toLowerCase();
      const map = {
        'js': 'javascript', 'ts': 'typescript', 'jsx': 'javascriptreact',
        'css': 'css', 'scss': 'scss', 'sass': 'sass', 'less': 'less',
        'html': 'html', 'htm': 'html', 'php': 'php', 'json': 'json',
        'md': 'markdown', 'xml': 'xml', 'py': 'python', 'rb': 'ruby',
        'java': 'java', 'c': 'c', 'cpp': 'cpp', 'cs': 'csharp',
        'go': 'go', 'rs': 'rust', 'swift': 'swift', 'kt': 'kotlin',
        'sql': 'sql', 'sh': 'shell', 'yaml': 'yaml', 'yml': 'yaml'
      };
      return map[ext] || 'plaintext';
    }

    // ============= FILE TREE =============
    async function loadFiles() {
      try {
        const r = await fetch('?action=list');
        const tree = await r.json();
        const container = document.getElementById('file-list');
        container.innerHTML = '';
        renderTree(tree, container);
      } catch (e) {
        console.error(e);
        document.getElementById('file-list').innerText = 'Failed to load files';
      }
    }

    function renderTree(tree, container) {
      tree.forEach(item => {
        if (item.type === 'dir') {
          const details = document.createElement('details');
          const summary = document.createElement('summary');
          summary.className = 'dir-item';
          const iconDiv = document.createElement('div');
          iconDiv.className = 'folder-icon';
          iconDiv.innerHTML = svgIcons.folder;
          summary.appendChild(iconDiv);
          
          const nameSpan = document.createElement('span');
          nameSpan.textContent = ' ' + item.name;
          nameSpan.className = 'folder-name';
          summary.appendChild(nameSpan);
          
          details.appendChild(summary);
          
          details.addEventListener('toggle', function(e) {
            if (this.open) {
              iconDiv.innerHTML = svgIcons.folderOpen;
            } else {
              iconDiv.innerHTML = svgIcons.folder;
            }
          });
          
          const childrenDiv = document.createElement('div');
          childrenDiv.className = 'children';
          details.appendChild(childrenDiv);
          container.appendChild(details);
          renderTree(item.children || [], childrenDiv);
        } else {
          const fileDiv = document.createElement('div');
          fileDiv.className = 'file-item';
          fileDiv.dataset.path = item.path;
          const iconDiv = document.createElement('div');
          iconDiv.className = 'file-icon';
          iconDiv.innerHTML = getFileIconSVG(item.name);
          fileDiv.appendChild(iconDiv);
          
          const nameSpan = document.createElement('span');
          nameSpan.className = 'file-name';
          nameSpan.textContent = item.name;
          fileDiv.appendChild(nameSpan);
          
          // Click to open file
          fileDiv.addEventListener('click', function(e) {
            if (!fileDiv.classList.contains('editing')) {
              openFile(item.path);
            }
          });
          
          // Double click to rename
          fileDiv.addEventListener('dblclick', function(e) {
            e.preventDefault();
            e.stopPropagation();
            startRename(fileDiv, item.path);
          });
          
          container.appendChild(fileDiv);
        }
      });
    }

    function startRename(fileDiv, oldPath) {
      if (fileDiv.classList.contains('editing')) return;
      
      fileDiv.classList.add('editing');
      const nameSpan = fileDiv.querySelector('.file-name');
      const oldName = nameSpan.textContent;
      
      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'rename-input';
      input.value = oldName;
      
      nameSpan.replaceWith(input);
      input.focus();
      input.select();
      
      const finishRename = async () => {
        const newName = input.value.trim();
        if (newName && newName !== oldName) {
          const pathParts = oldPath.split('/');
          pathParts[pathParts.length - 1] = newName;
          const newPath = pathParts.join('/');
          
          const success = await renameFile(oldPath, newPath);
          if (success) {
            // Update open tabs
            const tabIndex = findTabByPath(oldPath);
            if (tabIndex >= 0) {
              openTabs[tabIndex].path = newPath;
              renderTabs();
              if (tabIndex === currentTabIndex) {
                updateUI(newPath, detectLanguage(newPath), openTabs[tabIndex].model.getLineCount());
              }
            }
          }
          await loadFiles();
        } else {
          const newNameSpan = document.createElement('span');
          newNameSpan.className = 'file-name';
          newNameSpan.textContent = oldName;
          input.replaceWith(newNameSpan);
          fileDiv.classList.remove('editing');
        }
      };
      
      input.addEventListener('blur', finishRename, { once: true });
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          input.blur();
        } else if (e.key === 'Escape') {
          const newNameSpan = document.createElement('span');
          newNameSpan.className = 'file-name';
          newNameSpan.textContent = oldName;
          input.replaceWith(newNameSpan);
          fileDiv.classList.remove('editing');
        }
      });
    }

    async function renameFile(oldPath, newPath) {
      try {
        // Read old file
        const r = await fetch('?action=read&file=' + encodeURIComponent(oldPath));
        if (!r.ok) {
          alert('Failed to read file');
          return false;
        }
        const content = await r.text();
        
        // Save to new path
        const body = new URLSearchParams();
        body.append('file', newPath);
        body.append('content', content);
        
        const saveResponse = await fetch('?action=save', {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: body.toString()
        });
        
        if (!saveResponse.ok) {
          alert('Failed to save renamed file');
          return false;
        }
        
        // Delete old file
        const deleteResponse = await fetch('?action=delete&file=' + encodeURIComponent(oldPath));
        
        if (deleteResponse.ok) {
          updateStatusBar('✓ Renamed to ' + newPath);
          setTimeout(() => updateStatusBar('⚡ Ready'), 2000);
          return true;
        } else {
          alert('Failed to delete old file');
          return false;
        }
      } catch (e) {
        console.error(e);
        alert('Rename failed: ' + e.message);
        return false;
      }
    }

    function escapeHtml(s) {
      return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    // ============= TAB MANAGEMENT =============
    function renderTabs() {
      const container = document.getElementById('tabs-container');
      container.innerHTML = '';
      
      openTabs.forEach((tab, index) => {
        const tabEl = document.createElement('div');
        tabEl.className = 'tab' + (index === currentTabIndex ? ' active' : '');
        if (modifiedTabs.has(index)) {
          tabEl.classList.add('modified');
        }
        
        const icon = document.createElement('div');
        icon.className = 'tab-icon';
        icon.innerHTML = getFileIconSVG(tab.path);
        
        const name = document.createElement('span');
        name.className = 'tab-name';
        name.textContent = tab.path.split('/').pop();
        name.title = tab.path;
        
        const close = document.createElement('span');
        close.className = 'tab-close';
        close.textContent = '×';
        close.onclick = (e) => {
          e.stopPropagation();
          closeTab(index);
        };
        
        tabEl.appendChild(icon);
        tabEl.appendChild(name);
        tabEl.appendChild(close);
        
        tabEl.onclick = () => switchToTab(index);
        container.appendChild(tabEl);
      });
    }

    function closeTab(index) {
      if (openTabs[index]) {
        if (openTabs[index].model) {
          openTabs[index].model.dispose();
        }
        openTabs.splice(index, 1);
        modifiedTabs.delete(index);
        
        // Reindex modified tabs
        const newModified = new Set();
        modifiedTabs.forEach(i => {
          if (i > index) newModified.add(i - 1);
          else if (i < index) newModified.add(i);
        });
        modifiedTabs = newModified;
        
        if (openTabs.length === 0) {
          currentTabIndex = -1;
          editor.setModel(null);
          updateUI('No file open', '', 0);
        } else {
          if (index <= currentTabIndex) {
            currentTabIndex = Math.max(0, currentTabIndex - 1);
          }
          switchToTab(currentTabIndex);
        }
        
        renderTabs();
      }
    }

    function switchToTab(index) {
      if (index < 0 || index >= openTabs.length) return;
      
      if (currentTabIndex >= 0 && openTabs[currentTabIndex]) {
        openTabs[currentTabIndex].viewState = editor.saveViewState();
      }
      
      currentTabIndex = index;
      const tab = openTabs[index];
      
      editor.setModel(tab.model);
      if (tab.viewState) {
        editor.restoreViewState(tab.viewState);
      }
      
      updateUI(tab.path, detectLanguage(tab.path), tab.model.getLineCount());
      renderTabs();
      highlightActiveFile(tab.path);
    }

    function findTabByPath(path) {
      return openTabs.findIndex(tab => tab.path === path);
    }

    // ============= FILE OPERATIONS =============
    async function openFile(path) {
      const existingIndex = findTabByPath(path);
      
      if (existingIndex >= 0) {
        switchToTab(existingIndex);
        return;
      }
      
      try {
        const r = await fetch('?action=read&file=' + encodeURIComponent(path));
        if (!r.ok) {
          alert('Error opening file');
          return;
        }
        
        const text = await r.text();
        const lang = detectLanguage(path);
        const uri = monaco.Uri.parse('inmemory://model/' + encodeURIComponent(path));
        
        const model = monaco.editor.createModel(text, lang, uri);
        
        openTabs.push({
          path: path,
          model: model,
          viewState: null
        });
        
        currentTabIndex = openTabs.length - 1;
        switchToTab(currentTabIndex);
      } catch (e) {
        console.error(e);
        alert('Failed to open file');
      }
    }

    async function saveFile(isAutoSave = false) {
      if (currentTabIndex < 0 || !openTabs[currentTabIndex]) {
        if (!isAutoSave) alert('No file selected');
        return;
      }
      
      const tab = openTabs[currentTabIndex];
      const content = tab.model.getValue();
      const body = new URLSearchParams();
      body.append('file', tab.path);
      body.append('content', content);
      
      const r = await fetch('?action=save', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: body.toString()
      });
      
      if (r.ok) {
        modifiedTabs.delete(currentTabIndex);
        renderTabs();
        loadFiles();
        if (isAutoSave) {
          updateStatusBar('💾 Auto-saved ' + tab.path);
          setTimeout(() => updateStatusBar('⚡ Ready'), 1500);
        } else {
          updateStatusBar('💾 Saved ' + tab.path);
          setTimeout(() => updateStatusBar('⚡ Ready'), 2000);
        }
      } else {
        if (!isAutoSave) alert('Save failed');
      }
    }

    async function promptNew() {
      const name = prompt('New file name (e.g. folder/test.html):');
      if (!name) return;
      
      const body = new URLSearchParams();
      body.append('file', name);
      body.append('content', '');
      
      const r = await fetch('?action=save', {
        method:'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: body.toString()
      });
      
      if (r.ok) {
        await loadFiles();
        openFile(name);
      } else {
        alert('Failed to create file');
      }
    }

    async function doDelete() {
      if (currentTabIndex < 0 || !openTabs[currentTabIndex]) {
        alert('No file selected');
        return;
      }
      
      const tab = openTabs[currentTabIndex];
      if (!confirm('Delete ' + tab.path + '?')) return;
      
      const r = await fetch('?action=delete&file=' + encodeURIComponent(tab.path));
      
      if (r.ok) {
        closeTab(currentTabIndex);
        await loadFiles();
      } else {
        alert('Delete failed');
      }
    }

    function refresh() {
      loadFiles();
    }

    // ============= UI UPDATES =============
    function updateUI(path, lang, lines) {
      document.getElementById('current-file').textContent = path;
      document.getElementById('current-lang').textContent = lang ? '(' + lang + ')' : '';
      document.getElementById('status-lang').textContent = lang || 'plaintext';
      document.getElementById('status-lines').textContent = 'Lines: ' + lines;
    }

    function updateStatusBar(message) {
      const statusEl = document.querySelector('#statusbar .left .status-item');
      if (statusEl) statusEl.textContent = message;
    }

    function highlightActiveFile(path) {
      document.querySelectorAll('.file-item').forEach(el => {
        el.classList.toggle('active', el.dataset.path === path);
      });
    }

    // ============= MONACO INITIALIZATION =============
    require.config({ 
      paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs' }
    });
    
    require(['vs/editor/editor.main'], function() {
      editor = monaco.editor.create(document.getElementById('editor'), {
        value: '',
        language: 'javascript',
        theme: 'vs-dark',
        automaticLayout: true,
        fontSize: 14,
        lineNumbers: 'on',
        minimap: { enabled: true },
        scrollBeyondLastLine: false,
        tabCompletion: 'on',
        quickSuggestions: true,
        suggestOnTriggerCharacters: true,
        wordWrap: 'off',
        formatOnPaste: true,
        formatOnType: true
      });

      // Track content changes for auto-save and modified indicator
      editor.onDidChangeModelContent(() => {
        if (currentTabIndex >= 0 && openTabs[currentTabIndex]) {
          const lines = openTabs[currentTabIndex].model.getLineCount();
          document.getElementById('status-lines').textContent = 'Lines: ' + lines;
          
          // Mark tab as modified
          modifiedTabs.add(currentTabIndex);
          renderTabs();
          
          // Schedule auto-save
          scheduleAutoSave();
        }
      });

      // Keyboard shortcuts
      window.addEventListener('keydown', function(e) {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
          e.preventDefault();
          saveFile();
        }
        
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'w') {
          e.preventDefault();
          if (currentTabIndex >= 0) {
            closeTab(currentTabIndex);
          }
        }
      });

      // Emmet integration
      try {
        if (window.emmetMonaco) {
          window.emmetMonaco.emmetHTML(monaco, ['html','php']);
          window.emmetMonaco.emmetCSS(monaco, ['css','scss','sass','less']);
          if (window.emmetMonaco.emmetJSX) {
            window.emmetMonaco.emmetJSX(monaco, ['javascript','javascriptreact','typescriptreact']);
          }
          console.log('✓ Emmet enabled');
        }
      } catch (e) {
        console.error('Emmet init error', e);
      }

      loadFiles();
      updateStatusBar('⚡ Ready');
    });
  </script>
</body>
</html>